import { Component, ElementRef, EventEmitter, Output, signal, ViewChild, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormBuilder, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { LEGAL_CONTENT } from '../data/legal.data';
import { NotificationService } from '../services/notification.service';
import { SupportBotComponent } from './support-bot.component';

@Component({
  selector: 'app-landing-page',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule, SupportBotComponent],
  template: `
    <div class="h-screen overflow-y-auto overflow-x-hidden bg-[#020617] text-white scroll-smooth selection:bg-cyan-500 selection:text-black font-['Outfit']" #mainContainer>
      
      <!-- NAVIGATION -->
      <nav class="fixed top-0 left-0 right-0 z-50 transition-all duration-300 border-b border-white/5" 
           [class.bg-[#020617]/80]="scrolled()" 
           [class.backdrop-blur-xl]="scrolled()"
           [class.bg-transparent]="!scrolled()">
        <div class="max-w-7xl mx-auto px-6">
          <div class="flex justify-between items-center h-20">
            
            <!-- New Logo: Nebula -->
            <div class="flex items-center gap-3 cursor-pointer group" (click)="scrollToTop()">
              <div class="relative w-10 h-10 flex items-center justify-center">
                 <div class="absolute inset-0 bg-cyan-500 blur-[20px] opacity-40 group-hover:opacity-60 transition duration-500"></div>
                 <div class="relative z-10 w-10 h-10 bg-gradient-to-br from-cyan-400 to-blue-600 rounded-lg flex items-center justify-center text-white shadow-lg border border-white/20 transform group-hover:rotate-12 transition duration-300">
                    <span class="material-icons-round text-2xl">cloud_circle</span>
                 </div>
              </div>
              <span class="font-bold text-2xl tracking-tight text-white group-hover:text-cyan-300 transition">Nebula<span class="font-light text-slate-400">Workspace</span></span>
            </div>

            <!-- Desktop Menu -->
            <div class="hidden md:flex items-center space-x-8">
              <button (click)="scrollToSection('features')" class="text-sm font-medium text-slate-400 hover:text-cyan-300 transition hover:scale-105">Platforma</button>
              <button (click)="scrollToSection('security')" class="text-sm font-medium text-slate-400 hover:text-cyan-300 transition hover:scale-105">Szyfrowanie</button>
              <button (click)="openLegalModal('contact')" class="text-sm font-medium text-slate-400 hover:text-cyan-300 transition hover:scale-105">Kontakt</button>
            </div>

            <!-- Desktop CTA -->
            <div class="hidden md:flex items-center space-x-4">
              <button (click)="onNavigate.emit('login')" class="text-sm font-bold text-white hover:text-cyan-400 transition px-4 py-2 uppercase tracking-wide">
                Logowanie
              </button>
              <button (click)="onNavigate.emit('register')" class="group relative px-6 py-2.5 rounded-full bg-cyan-500 text-black text-sm font-extrabold transition hover:scale-105 active:scale-95 shadow-[0_0_20px_rgba(6,182,212,0.5)]">
                 <span class="relative flex items-center gap-2">
                    Start
                    <span class="material-icons-round text-sm group-hover:translate-x-1 transition">arrow_forward</span>
                 </span>
              </button>
            </div>

            <!-- Mobile Menu Button -->
            <div class="md:hidden flex items-center">
              <button (click)="mobileMenuOpen.set(!mobileMenuOpen())" class="p-2 rounded-lg text-white hover:bg-white/10 transition">
                <span class="material-icons-round text-3xl">{{ mobileMenuOpen() ? 'close' : 'drag_handle' }}</span>
              </button>
            </div>
          </div>
        </div>

        <!-- Mobile Menu Overlay -->
        @if (mobileMenuOpen()) {
          <div class="md:hidden absolute top-20 left-0 w-full bg-[#020617]/95 border-b border-white/10 shadow-2xl backdrop-blur-xl animate-slide-down">
            <div class="px-6 py-8 space-y-4">
              <button (click)="scrollToSection('features'); mobileMenuOpen.set(false)" class="block w-full text-left py-2 text-slate-300 hover:text-cyan-400 font-bold text-xl uppercase">Platforma</button>
              <button (click)="scrollToSection('security'); mobileMenuOpen.set(false)" class="block w-full text-left py-2 text-slate-300 hover:text-cyan-400 font-bold text-xl uppercase">Szyfrowanie</button>
              <div class="border-t border-white/10 my-4 pt-4"></div>
              <button (click)="onNavigate.emit('login')" class="block w-full text-center py-4 rounded-xl border border-white/10 font-bold text-white mb-3 hover:bg-white/5 transition">ZALOGUJ SIĘ</button>
              <button (click)="onNavigate.emit('register')" class="block w-full text-center py-4 rounded-xl bg-cyan-600 text-white font-bold shadow-lg shadow-cyan-900/50">UTWÓRZ KONTO</button>
            </div>
          </div>
        }
      </nav>

      <!-- HERO SECTION -->
      <section class="relative pt-32 pb-20 lg:pt-48 lg:pb-32 overflow-hidden min-h-screen flex flex-col justify-center items-center">
        <!-- Background Grid & Glows -->
        <div class="absolute inset-0 bg-grid opacity-20 pointer-events-none"></div>
        <div class="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] bg-cyan-500/10 rounded-full blur-[120px] pointer-events-none animate-pulse-slow"></div>
        <div class="absolute top-1/4 left-1/4 w-[300px] h-[300px] bg-purple-600/20 rounded-full blur-[100px] pointer-events-none"></div>

        <div class="max-w-5xl mx-auto px-6 relative z-10 text-center">
          <div class="inline-flex items-center gap-3 px-5 py-2 rounded-full bg-white/5 border border-white/10 backdrop-blur-md mb-8 animate-fade-in-up hover:border-cyan-500/50 transition cursor-default group">
            <span class="flex h-2 w-2 relative">
              <span class="animate-ping absolute inline-flex h-full w-full rounded-full bg-cyan-400 opacity-75"></span>
              <span class="relative inline-flex rounded-full h-2 w-2 bg-cyan-500"></span>
            </span>
            <span class="text-sm font-medium text-slate-300 group-hover:text-white transition">System v4.0 Online</span>
          </div>
          
          <h1 class="text-6xl md:text-8xl font-black tracking-tight text-white mb-8 leading-none animate-fade-in-up delay-100 drop-shadow-2xl">
            TWÓJ CYFROWY <br>
            <span class="text-transparent bg-clip-text bg-gradient-to-r from-cyan-400 via-blue-500 to-purple-600">WSZECHŚWIAT</span>
          </h1>
          
          <p class="mt-6 max-w-2xl mx-auto text-xl text-slate-400 mb-12 animate-fade-in-up delay-200 leading-relaxed font-light">
            Zarządzaj dokumentacją, analizuj dane z AI i współpracuj w czasie rzeczywistym. 
            Bezpieczeństwo klasy militarnej w nowoczesnym wydaniu.
          </p>
          
          <div class="flex flex-col sm:flex-row justify-center gap-6 animate-fade-in-up delay-300">
            <button (click)="onNavigate.emit('register')" class="px-10 py-5 bg-white text-black rounded-xl font-bold text-lg hover:bg-cyan-50 transition shadow-[0_0_30px_rgba(255,255,255,0.2)] hover:-translate-y-1 transform">
              Rozpocznij Podróż
            </button>
            <button (click)="scrollToSection('features')" class="px-10 py-5 bg-transparent border border-white/20 text-white rounded-xl font-bold text-lg hover:bg-white/10 transition backdrop-blur-md hover:-translate-y-1 transform">
              Zobacz Demo
            </button>
          </div>

          <!-- Futuristic Interface Mockup -->
          <div class="mt-24 relative mx-auto max-w-6xl animate-fade-in-up delay-500">
             <div class="relative bg-[#0B1121] border border-white/10 rounded-t-3xl p-2 shadow-2xl ring-1 ring-white/10 group overflow-hidden">
                <div class="absolute inset-0 bg-gradient-to-t from-cyan-500/10 to-transparent opacity-0 group-hover:opacity-100 transition duration-700"></div>
                <!-- Browser Header -->
                <div class="bg-[#020617] h-12 rounded-t-2xl flex items-center px-4 gap-3 border-b border-white/5">
                   <div class="flex gap-2">
                      <div class="w-3 h-3 rounded-full bg-red-500/50"></div>
                      <div class="w-3 h-3 rounded-full bg-yellow-500/50"></div>
                      <div class="w-3 h-3 rounded-full bg-green-500/50"></div>
                   </div>
                   <div class="flex-1 text-center">
                      <div class="bg-[#1E293B] inline-block px-12 py-1 rounded-md text-[10px] text-slate-500 font-mono tracking-wider">NEBULA://SECURE-WORKSPACE</div>
                   </div>
                </div>
                <!-- Content Placeholder -->
                <div class="bg-[#0F172A] aspect-[21/9] flex items-center justify-center relative overflow-hidden">
                   <div class="absolute inset-0 bg-grid opacity-30"></div>
                   <div class="text-center z-10">
                      <span class="material-icons-round text-8xl text-slate-700 animate-pulse">fingerprint</span>
                      <p class="text-slate-500 font-mono mt-4 uppercase tracking-[0.2em]">Authentication Required</p>
                   </div>
                   <!-- Glowing Line -->
                   <div class="absolute bottom-0 left-0 w-full h-1 bg-gradient-to-r from-cyan-500 via-purple-500 to-cyan-500 shadow-[0_-5px_20px_rgba(6,182,212,0.5)]"></div>
                </div>
             </div>
          </div>
        </div>
      </section>

      <!-- FEATURES GRID -->
      <section id="features" class="py-32 relative bg-[#020617]">
        <div class="max-w-7xl mx-auto px-6">
          <div class="grid grid-cols-1 md:grid-cols-3 gap-8">
            <!-- Feature 1 -->
            <div class="p-8 rounded-3xl bg-[#0B1121] border border-white/5 hover:border-cyan-500/50 transition duration-500 group relative overflow-hidden">
               <div class="absolute inset-0 bg-gradient-to-br from-cyan-500/10 to-transparent opacity-0 group-hover:opacity-100 transition duration-500"></div>
               <span class="material-icons-round text-5xl text-cyan-500 mb-6 group-hover:scale-110 transition duration-300 block">psychology</span>
               <h3 class="text-2xl font-bold text-white mb-3">AI Neural Core</h3>
               <p class="text-slate-400">Analiza semantyczna dokumentów w czasie rzeczywistym. Zadawaj pytania, otrzymuj odpowiedzi z kontekstem prawnym.</p>
            </div>

            <!-- Feature 2 -->
            <div class="p-8 rounded-3xl bg-[#0B1121] border border-white/5 hover:border-purple-500/50 transition duration-500 group relative overflow-hidden">
               <div class="absolute inset-0 bg-gradient-to-br from-purple-500/10 to-transparent opacity-0 group-hover:opacity-100 transition duration-500"></div>
               <span class="material-icons-round text-5xl text-purple-500 mb-6 group-hover:scale-110 transition duration-300 block">enhanced_encryption</span>
               <h3 class="text-2xl font-bold text-white mb-3">Szyfrowanie Zero-Trust</h3>
               <p class="text-slate-400">Twoje dane są Twoje. Architektura bez wiedzy (Zero-Knowledge) gwarantuje absolutną prywatność.</p>
            </div>

            <!-- Feature 3 -->
            <div class="p-8 rounded-3xl bg-[#0B1121] border border-white/5 hover:border-blue-500/50 transition duration-500 group relative overflow-hidden">
               <div class="absolute inset-0 bg-gradient-to-br from-blue-500/10 to-transparent opacity-0 group-hover:opacity-100 transition duration-500"></div>
               <span class="material-icons-round text-5xl text-blue-500 mb-6 group-hover:scale-110 transition duration-300 block">speed</span>
               <h3 class="text-2xl font-bold text-white mb-3">Hyper-Speed</h3>
               <p class="text-slate-400">Interfejs zoptymalizowany pod kątem milisekund. Brak opóźnień, brak przeładowań. Czysta wydajność.</p>
            </div>
          </div>
        </div>
      </section>

      <!-- CTA / FOOTER -->
      <footer class="border-t border-white/5 bg-[#010409] pt-24 pb-12">
        <div class="max-w-7xl mx-auto px-6">
          <div class="flex flex-col md:flex-row justify-between items-start gap-12">
             <div>
                <div class="flex items-center gap-2 mb-6">
                   <span class="material-icons-round text-cyan-500 text-3xl">cloud_circle</span>
                   <span class="text-2xl font-bold text-white">Nebula</span>
                </div>
                <p class="text-slate-500 max-w-sm">
                   Przyszłość pracy biurowej jest tutaj.
                   <br>Dołącz do tysięcy profesjonalistów.
                </p>
             </div>
             
             <div class="flex gap-16">
                <div>
                   <h4 class="text-white font-bold mb-4 uppercase tracking-wider text-xs">Produkt</h4>
                   <ul class="space-y-3 text-slate-400 text-sm">
                      <li><button (click)="scrollToSection('features')" class="hover:text-cyan-400 transition">Funkcje</button></li>
                      <li><button (click)="scrollToSection('security')" class="hover:text-cyan-400 transition">Bezpieczeństwo</button></li>
                      <li><button (click)="openLegalModal('contact')" class="hover:text-cyan-400 transition">Wsparcie</button></li>
                   </ul>
                </div>
                <div>
                   <h4 class="text-white font-bold mb-4 uppercase tracking-wider text-xs">Prawne</h4>
                   <ul class="space-y-3 text-slate-400 text-sm">
                      <li><button (click)="openLegalModal('terms')" class="hover:text-cyan-400 transition">Regulamin</button></li>
                      <li><button (click)="openLegalModal('privacy')" class="hover:text-cyan-400 transition">Prywatność</button></li>
                   </ul>
                </div>
             </div>
          </div>
          
          <div class="mt-20 pt-8 border-t border-white/5 text-center text-xs text-slate-600 font-mono">
             NEBULA WORKSPACE SYSTEM © 2024. ALL RIGHTS RESERVED.
          </div>
        </div>
      </footer>

      <!-- Support Bot -->
      <app-support-bot></app-support-bot>

      <!-- UNIVERSAL MODAL -->
      @if (activeModal()) {
        <div class="fixed inset-0 z-[100] flex items-center justify-center bg-black/90 backdrop-blur-md p-4 animate-fade-in" (click)="closeModal()">
          <div class="bg-[#0B1121] border border-white/10 rounded-3xl shadow-2xl w-full max-w-3xl max-h-[85vh] flex flex-col overflow-hidden animate-scale-in" (click)="$event.stopPropagation()">
            
            <!-- Header -->
            <div class="px-8 py-6 border-b border-white/10 flex justify-between items-center bg-[#020617]">
              <h3 class="text-xl font-bold text-white flex items-center gap-3">
                @switch (activeModal()) {
                  @case ('contact') { <span class="material-icons-round text-cyan-500">headset_mic</span> Centrum Wsparcia }
                  @case ('privacy') { <span class="material-icons-round text-purple-500">lock</span> Prywatność }
                  @case ('terms') { <span class="material-icons-round text-blue-500">gavel</span> Regulamin }
                  @case ('rodo') { <span class="material-icons-round text-emerald-500">info</span> RODO }
                }
              </h3>
              <button (click)="closeModal()" class="p-2 hover:bg-white/10 rounded-full transition text-slate-400 hover:text-white">
                <span class="material-icons-round">close</span>
              </button>
            </div>

            <!-- Content -->
            <div class="flex-1 overflow-y-auto p-8 text-slate-300 leading-relaxed custom-scrollbar font-light">
               @if (activeModal() === 'contact') {
                  <p class="mb-8 text-slate-400 border-l-2 border-cyan-500 pl-4">Wypełnij zgłoszenie. Nasz system AI wstępnie przetworzy Twoje zapytanie, aby przyspieszyć odpowiedź.</p>
                  
                  <form [formGroup]="contactForm" (ngSubmit)="onContactSubmit()" class="space-y-6">
                     <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                        <div class="space-y-2">
                           <label class="text-xs font-bold text-slate-500 uppercase tracking-wider">Imię</label>
                           <input formControlName="name" type="text" class="w-full bg-[#020617] border border-white/10 rounded-xl px-4 py-3 text-white focus:border-cyan-500 focus:ring-1 focus:ring-cyan-500 outline-none transition" placeholder="Twój identyfikator">
                        </div>
                        <div class="space-y-2">
                           <label class="text-xs font-bold text-slate-500 uppercase tracking-wider">Email</label>
                           <input formControlName="email" type="email" class="w-full bg-[#020617] border border-white/10 rounded-xl px-4 py-3 text-white focus:border-cyan-500 focus:ring-1 focus:ring-cyan-500 outline-none transition" placeholder="user@domain.com">
                        </div>
                     </div>
                     <div class="space-y-2">
                        <label class="text-xs font-bold text-slate-500 uppercase tracking-wider">Kategoria</label>
                        <select formControlName="subject" class="w-full bg-[#020617] border border-white/10 rounded-xl px-4 py-3 text-white focus:border-cyan-500 outline-none transition appearance-none">
                           <option value="password_reset">Reset Danych Dostępowych</option>
                           <option value="data_change">Zmiana Danych Konta</option>
                           <option value="tech_support">Wsparcie Techniczne</option>
                        </select>
                     </div>
                     <div class="space-y-2">
                        <label class="text-xs font-bold text-slate-500 uppercase tracking-wider">Wiadomość</label>
                        <textarea formControlName="message" rows="5" class="w-full bg-[#020617] border border-white/10 rounded-xl px-4 py-3 text-white focus:border-cyan-500 focus:ring-1 focus:ring-cyan-500 outline-none transition resize-none" placeholder="Opisz problem..."></textarea>
                     </div>

                     <div class="flex justify-end pt-4">
                        <button type="submit" [disabled]="contactForm.invalid || isSending" class="px-8 py-3 bg-gradient-to-r from-cyan-600 to-blue-600 text-white font-bold rounded-xl hover:brightness-110 transition disabled:opacity-50 disabled:cursor-wait flex items-center gap-2 shadow-lg shadow-cyan-900/30">
                           @if (isSending) {
                              <span class="material-icons-round animate-spin">sync</span> Przetwarzanie...
                           } @else {
                              <span class="material-icons-round">send</span> Wyślij Zgłoszenie
                           }
                        </button>
                     </div>
                  </form>
               } @else {
                  <div [innerHTML]="getLegalContent(activeModal())"></div>
               }
            </div>
          </div>
        </div>
      }
    </div>
  `,
  styles: [`
    .animate-fade-in-up { animation: fadeInUp 0.8s cubic-bezier(0.16, 1, 0.3, 1) forwards; opacity: 0; transform: translateY(20px); }
    .delay-100 { animation-delay: 0.1s; }
    .delay-200 { animation-delay: 0.2s; }
    .delay-300 { animation-delay: 0.3s; }
    .delay-500 { animation-delay: 0.5s; }
    @keyframes fadeInUp { to { opacity: 1; transform: translateY(0); } }
    .animate-pulse-slow { animation: pulseSlow 8s infinite; }
    @keyframes pulseSlow { 0%, 100% { opacity: 0.3; transform: scale(1); } 50% { opacity: 0.5; transform: scale(1.1); } }
    
    .bg-grid { background-image: radial-gradient(rgba(255,255,255,0.1) 1px, transparent 1px); background-size: 40px 40px; }
  `]
})
export class LandingPageComponent {
  @Output() onNavigate = new EventEmitter<'login' | 'register'>();
  private notificationService = inject(NotificationService);
  private fb = inject(FormBuilder);

  mobileMenuOpen = signal(false);
  scrolled = signal(false);
  activeModal = signal<string | null>(null);
  isSending = false;

  @ViewChild('mainContainer') mainContainer!: ElementRef;

  contactForm: FormGroup = this.fb.group({
    name: ['', [Validators.required, Validators.minLength(2)]],
    email: ['', [Validators.required, Validators.email]],
    subject: ['password_reset', Validators.required],
    message: ['', [Validators.required, Validators.minLength(5)]]
  });

  ngAfterViewInit() {
    this.mainContainer.nativeElement.addEventListener('scroll', () => {
      this.scrolled.set(this.mainContainer.nativeElement.scrollTop > 20);
    });
  }

  scrollToTop() { this.mainContainer.nativeElement.scrollTo({ top: 0, behavior: 'smooth' }); }
  
  scrollToSection(id: string) {
    const el = document.getElementById(id);
    if (el) el.scrollIntoView({ behavior: 'smooth', block: 'start' });
    this.mobileMenuOpen.set(false);
  }

  openLegalModal(type: string) { this.activeModal.set(type); }
  
  closeModal() { 
     this.activeModal.set(null); 
     this.contactForm.reset({ subject: 'password_reset' });
  }

  getLegalContent(type: string | null): string {
    if (!type) return '';
    return (LEGAL_CONTENT as any)[type] || '<p>Brak treści.</p>';
  }

  onContactSubmit() {
    if (this.contactForm.invalid) return;

    this.isSending = true;
    const { email, subject } = this.contactForm.value;
    
    setTimeout(() => {
       this.isSending = false;
       let message = 'Wiadomość wysłana.';
       if (subject === 'password_reset') {
         message = `Instrukcja resetu wysłana na ${email}.`;
       } else if (subject === 'data_change') {
         message = `Zgłoszenie zmiany danych przyjęte do weryfikacji.`;
       }
       this.notificationService.show(message, 'success');
       this.closeModal();
    }, 1500);
  }
}