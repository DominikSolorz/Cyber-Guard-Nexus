import { Component, inject, computed, signal, OnInit, OnDestroy } from '@angular/core';
import { CommonModule } from '@angular/common';
import { DataService } from '../services/data.service';
import { CloudService } from '../services/cloud.service';

@Component({
  selector: 'app-dashboard',
  standalone: true,
  imports: [CommonModule],
  template: `
    <div class="h-full overflow-y-auto p-6 md:p-8 space-y-8 animate-fade-in custom-scrollbar">
      
      <!-- Welcome Section & Clock -->
      <div class="flex flex-col md:flex-row justify-between items-start md:items-end gap-6">
        <div>
          <h1 class="text-3xl md:text-4xl font-bold bg-clip-text text-transparent bg-gradient-to-r from-cyan-400 to-blue-600 mb-2">
            Witaj, {{ user()?.firstName || 'Użytkowniku' }}.
          </h1>
          <p class="text-slate-500 font-medium text-lg">System online. Połączenie z chmurą: {{ cloudStatus().online ? 'Aktywne' : 'Przerwane' }}.</p>
        </div>
        <div class="text-right">
           <div class="text-5xl font-black text-slate-700 tracking-tighter">{{ time() }}</div>
           <div class="text-slate-400 font-medium uppercase tracking-widest text-sm">{{ date() }}</div>
        </div>
      </div>

      <!-- Widgets Grid -->
      <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        
        <!-- Storage Widget (Cloud Connected) -->
        <div class="bg-white p-6 rounded-3xl shadow-sm border border-slate-100 relative overflow-hidden group hover:border-cyan-300 transition duration-500">
           <div class="absolute -right-6 -top-6 w-24 h-24 bg-cyan-50 rounded-full group-hover:bg-cyan-100 transition"></div>
           <div class="relative z-10">
              <div class="flex items-center justify-between mb-4">
                 <div class="flex items-center gap-3">
                    <div class="w-10 h-10 rounded-xl bg-cyan-100 text-cyan-600 flex items-center justify-center">
                        <span class="material-icons-round">cloud_queue</span>
                    </div>
                    <h3 class="font-bold text-slate-700">Chmura</h3>
                 </div>
                 @if (cloudStatus().syncing) {
                    <span class="material-icons-round animate-spin text-cyan-500 text-sm">sync</span>
                 }
              </div>
              <div class="flex items-end gap-2 mb-2">
                 <span class="text-3xl font-black text-slate-800">{{ totalStorage }}</span>
              </div>
              <div class="w-full bg-slate-100 rounded-full h-2 overflow-hidden">
                 <div class="bg-cyan-500 h-full rounded-full w-[25%] relative overflow-hidden">
                    <div class="absolute inset-0 bg-white/30 animate-pulse"></div>
                 </div>
              </div>
              <p class="text-xs text-slate-400 mt-2 flex items-center gap-1">
                 @if(cloudStatus().googleConnected) {
                   <span class="w-1.5 h-1.5 bg-green-500 rounded-full"></span> Google Drive połączony
                 } @else {
                   <span class="w-1.5 h-1.5 bg-slate-300 rounded-full"></span> Lokalna kopia
                 }
              </p>
           </div>
        </div>

        <!-- Files Widget -->
        <div class="bg-white p-6 rounded-3xl shadow-sm border border-slate-100 relative overflow-hidden group hover:border-purple-300 transition duration-500">
           <div class="absolute -right-6 -top-6 w-24 h-24 bg-purple-50 rounded-full group-hover:bg-purple-100 transition"></div>
           <div class="relative z-10">
              <div class="flex items-center gap-3 mb-4">
                 <div class="w-10 h-10 rounded-xl bg-purple-100 text-purple-600 flex items-center justify-center">
                    <span class="material-icons-round">description</span>
                 </div>
                 <h3 class="font-bold text-slate-700">Pliki</h3>
              </div>
              <div class="flex items-end gap-2">
                 <span class="text-3xl font-black text-slate-800">{{ fileCount() }}</span>
                 <span class="text-sm text-slate-400 mb-1">elementów</span>
              </div>
              <div class="flex gap-2 mt-4">
                 <span class="text-xs px-2 py-1 bg-blue-50 text-blue-600 rounded-md font-bold">DOCX</span>
                 <span class="text-xs px-2 py-1 bg-red-50 text-red-600 rounded-md font-bold">PDF</span>
                 <span class="text-xs px-2 py-1 bg-green-50 text-green-600 rounded-md font-bold">IMG</span>
              </div>
           </div>
        </div>

        <!-- Tasks Widget -->
        <div class="bg-white p-6 rounded-3xl shadow-sm border border-slate-100 relative overflow-hidden group hover:border-emerald-300 transition duration-500">
           <div class="absolute -right-6 -top-6 w-24 h-24 bg-emerald-50 rounded-full group-hover:bg-emerald-100 transition"></div>
           <div class="relative z-10">
              <div class="flex items-center gap-3 mb-4">
                 <div class="w-10 h-10 rounded-xl bg-emerald-100 text-emerald-600 flex items-center justify-center">
                    <span class="material-icons-round">check_circle</span>
                 </div>
                 <h3 class="font-bold text-slate-700">Zadania</h3>
              </div>
              <div class="flex items-end gap-2">
                 <span class="text-3xl font-black text-slate-800">{{ pendingTasks() }}</span>
                 <span class="text-sm text-slate-400 mb-1">do zrobienia</span>
              </div>
              <p class="text-xs text-slate-400 mt-2">
                 {{ completedTasks() }} ukończonych zadań w tym miesiącu.
              </p>
           </div>
        </div>

        <!-- Weather/Time Widget (Simulated) -->
        <div class="bg-gradient-to-br from-indigo-500 to-blue-600 p-6 rounded-3xl shadow-lg shadow-blue-500/20 text-white relative overflow-hidden">
           <div class="absolute inset-0 bg-white/10 opacity-30 bg-grid"></div>
           <div class="relative z-10 flex flex-col justify-between h-full">
              <div class="flex justify-between items-start">
                 <div class="bg-white/20 backdrop-blur-md px-3 py-1 rounded-lg text-xs font-bold">Warszawa</div>
                 <span class="material-icons-round text-yellow-300 text-4xl animate-pulse-slow">wb_sunny</span>
              </div>
              <div>
                 <div class="text-4xl font-bold">21°C</div>
                 <div class="text-sm text-blue-100 opacity-90">Słonecznie, lekki wiatr.</div>
              </div>
           </div>
        </div>
      </div>

      <!-- Quick Actions -->
      <h2 class="text-lg font-bold text-slate-700 mt-8 mb-4">Szybkie Akcje</h2>
      <div class="flex gap-4 overflow-x-auto pb-2">
         <button class="flex items-center gap-3 px-6 py-4 bg-white border border-slate-100 rounded-2xl hover:bg-slate-50 transition shadow-sm hover:shadow group min-w-[160px]">
            <div class="w-8 h-8 rounded-full bg-cyan-100 text-cyan-600 flex items-center justify-center group-hover:scale-110 transition">
               <span class="material-icons-round text-sm">upload_file</span>
            </div>
            <span class="font-bold text-sm text-slate-700">Wgraj Plik</span>
         </button>
         <button class="flex items-center gap-3 px-6 py-4 bg-white border border-slate-100 rounded-2xl hover:bg-slate-50 transition shadow-sm hover:shadow group min-w-[160px]">
            <div class="w-8 h-8 rounded-full bg-purple-100 text-purple-600 flex items-center justify-center group-hover:scale-110 transition">
               <span class="material-icons-round text-sm">note_add</span>
            </div>
            <span class="font-bold text-sm text-slate-700">Nowa Notatka</span>
         </button>
         <button class="flex items-center gap-3 px-6 py-4 bg-white border border-slate-100 rounded-2xl hover:bg-slate-50 transition shadow-sm hover:shadow group min-w-[160px]">
            <div class="w-8 h-8 rounded-full bg-emerald-100 text-emerald-600 flex items-center justify-center group-hover:scale-110 transition">
               <span class="material-icons-round text-sm">add_task</span>
            </div>
            <span class="font-bold text-sm text-slate-700">Dodaj Zadanie</span>
         </button>
      </div>

      <!-- Recent Files -->
      <div class="bg-white rounded-3xl border border-slate-200 overflow-hidden shadow-sm">
         <div class="p-6 border-b border-slate-100 flex justify-between items-center bg-slate-50">
            <h3 class="font-bold text-slate-800">Ostatnio dodane pliki</h3>
            <span class="text-xs text-slate-400 font-bold uppercase tracking-wider">Historia</span>
         </div>
         <div class="divide-y divide-slate-100">
            @if (recentFiles().length === 0) {
               <div class="p-8 text-center text-slate-400">
                  <p>Brak ostatniej aktywności.</p>
               </div>
            }
            @for (file of recentFiles(); track file.id) {
               <div class="p-4 flex items-center hover:bg-slate-50 transition gap-4">
                  <div class="w-10 h-10 rounded-lg flex items-center justify-center text-white font-bold text-xs uppercase"
                       [ngClass]="getFileColor(file.fileType || 'unknown')">
                     {{ file.fileType || 'FILE' }}
                  </div>
                  <div class="flex-1">
                     <p class="text-sm font-bold text-slate-800">{{ file.name }}</p>
                     <p class="text-xs text-slate-400">{{ file.date }} • {{ file.size }}</p>
                  </div>
                  <button class="p-2 text-slate-400 hover:text-cyan-600 transition">
                     <span class="material-icons-outlined">download</span>
                  </button>
               </div>
            }
         </div>
      </div>
    </div>
  `,
  styles: [`
    .animate-fade-in { animation: fadeIn 0.4s ease-out; }
    @keyframes fadeIn { from { opacity: 0; transform: translateY(10px); } to { opacity: 1; transform: translateY(0); } }
    .animate-pulse-slow { animation: pulse 3s infinite; }
    .bg-grid { background-image: radial-gradient(rgba(255,255,255,0.2) 1px, transparent 1px); background-size: 10px 10px; }
    .custom-scrollbar::-webkit-scrollbar { width: 6px; }
    .custom-scrollbar::-webkit-scrollbar-track { background: transparent; }
    .custom-scrollbar::-webkit-scrollbar-thumb { background: #cbd5e1; border-radius: 3px; }
  `]
})
export class DashboardComponent implements OnInit, OnDestroy {
  dataService = inject(DataService);
  cloudService = inject(CloudService); // Inject Cloud Service
  
  user = this.dataService.currentUser;
  cloudStatus = this.cloudService.status;
  
  time = signal('');
  date = signal('');
  private timer: any;

  fileCount = computed(() => this.dataService.items().filter(i => i.type === 'file').length);
  recentFiles = computed(() => {
     return this.dataService.items()
      .filter(i => i.type === 'file')
      .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime())
      .slice(0, 5);
  });

  pendingTasks = computed(() => this.dataService.userTasks().filter(t => t.status !== 'done').length);
  completedTasks = computed(() => this.dataService.userTasks().filter(t => t.status === 'done').length);

  get totalStorage(): string {
     const totalBytes = this.dataService.items().reduce((acc, item) => acc + (item.sizeBytes || 0), 0);
     if (totalBytes === 0) return '0 B';
     const k = 1024;
     const sizes = ['B', 'KB', 'MB', 'GB'];
     const i = Math.floor(Math.log(totalBytes) / Math.log(k));
     return parseFloat((totalBytes / Math.pow(k, i)).toFixed(1)) + ' ' + sizes[i];
  }

  ngOnInit() {
    this.updateTime();
    this.timer = setInterval(() => this.updateTime(), 1000);
  }

  ngOnDestroy() {
    if (this.timer) clearInterval(this.timer);
  }

  updateTime() {
    const now = new Date();
    this.time.set(now.toLocaleTimeString('pl-PL', { hour: '2-digit', minute: '2-digit' }));
    this.date.set(now.toLocaleDateString('pl-PL', { weekday: 'long', day: 'numeric', month: 'long' }));
  }

  getFileColor(type: string) {
     if (['jpg', 'png', 'gif'].includes(type)) return 'bg-purple-500';
     if (['pdf'].includes(type)) return 'bg-red-500';
     if (['docx', 'doc'].includes(type)) return 'bg-blue-500';
     if (['txt', 'md'].includes(type)) return 'bg-slate-500';
     return 'bg-emerald-500';
  }
}