import { Component, EventEmitter, Input, OnInit, Output, signal, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormBuilder, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { FirebaseService } from '../services/firebase.service';
import { DataService } from '../services/data.service';
import { LEGAL_CONTENT } from '../data/legal.data';
import { SupportBotComponent } from './support-bot.component';

@Component({
  selector: 'app-auth',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule, SupportBotComponent],
  template: `
    <div class="h-screen overflow-y-auto bg-[#020617] text-white flex items-center justify-center relative font-['Outfit']">
      
      <!-- Animated Background -->
      <div class="absolute inset-0 overflow-hidden pointer-events-none">
         <div class="absolute top-0 left-0 w-full h-full bg-[radial-gradient(ellipse_at_top,_var(--tw-gradient-stops))] from-slate-900 via-[#020617] to-[#020617]"></div>
         <div class="absolute -top-[20%] -right-[20%] w-[800px] h-[800px] bg-cyan-500/10 rounded-full blur-[100px] animate-pulse-slow"></div>
         <div class="absolute bottom-0 left-0 w-[600px] h-[600px] bg-purple-600/10 rounded-full blur-[100px]"></div>
         <div class="absolute inset-0 bg-grid opacity-10"></div>
      </div>

      <button (click)="onBack.emit()" class="absolute top-8 left-8 text-slate-400 hover:text-white flex items-center gap-2 transition z-20 group">
          <span class="material-icons-round group-hover:-translate-x-1 transition">arrow_back</span>
          <span class="font-medium">Wróć</span>
      </button>

      <!-- Glass Card -->
      <div class="w-full max-w-md mx-4 bg-[#0B1121]/80 backdrop-blur-2xl border border-white/10 rounded-3xl shadow-2xl relative z-10 animate-scale-in flex flex-col overflow-hidden">
         
         @if(firebase.demoMode()) {
            <div class="bg-amber-500/10 text-amber-500 text-xs text-center py-2 border-b border-amber-500/20 font-bold tracking-wider">
               TRYB DEMO (OFFLINE)
            </div>
         }

         <!-- Header -->
         <div class="p-8 pb-0 text-center">
            <div class="w-16 h-16 bg-gradient-to-br from-cyan-400 to-blue-600 rounded-2xl mx-auto mb-6 flex items-center justify-center shadow-lg shadow-cyan-900/50">
               <span class="material-icons-round text-3xl text-white">cloud_circle</span>
            </div>
            <h2 class="text-2xl font-bold text-white mb-2">
               {{ mode() === 'login' ? 'Logowanie' : 'Rejestracja' }}
            </h2>
            <p class="text-slate-400 text-sm">
               Uzyskaj dostęp do swojego systemu Nebula.
            </p>
         </div>

         <!-- Tabs -->
         <div class="flex p-2 m-8 mb-4 bg-[#020617] rounded-xl border border-white/5">
            <button (click)="setMode('login')" class="flex-1 py-2 text-sm font-bold rounded-lg transition" [ngClass]="mode() === 'login' ? 'bg-[#1E293B] text-white shadow' : 'text-slate-500 hover:text-slate-300'">Logowanie</button>
            <button (click)="setMode('register')" class="flex-1 py-2 text-sm font-bold rounded-lg transition" [ngClass]="mode() === 'register' ? 'bg-[#1E293B] text-white shadow' : 'text-slate-500 hover:text-slate-300'">Rejestracja</button>
         </div>

         <!-- Forms Container -->
         <div class="p-8 pt-2">
            
            <!-- LOGIN FORM -->
            @if (mode() === 'login') {
               <form [formGroup]="loginForm" (ngSubmit)="onLogin()" class="space-y-4 animate-fade-in">
                  <div class="space-y-1">
                     <label class="text-[10px] font-bold text-slate-500 uppercase tracking-widest pl-1">Login / Email</label>
                     <input formControlName="email" type="text" class="w-full bg-[#020617] border border-white/10 rounded-xl px-4 py-3 text-white focus:border-cyan-500 focus:ring-1 focus:ring-cyan-500 outline-none transition placeholder-slate-700">
                  </div>
                  
                  <div class="space-y-1">
                     <label class="text-[10px] font-bold text-slate-500 uppercase tracking-widest pl-1">Hasło</label>
                     <div class="relative">
                        <input [type]="showPassword() ? 'text' : 'password'" formControlName="password" class="w-full bg-[#020617] border border-white/10 rounded-xl px-4 py-3 text-white focus:border-cyan-500 focus:ring-1 focus:ring-cyan-500 outline-none transition placeholder-slate-700">
                        <button type="button" (click)="togglePassword()" class="absolute right-3 top-3 text-slate-500 hover:text-white">
                           <span class="material-icons-round text-lg">{{ showPassword() ? 'visibility_off' : 'visibility' }}</span>
                        </button>
                     </div>
                  </div>

                  <button type="submit" [disabled]="isLoginLoading() || loginForm.invalid" class="w-full py-3 bg-gradient-to-r from-cyan-600 to-blue-600 text-white font-bold rounded-xl hover:brightness-110 transition disabled:opacity-50 disabled:cursor-not-allowed shadow-lg shadow-cyan-900/20 mt-2">
                     {{ isLoginLoading() ? 'Weryfikacja...' : 'Zaloguj się' }}
                  </button>
               </form>
            }

            <!-- REGISTER FORM -->
            @if (mode() === 'register') {
               <form [formGroup]="registerForm" (ngSubmit)="onRegister()" class="space-y-4 animate-fade-in">
                  <div class="space-y-1">
                     <label class="text-[10px] font-bold text-slate-500 uppercase tracking-widest pl-1">Imię / Nazwa</label>
                     <input formControlName="name" type="text" class="w-full bg-[#020617] border border-white/10 rounded-xl px-4 py-3 text-white focus:border-purple-500 outline-none transition">
                  </div>
                  <div class="space-y-1">
                     <label class="text-[10px] font-bold text-slate-500 uppercase tracking-widest pl-1">Login / Email</label>
                     <input formControlName="email" type="text" class="w-full bg-[#020617] border border-white/10 rounded-xl px-4 py-3 text-white focus:border-purple-500 outline-none transition">
                  </div>
                  <div class="space-y-1">
                     <label class="text-[10px] font-bold text-slate-500 uppercase tracking-widest pl-1">Hasło</label>
                     <input formControlName="password" [type]="showPassword() ? 'text' : 'password'" class="w-full bg-[#020617] border border-white/10 rounded-xl px-4 py-3 text-white focus:border-purple-500 outline-none transition">
                  </div>
                  <button type="submit" [disabled]="registerForm.invalid || isLoginLoading()" class="w-full py-3 bg-gradient-to-r from-purple-600 to-pink-600 text-white font-bold rounded-xl hover:brightness-110 transition shadow-lg shadow-purple-900/20 mt-2">
                     {{ isLoginLoading() ? 'Tworzenie konta...' : 'Zarejestruj się' }}
                  </button>
               </form>
            }
            
            @if (errorMessage()) {
               <div class="mt-4 p-3 bg-red-500/10 border border-red-500/20 rounded-xl flex items-start gap-2 text-red-400 text-xs animate-fade-in">
                  <span class="material-icons-round text-sm mt-0.5">error</span>
                  <span>{{ errorMessage() }}</span>
               </div>
            }

            <!-- Admin Setup Button -->
            <div class="mt-6 pt-4 border-t border-white/5 text-center">
               <button (click)="createDefaultAdmin()" [disabled]="isLoginLoading()" 
                  class="text-xs text-slate-500 hover:text-cyan-400 transition underline disabled:opacity-50">
                   Skonfiguruj Admina (gonzok17)
               </button>
            </div>
         </div>
      </div>
      
      <app-support-bot></app-support-bot>
    </div>
  `,
  styles: [`
    .animate-fade-in { animation: fadeIn 0.4s ease-out; }
    @keyframes fadeIn { from { opacity: 0; transform: translateY(10px); } to { opacity: 1; transform: translateY(0); } }
    .bg-grid { background-image: radial-gradient(rgba(255,255,255,0.1) 1px, transparent 1px); background-size: 20px 20px; }
  `]
})
export class AuthComponent implements OnInit {
  @Input() initialMode: 'login' | 'register' = 'login';
  @Output() onBack = new EventEmitter<void>();

  public firebase = inject(FirebaseService);
  private dataService = inject(DataService); // Inject DataService for forceLogin
  private fb = inject(FormBuilder);

  mode = signal<'login' | 'register'>('login');
  isGoogleLoading = signal(false);
  isLoginLoading = signal(false);
  showPassword = signal(false);
  errorMessage = signal<string | null>(null);
  
  legalContent = LEGAL_CONTENT; 

  loginForm: FormGroup;
  registerForm: FormGroup;

  constructor() {
    // Removed Validators.email to allow simple username "gonzok17"
    this.loginForm = this.fb.group({
      email: ['', [Validators.required]], 
      password: ['', Validators.required]
    });
    
    this.registerForm = this.fb.group({
      name: ['', Validators.required],
      email: ['', [Validators.required]],
      password: ['', [Validators.required, Validators.minLength(6)]]
    });
  }
  
  ngOnInit() {
    if (this.initialMode === 'register') {
      this.mode.set('register');
    }
  }

  setMode(m: 'login' | 'register') {
    this.mode.set(m);
    this.errorMessage.set(null);
  }

  togglePassword() {
    this.showPassword.update(v => !v);
  }

  // Helper to normalize input (handle strict gonzok17 logic)
  private normalizeEmail(input: string): string {
    const trimmed = input.trim();
    if (trimmed === 'gonzok17') {
        return 'gonzok17@nebula.admin';
    }
    return trimmed;
  }

  async onLogin() {
    if (this.loginForm.invalid) return;
    this.isLoginLoading.set(true);
    this.errorMessage.set(null);
    try {
        const email = this.normalizeEmail(this.loginForm.value.email);
        await this.firebase.loginEmail(email, this.loginForm.value.password);
    } catch(e: any) {
        // ERROR HANDLING & BYPASS FOR IDENTITY TOOLKIT
        if (this.isIdentityError(e)) {
            // Force login locally if API is not enabled
            this.dataService.forceLogin(this.loginForm.value.email);
        } else {
            this.errorMessage.set(this.mapError(e.code));
        }
    } finally {
        this.isLoginLoading.set(false);
    }
  }

  async onRegister() {
    if (this.registerForm.invalid) return;
    this.isLoginLoading.set(true);
    this.errorMessage.set(null);
    try {
        const email = this.normalizeEmail(this.registerForm.value.email);
        await this.firebase.registerEmail(
            email, 
            this.registerForm.value.password,
            this.registerForm.value.name
        );
    } catch(e: any) {
        // ERROR HANDLING & BYPASS FOR IDENTITY TOOLKIT
        if (this.isIdentityError(e)) {
            this.dataService.forceLogin(this.registerForm.value.email);
        } else {
            this.errorMessage.set(this.mapError(e.code));
        }
    } finally {
        this.isLoginLoading.set(false);
    }
  }

  // Helper to detect critical config errors
  private isIdentityError(e: any): boolean {
     const str = e.message || e.code || '';
     return str.includes('identity-toolkit') || str.includes('project') || str.includes('disabled');
  }

  // --- Admin Setup Helper ---
  async createDefaultAdmin() {
    const login = 'gonzok17';
    const pass = 'admin123';
    const email = 'gonzok17@nebula.admin';
    
    // Visually show just the username
    this.loginForm.patchValue({ email: login, password: pass });
    this.registerForm.patchValue({ email: login, password: pass, name: 'Administrator Gonzok' });
    
    this.isLoginLoading.set(true);
    this.errorMessage.set(null);

    try {
        // Attempt to register first using the FULL email
        await this.firebase.registerEmail(email, pass, 'Administrator Gonzok');
    } catch(e: any) {
        // IF API IS DISABLED, FORCE LOGIN DIRECTLY
        if (this.isIdentityError(e)) {
             this.dataService.forceLogin(login);
             this.isLoginLoading.set(false);
             return;
        }

        if (e.code === 'auth/email-already-in-use') {
            // If already exists, try logging in
            try {
                await this.firebase.loginEmail(email, pass);
            } catch (loginErr: any) {
                if (this.isIdentityError(loginErr)) {
                     this.dataService.forceLogin(login);
                } else {
                     this.errorMessage.set(this.mapError(loginErr.code));
                }
            }
        } else {
            this.errorMessage.set(this.mapError(e.code));
        }
    } finally {
        this.isLoginLoading.set(false);
    }
  }

  private mapError(code: string): string {
     switch(code) {
        case 'auth/invalid-credential': return 'Nieprawidłowy login lub hasło.';
        case 'auth/user-not-found': return 'Konto nie istnieje.';
        case 'auth/wrong-password': return 'Nieprawidłowe hasło.';
        case 'auth/email-already-in-use': return 'Ten login jest już zajęty.';
        case 'auth/invalid-email': return 'Nieprawidłowy format (dla admina wpisz "gonzok17").';
        case 'auth/popup-closed-by-user': return 'Logowanie anulowane przez użytkownika.';
        case 'auth/operation-not-allowed': return 'Logowanie Google nie jest włączone w konsoli Firebase.';
        case 'auth/popup-blocked': return 'Przeglądarka zablokowała okno logowania.';
        case 'auth/api-key-not-valid': return 'Nieprawidłowy klucz API w konfiguracji.';
        default: return 'Wystąpił nieznany błąd logowania: ' + code;
     }
  }
}