import { Component, ElementRef, inject, ViewChild, AfterViewInit, signal, effect, OnDestroy } from '@angular/core';
import { CommonModule } from '@angular/common';
import { DataService } from '../services/data.service';
import { GeminiService, GraphData, GraphNode } from '../services/gemini.service';
import { NotificationService } from '../services/notification.service';
import * as d3 from 'd3';

@Component({
  selector: 'app-mind-map',
  standalone: true,
  imports: [CommonModule],
  template: `
    <div class="flex flex-col h-full bg-slate-900 rounded-3xl shadow-sm border border-slate-700 overflow-hidden relative group">
      
      <!-- Graph Canvas -->
      <div class="flex-1 relative overflow-hidden cursor-move bg-gradient-to-br from-[#020617] to-[#0f172a]" #graphContainer>
         <div class="absolute inset-0 bg-grid opacity-20 pointer-events-none"></div>
         <!-- D3 SVG will be appended here -->
      </div>

      <!-- Floating Controls -->
      <div class="absolute bottom-6 left-1/2 -translate-x-1/2 flex items-center gap-4 bg-black/60 backdrop-blur-md p-2 rounded-2xl border border-white/10 shadow-2xl z-20">
         <button (click)="generateGraph()" [disabled]="isGenerating()" 
            class="px-6 py-3 bg-cyan-600 hover:bg-cyan-500 text-white rounded-xl font-bold transition flex items-center gap-2 shadow-lg shadow-cyan-900/40 disabled:opacity-50 disabled:cursor-wait">
            @if (isGenerating()) {
              <span class="material-icons-round animate-spin">sync</span> Generowanie...
            } @else {
              <span class="material-icons-round">auto_awesome</span> Nebula Mind
            }
         </button>
         
         <div class="h-8 w-[1px] bg-white/20"></div>

         <div class="flex gap-2">
            <button (click)="zoomIn()" class="w-10 h-10 rounded-xl bg-white/5 hover:bg-white/10 text-white flex items-center justify-center transition">
               <span class="material-icons-round">add</span>
            </button>
            <button (click)="zoomOut()" class="w-10 h-10 rounded-xl bg-white/5 hover:bg-white/10 text-white flex items-center justify-center transition">
               <span class="material-icons-round">remove</span>
            </button>
            <button (click)="resetZoom()" class="w-10 h-10 rounded-xl bg-white/5 hover:bg-white/10 text-white flex items-center justify-center transition" title="Centruj">
               <span class="material-icons-round">center_focus_strong</span>
            </button>
         </div>
      </div>

      <!-- Info Overlay -->
      @if (!hasGraphData() && !isGenerating()) {
         <div class="absolute inset-0 flex items-center justify-center pointer-events-none z-10">
            <div class="text-center p-8 max-w-md animate-fade-in">
               <div class="w-20 h-20 bg-cyan-500/10 rounded-full flex items-center justify-center mx-auto mb-6 border border-cyan-500/30">
                  <span class="material-icons-round text-4xl text-cyan-400">hub</span>
               </div>
               <h3 class="text-2xl font-bold text-white mb-2">Wizualizacja Wiedzy</h3>
               <p class="text-slate-400">
                  Kliknij "Nebula Mind", aby AI przeanalizowała Twoje pliki i stworzyła mapę powiązań między nimi.
               </p>
            </div>
         </div>
      }
    </div>
  `,
  styles: [`
    .bg-grid {
      background-size: 40px 40px;
      background-image: linear-gradient(to right, rgba(255, 255, 255, 0.05) 1px, transparent 1px),
                        linear-gradient(to bottom, rgba(255, 255, 255, 0.05) 1px, transparent 1px);
    }
    .animate-fade-in { animation: fadeIn 0.5s ease-out; }
    @keyframes fadeIn { from { opacity: 0; transform: translateY(10px); } to { opacity: 1; transform: translateY(0); } }
  `]
})
export class MindMapComponent implements AfterViewInit, OnDestroy {
  @ViewChild('graphContainer') graphContainer!: ElementRef;
  
  private dataService = inject(DataService);
  private geminiService = inject(GeminiService);
  private notificationService = inject(NotificationService);

  isGenerating = signal(false);
  hasGraphData = signal(false);
  
  private svg: any;
  private simulation: any;
  private g: any; // Group for zoom
  private zoom: any;

  private width = 0;
  private height = 0;

  ngAfterViewInit() {
    this.initGraph();
    window.addEventListener('resize', this.onResize.bind(this));
  }

  ngOnDestroy() {
    window.removeEventListener('resize', this.onResize.bind(this));
    if (this.simulation) this.simulation.stop();
  }

  onResize() {
     if (!this.graphContainer) return;
     this.width = this.graphContainer.nativeElement.clientWidth;
     this.height = this.graphContainer.nativeElement.clientHeight;
     if (this.svg) {
        this.svg.attr("width", this.width).attr("height", this.height);
        if (this.simulation) {
           this.simulation.force("center", d3.forceCenter(this.width / 2, this.height / 2));
           this.simulation.alpha(0.3).restart();
        }
     }
  }

  initGraph() {
    const el = this.graphContainer.nativeElement;
    this.width = el.clientWidth;
    this.height = el.clientHeight;

    this.svg = d3.select(el).append('svg')
      .attr('width', this.width)
      .attr('height', this.height)
      .attr('class', 'w-full h-full');

    this.g = this.svg.append('g');

    this.zoom = d3.zoom()
      .scaleExtent([0.1, 4])
      .on('zoom', (event) => {
        this.g.attr('transform', event.transform);
      });

    this.svg.call(this.zoom);
  }

  async generateGraph() {
    const files = this.dataService.items().filter(i => i.type === 'file');
    
    if (files.length < 2) {
       this.notificationService.show('Potrzebujesz co najmniej 2 plików, aby wygenerować mapę.', 'warning');
       return;
    }

    this.isGenerating.set(true);
    const fileNames = files.map(f => f.name);

    // Call Gemini
    const graphData = await this.geminiService.generateKnowledgeGraph(fileNames);
    
    this.isGenerating.set(false);

    if (graphData) {
      this.hasGraphData.set(true);
      this.renderGraph(graphData);
      this.notificationService.show('Mapa myśli wygenerowana.', 'success');
    } else {
      this.notificationService.show('Nie udało się wygenerować mapy.', 'error');
    }
  }

  renderGraph(data: GraphData) {
    if (this.simulation) this.simulation.stop();
    this.g.selectAll("*").remove(); // Clear previous

    // Color scale based on node type
    const getNodeColor = (d: GraphNode) => {
       if (d.type === 'concept') return '#9333ea'; // Purple
       return '#06b6d4'; // Cyan for files
    };

    const getNodeRadius = (d: GraphNode) => d.type === 'concept' ? 25 : 15;

    // Forces
    this.simulation = d3.forceSimulation(data.nodes as any)
        .force("link", d3.forceLink(data.links).id((d: any) => d.id).distance(150))
        .force("charge", d3.forceManyBody().strength(-400))
        .force("center", d3.forceCenter(this.width / 2, this.height / 2))
        .force("collide", d3.forceCollide().radius(40));

    // Links
    const link = this.g.append("g")
        .attr("stroke", "#ffffff")
        .attr("stroke-opacity", 0.2)
        .selectAll("line")
        .data(data.links)
        .join("line")
        .attr("stroke-width", 1.5);

    // Node Group
    const node = this.g.append("g")
        .selectAll("g")
        .data(data.nodes)
        .join("g")
        .call(d3.drag()
            .on("start", (event, d) => this.dragstarted(event, d))
            .on("drag", (event, d) => this.dragged(event, d))
            .on("end", (event, d) => this.dragended(event, d)));

    // Node Circles
    node.append("circle")
        .attr("r", (d: any) => getNodeRadius(d))
        .attr("fill", (d: any) => getNodeColor(d))
        .attr("stroke", "#fff")
        .attr("stroke-width", 2)
        .attr("class", "cursor-pointer transition hover:opacity-80 shadow-lg");

    // Glow effect for concepts
    node.filter((d: any) => d.type === 'concept')
        .append("circle")
        .attr("r", 35)
        .attr("fill", "none")
        .attr("stroke", "#9333ea")
        .attr("stroke-opacity", 0.3)
        .attr("stroke-width", 1)
        .attr("class", "animate-pulse");

    // Labels
    node.append("text")
        .text((d: any) => d.label)
        .attr("x", (d: any) => getNodeRadius(d) + 8)
        .attr("y", 4)
        .attr("fill", "#e2e8f0")
        .attr("font-size", (d: any) => d.type === 'concept' ? "14px" : "12px")
        .attr("font-weight", (d: any) => d.type === 'concept' ? "bold" : "normal")
        .style("pointer-events", "none")
        .style("text-shadow", "0 2px 4px rgba(0,0,0,0.8)");

    // Icons inside nodes
    node.append("text")
        .attr("class", "material-icons-round")
        .attr("text-anchor", "middle")
        .attr("dominant-baseline", "central")
        .attr("fill", "white")
        .attr("font-size", (d: any) => d.type === 'concept' ? "20px" : "14px")
        .style("pointer-events", "none")
        .text((d: any) => d.type === 'concept' ? 'auto_awesome' : 'description');


    this.simulation.on("tick", () => {
        link
            .attr("x1", (d: any) => d.source.x)
            .attr("y1", (d: any) => d.source.y)
            .attr("x2", (d: any) => d.target.x)
            .attr("y2", (d: any) => d.target.y);

        node
            .attr("transform", (d: any) => `translate(${d.x},${d.y})`);
    });
  }

  // Drag functions
  dragstarted(event: any, d: any) {
    if (!event.active) this.simulation.alphaTarget(0.3).restart();
    d.fx = d.x;
    d.fy = d.y;
  }

  dragged(event: any, d: any) {
    d.fx = event.x;
    d.fy = event.y;
  }

  dragended(event: any, d: any) {
    if (!event.active) this.simulation.alphaTarget(0);
    d.fx = null;
    d.fy = null;
  }

  zoomIn() {
    this.svg.transition().call(this.zoom.scaleBy, 1.2);
  }

  zoomOut() {
    this.svg.transition().call(this.zoom.scaleBy, 0.8);
  }

  resetZoom() {
    this.svg.transition().call(this.zoom.transform, d3.zoomIdentity);
  }
}