import { Component, inject, signal, computed, effect } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormBuilder, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { DataService, User } from '../services/data.service';
import { NotificationService } from '../services/notification.service';
import { CloudService } from '../services/cloud.service';

@Component({
  selector: 'app-settings',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule],
  template: `
    <div class="flex flex-col h-full bg-white rounded-3xl shadow-sm border border-slate-200 overflow-hidden relative" [ngClass]="{'bg-slate-900 border-slate-700 text-white': isDark(), 'bg-white border-slate-200': !isDark()}">
      
      <!-- Header -->
      <div class="p-6 border-b flex items-center gap-4 transition-colors duration-300" [ngClass]="{'border-slate-700 bg-slate-900': isDark(), 'border-slate-100 bg-white': !isDark()}">
        <div class="w-12 h-12 rounded-2xl flex items-center justify-center text-white shadow-lg transition-colors duration-300"
             [style.background-color]="currentUser()?.preferences?.accentHex || '#06b6d4'">
           <span class="material-icons-round text-2xl">tune</span>
        </div>
        <div>
           <h2 class="text-2xl font-bold tracking-tight">Ustawienia</h2>
           <p class="text-sm opacity-60">Dostosuj Nebula do swojego stylu</p>
        </div>
      </div>

      <div class="flex flex-1 overflow-hidden">
        
        <!-- Sidebar Tabs -->
        <div class="w-64 border-r p-4 space-y-2 hidden md:block" [ngClass]="{'border-slate-700 bg-slate-800/30': isDark(), 'border-slate-100 bg-slate-50': !isDark()}">
           <button (click)="activeTab = 'profile'" [class]="getTabClass('profile')">
              <span class="material-icons-round">person</span> Profil
           </button>
           <button (click)="activeTab = 'appearance'" [class]="getTabClass('appearance')">
              <span class="material-icons-round">palette</span> Wygląd
           </button>
           <button (click)="activeTab = 'cloud'" [class]="getTabClass('cloud')">
              <span class="material-icons-round">cloud_sync</span> Chmura & Google
           </button>
           <button (click)="activeTab = 'security'" [class]="getTabClass('security')">
              <span class="material-icons-round">security</span> Bezpieczeństwo
           </button>
        </div>

        <!-- Content -->
        <div class="flex-1 overflow-y-auto p-6 md:p-8 relative">
           
           <!-- Mobile Tabs (Top) -->
           <div class="md:hidden flex gap-2 mb-6 overflow-x-auto pb-2">
              <button (click)="activeTab = 'profile'" [class]="getTabClass('profile', true)">Profil</button>
              <button (click)="activeTab = 'appearance'" [class]="getTabClass('appearance', true)">Wygląd</button>
              <button (click)="activeTab = 'cloud'" [class]="getTabClass('cloud', true)">Chmura</button>
              <button (click)="activeTab = 'security'" [class]="getTabClass('security', true)">Bezpieczeństwo</button>
           </div>

           <!-- PROFILE TAB (Two Column Layout) -->
           @if (activeTab === 'profile') {
              <div class="max-w-4xl animate-fade-in">
                 <div class="grid grid-cols-1 md:grid-cols-3 gap-8">
                    
                    <!-- Column 1: Visual Card (Avatar & Summary) -->
                    <div class="md:col-span-1">
                       <div class="border rounded-3xl p-6 flex flex-col items-center text-center shadow-sm sticky top-0" 
                            [ngClass]="{'bg-slate-800/30 border-slate-700': isDark(), 'bg-slate-50 border-slate-200': !isDark()}">
                          
                          <div class="relative group mb-4">
                             <img [src]="currentUser()?.avatarUrl || 'https://ui-avatars.com/api/?name=' + currentUser()?.name + '&background=random'" 
                                  class="w-32 h-32 rounded-full object-cover ring-4 shadow-xl transition transform group-hover:scale-105"
                                  [style.ring-color]="currentUser()?.preferences?.accentHex">
                             
                             <!-- Upload Overlay -->
                             <button (click)="fileInput.click()" class="absolute inset-0 bg-black/40 rounded-full flex items-center justify-center opacity-0 group-hover:opacity-100 transition cursor-pointer backdrop-blur-sm">
                                <span class="material-icons-round text-white text-3xl">photo_camera</span>
                             </button>
                          </div>
                          
                          <h3 class="font-bold text-xl truncate w-full mb-1">{{ currentUser()?.name }}</h3>
                          <p class="text-sm opacity-60 mb-6 truncate w-full">{{ currentUser()?.email }}</p>

                          <input #fileInput type="file" hidden (change)="onAvatarSelected($event)" accept="image/*">
                          
                          <div class="w-full space-y-2">
                            <button (click)="fileInput.click()" class="w-full py-2.5 rounded-xl border font-bold text-xs transition uppercase tracking-wider flex items-center justify-center gap-2"
                               [ngClass]="{'border-white/20 hover:bg-white/10': isDark(), 'border-slate-300 hover:bg-slate-100': !isDark()}">
                               <span class="material-icons-round text-sm">upload</span> Zmień zdjęcie
                            </button>
                          </div>
                       </div>
                    </div>

                    <!-- Column 2: Edit Form -->
                    <div class="md:col-span-2">
                       <div class="rounded-3xl border p-6 md:p-8 shadow-sm" [ngClass]="{'border-slate-700 bg-slate-800/20': isDark(), 'border-slate-100 bg-white': !isDark()}"> 
                         <h3 class="font-bold text-lg mb-6 flex items-center gap-2 opacity-80 border-b pb-4" [ngClass]="isDark() ? 'border-slate-700' : 'border-slate-100'">
                            <span class="material-icons-round">edit_note</span> 
                            Dane Osobowe
                         </h3>

                         <form [formGroup]="profileForm" (ngSubmit)="saveProfile()" class="space-y-6">
                            <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                               <div class="space-y-2">
                                  <label class="text-xs font-bold uppercase tracking-wider opacity-60">Imię</label>
                                  <input formControlName="firstName" class="w-full px-4 py-3 rounded-xl border bg-transparent outline-none transition focus:ring-2"
                                     [ngClass]="getInputClass()">
                               </div>
                               <div class="space-y-2">
                                  <label class="text-xs font-bold uppercase tracking-wider opacity-60">Nazwisko</label>
                                  <input formControlName="lastName" class="w-full px-4 py-3 rounded-xl border bg-transparent outline-none transition focus:ring-2"
                                     [ngClass]="getInputClass()">
                               </div>
                            </div>

                            <div class="space-y-2">
                                <label class="text-xs font-bold uppercase tracking-wider opacity-60">Wyświetlana nazwa (Nick)</label>
                                <input formControlName="nickname" class="w-full px-4 py-3 rounded-xl border bg-transparent outline-none transition focus:ring-2"
                                     [ngClass]="getInputClass()">
                            </div>
                            
                            <!-- Role Badge (Read Only) -->
                             <div class="space-y-2 opacity-70">
                                <label class="text-xs font-bold uppercase tracking-wider opacity-60">Rola w systemie</label>
                                <div class="w-full px-4 py-3 rounded-xl border bg-slate-100/50 flex items-center gap-2" [ngClass]="isDark() ? 'border-slate-700 bg-slate-800' : 'border-slate-200'">
                                   <span class="material-icons-round text-sm">verified_user</span>
                                   <span class="text-sm font-medium">{{ currentUser()?.role | uppercase }}</span>
                                </div>
                            </div>

                            <div class="pt-6 flex justify-end">
                               <button type="submit" [disabled]="profileForm.invalid || profileForm.pristine" 
                                  class="px-8 py-3 rounded-xl font-bold text-white shadow-lg transition hover:-translate-y-1 active:translate-y-0 disabled:opacity-50 disabled:transform-none flex items-center gap-2"
                                  [style.background-color]="currentUser()?.preferences?.accentHex">
                                  <span class="material-icons-round">save</span>
                                  Zapisz Zmiany
                               </button>
                            </div>
                         </form>
                       </div>
                    </div>

                 </div>
              </div>
           }

           <!-- APPEARANCE TAB -->
           @if (activeTab === 'appearance') {
              <div class="max-w-2xl animate-fade-in space-y-10">
                 
                 <!-- Theme Toggle -->
                 <div class="flex items-center justify-between p-6 rounded-2xl border" [ngClass]="{'border-slate-700 bg-slate-800/50': isDark(), 'border-slate-200 bg-slate-50': !isDark()}">
                    <div class="flex items-center gap-4">
                       <div class="w-12 h-12 rounded-full flex items-center justify-center transition" [ngClass]="isDark() ? 'bg-slate-700 text-yellow-400' : 'bg-white text-slate-800 shadow-sm'">
                          <span class="material-icons-round text-2xl">{{ isDark() ? 'dark_mode' : 'light_mode' }}</span>
                       </div>
                       <div>
                          <h3 class="font-bold text-lg">Tryb Nocny</h3>
                          <p class="text-sm opacity-60">Przełącz między jasnym a ciemnym interfejsem.</p>
                       </div>
                    </div>
                    <button (click)="toggleTheme()" class="w-16 h-8 rounded-full relative transition duration-300"
                            [style.background-color]="isDark() ? currentUser()?.preferences?.accentHex : '#cbd5e1'">
                       <div class="absolute top-1 bottom-1 bg-white rounded-full w-6 shadow-md transition-all duration-300"
                            [style.left.px]="isDark() ? 36 : 4"></div>
                    </button>
                 </div>

                 <!-- Color Picker -->
                 <div>
                    <h3 class="font-bold text-lg mb-4">Kolor Akcentu</h3>
                    <div class="grid grid-cols-2 md:grid-cols-5 gap-4">
                       @for (color of colors; track color.hex) {
                          <button (click)="setAccent(color)" 
                             class="group relative h-24 rounded-2xl border flex flex-col items-center justify-center gap-2 transition hover:scale-105"
                             [ngClass]="{'border-white/20': isDark(), 'border-slate-200': !isDark(), 'ring-2 ring-offset-2 ring-offset-slate-900': isDark() && currentUser()?.preferences?.accentHex === color.hex, 'ring-2 ring-offset-2 ring-offset-white': !isDark() && currentUser()?.preferences?.accentHex === color.hex}"
                             [style.background]="isDark() ? 'rgba('+color.rgb+', 0.1)' : 'rgba('+color.rgb+', 0.05)'">
                             
                             <div class="w-8 h-8 rounded-full shadow-lg" [style.background-color]="color.hex"></div>
                             <span class="text-xs font-bold uppercase tracking-wider opacity-80">{{ color.name }}</span>
                             
                             @if (currentUser()?.preferences?.accentHex === color.hex) {
                                <div class="absolute top-2 right-2 text-xs bg-white text-black px-1.5 rounded-md font-bold">ON</div>
                             }
                          </button>
                       }
                    </div>
                 </div>

                 <!-- Reduced Motion -->
                 <div class="flex items-center gap-3 opacity-80">
                    <input type="checkbox" id="motion" [checked]="currentUser()?.preferences?.reduceMotion" (change)="toggleMotion()" class="w-5 h-5 rounded border-gray-300 text-cyan-600 focus:ring-cyan-500">
                    <label for="motion" class="text-sm font-medium">Redukuj animacje (Dla wyższej wydajności)</label>
                 </div>

              </div>
           }

           <!-- CLOUD TAB -->
           @if (activeTab === 'cloud') {
              <div class="max-w-2xl animate-fade-in space-y-8">
                
                <div class="p-6 rounded-2xl border flex items-center justify-between"
                   [ngClass]="{'border-slate-700 bg-slate-800/50': isDark(), 'border-slate-200 bg-slate-50': !isDark()}">
                   <div>
                     <h3 class="font-bold text-lg mb-1">Status Chmury Nebula</h3>
                     <div class="flex items-center gap-2">
                       <span class="w-2 h-2 rounded-full" [class.bg-green-500]="cloudStatus().online" [class.bg-red-500]="!cloudStatus().online"></span>
                       <span class="text-sm font-medium opacity-80">{{ cloudStatus().online ? 'Online' : 'Offline' }}</span>
                     </div>
                   </div>
                   <button (click)="cloudService.syncData()" class="p-3 rounded-xl bg-white/10 hover:bg-white/20 transition" title="Wymuś synchronizację">
                     <span class="material-icons-round" [class.animate-spin]="cloudStatus().syncing">sync</span>
                   </button>
                </div>

                <!-- Google Integration Hidden due to dev mode -->
                <!-- 
                <div class="p-6 rounded-2xl border" 
                     [ngClass]="{'border-slate-700 bg-slate-800/50': isDark(), 'border-slate-200 bg-white': !isDark()}">
                     ...
                </div>
                -->
                
                <div class="p-4 bg-amber-50 border border-amber-200 rounded-xl text-amber-800 text-sm">
                   <p class="font-bold flex items-center gap-2"><span class="material-icons-round text-sm">info</span> Integracja Google Drive</p>
                   <p class="mt-1">Ta funkcja jest tymczasowo wyłączona ze względów bezpieczeństwa (brak weryfikacji domeny).</p>
                </div>

              </div>
           }

           <!-- SECURITY TAB -->
           @if (activeTab === 'security') {
              <div class="max-w-2xl animate-fade-in space-y-8">
                 
                 <div class="p-4 rounded-xl border-l-4 border-yellow-500 bg-yellow-500/10 mb-6">
                    <p class="text-sm font-medium opacity-90 flex items-center gap-2">
                       <span class="material-icons-round text-yellow-500">warning</span>
                       Zmiany w tej sekcji wymagają ponownego zalogowania dla bezpieczeństwa.
                    </p>
                 </div>

                 <form [formGroup]="securityForm" (ngSubmit)="updateSecurity()" class="space-y-6">
                    <div class="space-y-2">
                       <label class="text-xs font-bold uppercase tracking-wider opacity-60">Adres Email</label>
                       <input formControlName="email" type="email" class="w-full px-4 py-3 rounded-xl border bg-transparent outline-none transition focus:ring-2"
                          [ngClass]="getInputClass()">
                    </div>

                    <div class="space-y-2">
                       <label class="text-xs font-bold uppercase tracking-wider opacity-60">Numer Telefonu</label>
                       <input formControlName="phone" type="tel" class="w-full px-4 py-3 rounded-xl border bg-transparent outline-none transition focus:ring-2"
                          [ngClass]="getInputClass()">
                    </div>

                    <div class="pt-6 border-t" [ngClass]="isDark() ? 'border-slate-700' : 'border-slate-200'">
                       <h4 class="font-bold mb-4">Zmiana Hasła</h4>
                       <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                          <div class="space-y-2">
                             <label class="text-xs font-bold uppercase tracking-wider opacity-60">Nowe Hasło</label>
                             <input formControlName="password" type="password" class="w-full px-4 py-3 rounded-xl border bg-transparent outline-none transition focus:ring-2"
                                [ngClass]="getInputClass()">
                          </div>
                          <div class="space-y-2">
                             <label class="text-xs font-bold uppercase tracking-wider opacity-60">Powtórz Hasło</label>
                             <input formControlName="confirmPassword" type="password" class="w-full px-4 py-3 rounded-xl border bg-transparent outline-none transition focus:ring-2"
                                [ngClass]="getInputClass()">
                          </div>
                       </div>
                    </div>

                    <div class="pt-4 flex justify-end">
                       <button type="submit" [disabled]="securityForm.invalid || securityForm.pristine" 
                          class="px-8 py-3 rounded-xl font-bold text-white bg-red-600 hover:bg-red-700 shadow-lg transition disabled:opacity-50">
                          Zaktualizuj Dane
                       </button>
                    </div>
                 </form>
              </div>
           }

        </div>
      </div>
    </div>
  `,
  styles: [`
    .animate-fade-in { animation: fadeIn 0.4s ease-out; }
    @keyframes fadeIn { from { opacity: 0; transform: translateY(10px); } to { opacity: 1; transform: translateY(0); } }
  `]
})
export class SettingsComponent {
  dataService = inject(DataService);
  notificationService = inject(NotificationService);
  cloudService = inject(CloudService); // Inject Cloud Service
  fb = inject(FormBuilder);

  currentUser = this.dataService.currentUser;
  cloudStatus = this.cloudService.status; // Signal for cloud status

  activeTab: 'profile' | 'appearance' | 'security' | 'cloud' = 'profile';
  
  // Theme computed for easier template usage
  isDark = computed(() => this.currentUser()?.preferences.theme === 'dark');

  colors = [
    { name: 'Cyan', hex: '#06b6d4', rgb: '6, 182, 212' },
    { name: 'Purple', hex: '#9333ea', rgb: '147, 51, 234' },
    { name: 'Emerald', hex: '#10b981', rgb: '16, 185, 129' },
    { name: 'Rose', hex: '#f43f5e', rgb: '244, 63, 94' },
    { name: 'Amber', hex: '#f59e0b', rgb: '245, 158, 11' }
  ];

  profileForm: FormGroup;
  securityForm: FormGroup;

  constructor() {
    this.profileForm = this.fb.group({
      firstName: ['', Validators.required],
      lastName: ['', Validators.required],
      nickname: ['']
    });

    this.securityForm = this.fb.group({
      email: ['', [Validators.required, Validators.email]],
      phone: [''],
      password: [''],
      confirmPassword: ['']
    });

    // Populate forms when user loads
    effect(() => {
      const user = this.currentUser();
      if (user) {
        this.profileForm.patchValue({
          firstName: user.firstName,
          lastName: user.lastName,
          nickname: user.nickname
        }, { emitEvent: false }); // Avoid triggering pristine check immediately
        
        this.securityForm.patchValue({
            email: user.email,
            phone: user.phone
        }, { emitEvent: false });
      }
    });
  }

  // --- Google Cloud Logic ---
  async connectGoogle() {
    await this.cloudService.connectGoogleAccount();
  }

  async disconnectGoogle() {
    await this.cloudService.disconnectGoogle();
  }

  // --- Styles Helper ---
  getTabClass(tab: string, mobile = false) {
    const isActive = this.activeTab === tab;
    const base = mobile 
       ? "px-4 py-2 rounded-full text-sm font-bold whitespace-nowrap transition " 
       : "w-full text-left px-4 py-3 rounded-xl flex items-center gap-3 font-medium transition duration-300 ";
    
    if (this.isDark()) {
       return base + (isActive ? 'bg-white/10 text-white' : 'text-slate-400 hover:text-white hover:bg-white/5');
    } else {
       return base + (isActive ? 'bg-slate-200 text-slate-900' : 'text-slate-500 hover:text-slate-900 hover:bg-slate-100');
    }
  }

  getInputClass() {
     return this.isDark() 
        ? 'border-slate-700 bg-slate-800/50 text-white focus:border-white/50 placeholder-slate-500' 
        : 'border-slate-200 bg-slate-50 text-slate-900 focus:border-indigo-500 placeholder-slate-400';
  }

  // --- Logic ---

  toggleTheme() {
    const current = this.currentUser()?.preferences.theme;
    this.dataService.updatePreferences({ theme: current === 'dark' ? 'light' : 'dark' });
  }

  setAccent(color: {name: string, hex: string, rgb: string}) {
    this.dataService.updatePreferences({ accentColor: color.name.toLowerCase(), accentHex: color.hex });
    // Also update CSS variable directly via effect in AppComponent, but we store RGB for glass effects
    document.documentElement.style.setProperty('--primary-rgb', color.rgb);
  }

  toggleMotion() {
    const current = this.currentUser()?.preferences.reduceMotion;
    this.dataService.updatePreferences({ reduceMotion: !current });
  }

  onAvatarSelected(event: Event) {
    const input = event.target as HTMLInputElement;
    if (input.files && input.files[0]) {
      const reader = new FileReader();
      reader.onload = (e) => {
         this.dataService.updateUser({ avatarUrl: e.target?.result as string });
      };
      reader.readAsDataURL(input.files[0]);
    }
  }

  saveProfile() {
    if (this.profileForm.valid) {
       this.dataService.updateUser(this.profileForm.value);
       this.profileForm.markAsPristine();
    }
  }

  updateSecurity() {
     if (this.securityForm.valid) {
        const { password, confirmPassword, ...otherData } = this.securityForm.value;
        
        if (password && password !== confirmPassword) {
           this.notificationService.show('Hasła nie są identyczne', 'error');
           return;
        }

        // Simulating API call
        this.dataService.updateUser(otherData);
        if (password) {
           this.notificationService.show('Hasło zmienione. Wymagane ponowne zalogowanie.', 'warning');
           setTimeout(() => this.dataService.logout(), 2000);
        } else {
           this.securityForm.markAsPristine();
        }
     }
  }
}