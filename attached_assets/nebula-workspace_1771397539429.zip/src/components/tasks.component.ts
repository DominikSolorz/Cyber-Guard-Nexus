import { Component, inject, computed, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { DataService, Task } from '../services/data.service';

@Component({
  selector: 'app-tasks',
  standalone: true,
  imports: [CommonModule, FormsModule],
  template: `
    <div class="h-full flex flex-col p-6 animate-fade-in">
      
      <!-- Header -->
      <div class="flex justify-between items-center mb-6">
         <div>
            <h2 class="text-2xl font-bold text-slate-800">Moje Zadania</h2>
            <p class="text-slate-400 text-sm">Zarządzaj projektami w stylu Kanban</p>
         </div>
         <button (click)="showAddModal = true" class="px-5 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl font-bold shadow-lg shadow-emerald-200 transition flex items-center gap-2">
            <span class="material-icons-round">add</span>
            Nowe Zadanie
         </button>
      </div>

      <!-- Kanban Board -->
      <div class="flex-1 overflow-x-auto">
         <div class="flex gap-6 h-full min-w-[800px]">
            
            <!-- Column: To Do -->
            <div class="flex-1 flex flex-col bg-slate-100 rounded-2xl p-4 border border-slate-200">
               <div class="flex items-center justify-between mb-4 px-2">
                  <h3 class="font-bold text-slate-600 flex items-center gap-2">
                     <span class="w-3 h-3 rounded-full bg-slate-400"></span> Do Zrobienia
                  </h3>
                  <span class="bg-white px-2 py-0.5 rounded-md text-xs font-bold text-slate-400 shadow-sm">{{ todoTasks().length }}</span>
               </div>
               <div class="flex-1 overflow-y-auto space-y-3 custom-scrollbar pr-2">
                  @for (task of todoTasks(); track task.id) {
                     <div class="bg-white p-4 rounded-xl shadow-sm border border-slate-200 hover:shadow-md transition group relative">
                        <div class="flex justify-between items-start mb-2">
                           <span [class]="getPriorityClass(task.priority)">{{ task.priority }}</span>
                           <button (click)="deleteTask(task.id)" class="text-slate-300 hover:text-red-500 opacity-0 group-hover:opacity-100 transition"><span class="material-icons-round text-sm">close</span></button>
                        </div>
                        <p class="font-semibold text-slate-700 mb-3">{{ task.title }}</p>
                        <div class="flex justify-end">
                           <button (click)="moveTask(task.id, 'in-progress')" class="text-xs font-bold text-emerald-600 hover:bg-emerald-50 px-2 py-1 rounded transition flex items-center gap-1">
                              Start <span class="material-icons-round text-sm">arrow_forward</span>
                           </button>
                        </div>
                     </div>
                  }
                  @if (todoTasks().length === 0) {
                     <div class="text-center py-8 text-slate-400 text-sm border-2 border-dashed border-slate-200 rounded-xl">Brak zadań</div>
                  }
               </div>
            </div>

            <!-- Column: In Progress -->
            <div class="flex-1 flex flex-col bg-blue-50/50 rounded-2xl p-4 border border-blue-100">
               <div class="flex items-center justify-between mb-4 px-2">
                  <h3 class="font-bold text-blue-600 flex items-center gap-2">
                     <span class="w-3 h-3 rounded-full bg-blue-500 animate-pulse"></span> W Trakcie
                  </h3>
                  <span class="bg-white px-2 py-0.5 rounded-md text-xs font-bold text-blue-400 shadow-sm">{{ progressTasks().length }}</span>
               </div>
               <div class="flex-1 overflow-y-auto space-y-3 custom-scrollbar pr-2">
                  @for (task of progressTasks(); track task.id) {
                     <div class="bg-white p-4 rounded-xl shadow-sm border-l-4 border-l-blue-500 hover:shadow-md transition group relative">
                        <div class="flex justify-between items-start mb-2">
                           <span [class]="getPriorityClass(task.priority)">{{ task.priority }}</span>
                        </div>
                        <p class="font-semibold text-slate-700 mb-3">{{ task.title }}</p>
                        <div class="flex justify-between items-center border-t pt-2 mt-2 border-slate-50">
                           <button (click)="moveTask(task.id, 'todo')" class="text-xs text-slate-400 hover:text-slate-600"><span class="material-icons-round text-sm">arrow_back</span> Cofnij</button>
                           <button (click)="moveTask(task.id, 'done')" class="text-xs font-bold text-emerald-600 hover:bg-emerald-50 px-2 py-1 rounded transition flex items-center gap-1">
                              Gotowe <span class="material-icons-round text-sm">check</span>
                           </button>
                        </div>
                     </div>
                  }
               </div>
            </div>

            <!-- Column: Done -->
            <div class="flex-1 flex flex-col bg-emerald-50/50 rounded-2xl p-4 border border-emerald-100">
               <div class="flex items-center justify-between mb-4 px-2">
                  <h3 class="font-bold text-emerald-600 flex items-center gap-2">
                     <span class="w-3 h-3 rounded-full bg-emerald-500"></span> Zakończone
                  </h3>
                  <span class="bg-white px-2 py-0.5 rounded-md text-xs font-bold text-emerald-400 shadow-sm">{{ doneTasks().length }}</span>
               </div>
               <div class="flex-1 overflow-y-auto space-y-3 custom-scrollbar pr-2">
                  @for (task of doneTasks(); track task.id) {
                     <div class="bg-white p-4 rounded-xl shadow-sm opacity-60 hover:opacity-100 transition group relative">
                        <div class="flex justify-between items-start mb-2">
                           <span class="bg-slate-100 text-slate-500 text-[10px] px-2 py-0.5 rounded uppercase font-bold tracking-wider">Archiwum</span>
                           <button (click)="deleteTask(task.id)" class="text-slate-300 hover:text-red-500 transition"><span class="material-icons-round text-sm">delete</span></button>
                        </div>
                        <p class="font-semibold text-slate-700 line-through decoration-slate-400">{{ task.title }}</p>
                        <div class="mt-2 text-right">
                            <button (click)="moveTask(task.id, 'in-progress')" class="text-xs text-slate-400 hover:text-blue-500"><span class="material-icons-round text-sm">replay</span> Przywróć</button>
                        </div>
                     </div>
                  }
               </div>
            </div>

         </div>
      </div>

      <!-- Add Modal -->
      @if (showAddModal) {
         <div class="fixed inset-0 z-50 flex items-center justify-center bg-black/40 backdrop-blur-sm p-4 animate-fade-in">
            <div class="bg-white rounded-2xl shadow-2xl w-full max-w-sm p-6 animate-scale-in">
               <h3 class="text-xl font-bold mb-4">Dodaj Zadanie</h3>
               <input [(ngModel)]="newTaskTitle" placeholder="Co trzeba zrobić?" class="w-full border border-slate-200 rounded-xl px-4 py-3 mb-4 focus:ring-2 focus:ring-emerald-500 outline-none">
               <div class="flex gap-2 mb-6">
                  <button (click)="newTaskPriority = 'low'" [class]="newTaskPriority === 'low' ? 'bg-blue-100 text-blue-700 border-blue-200' : 'bg-slate-50 text-slate-500 border-slate-100'" class="flex-1 py-2 rounded-lg text-xs font-bold border transition">LOW</button>
                  <button (click)="newTaskPriority = 'medium'" [class]="newTaskPriority === 'medium' ? 'bg-amber-100 text-amber-700 border-amber-200' : 'bg-slate-50 text-slate-500 border-slate-100'" class="flex-1 py-2 rounded-lg text-xs font-bold border transition">MED</button>
                  <button (click)="newTaskPriority = 'high'" [class]="newTaskPriority === 'high' ? 'bg-red-100 text-red-700 border-red-200' : 'bg-slate-50 text-slate-500 border-slate-100'" class="flex-1 py-2 rounded-lg text-xs font-bold border transition">HIGH</button>
               </div>
               <div class="flex justify-end gap-3">
                  <button (click)="showAddModal = false" class="text-slate-500 font-bold px-4 py-2 hover:bg-slate-50 rounded-lg">Anuluj</button>
                  <button (click)="addTask()" [disabled]="!newTaskTitle.trim()" class="bg-emerald-600 text-white font-bold px-6 py-2 rounded-lg hover:bg-emerald-700 disabled:opacity-50">Dodaj</button>
               </div>
            </div>
         </div>
      }
    </div>
  `,
  styles: [`
    .custom-scrollbar::-webkit-scrollbar { width: 4px; }
    .custom-scrollbar::-webkit-scrollbar-track { background: transparent; }
    .custom-scrollbar::-webkit-scrollbar-thumb { background: #cbd5e1; border-radius: 2px; }
    .animate-fade-in { animation: fadeIn 0.3s ease-out; }
    @keyframes fadeIn { from { opacity: 0; } to { opacity: 1; } }
    @keyframes scaleIn { from { transform: scale(0.95); opacity: 0; } to { transform: scale(1); opacity: 1; } }
    .animate-scale-in { animation: scaleIn 0.2s cubic-bezier(0.16, 1, 0.3, 1); }
  `]
})
export class TasksComponent {
  dataService = inject(DataService);
  tasks = this.dataService.userTasks;

  showAddModal = false;
  newTaskTitle = '';
  newTaskPriority: 'low' | 'medium' | 'high' = 'medium';

  todoTasks = computed(() => this.tasks().filter(t => t.status === 'todo'));
  progressTasks = computed(() => this.tasks().filter(t => t.status === 'in-progress'));
  doneTasks = computed(() => this.tasks().filter(t => t.status === 'done'));

  getPriorityClass(p: string) {
     const base = "text-[10px] px-2 py-0.5 rounded uppercase font-bold tracking-wider ";
     if (p === 'high') return base + "bg-red-100 text-red-600";
     if (p === 'medium') return base + "bg-amber-100 text-amber-600";
     return base + "bg-blue-100 text-blue-600";
  }

  addTask() {
     if (!this.newTaskTitle.trim()) return;
     this.dataService.addTask(this.newTaskTitle, this.newTaskPriority);
     this.newTaskTitle = '';
     this.newTaskPriority = 'medium';
     this.showAddModal = false;
  }

  moveTask(id: string, status: Task['status']) {
     this.dataService.updateTaskStatus(id, status);
  }

  deleteTask(id: string) {
     if(confirm('Usunąć zadanie?')) {
        this.dataService.deleteTask(id);
     }
  }
}