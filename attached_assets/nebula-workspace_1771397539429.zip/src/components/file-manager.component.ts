import { Component, computed, inject, signal, ViewChild, ElementRef } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { DomSanitizer, SafeUrl } from '@angular/platform-browser';
import { DataService, FileItem, SortOption, ViewMode } from '../services/data.service';

@Component({
  selector: 'app-file-manager',
  standalone: true,
  imports: [CommonModule, FormsModule],
  template: `
    <div class="flex flex-col h-full bg-white rounded-3xl shadow-sm border border-slate-200 overflow-hidden relative">
      
      <!-- Toolbar -->
      <div class="px-6 py-5 border-b border-slate-100 flex flex-col md:flex-row md:items-center justify-between gap-4 bg-white z-10">
        
        <!-- Left: Breadcrumbs -->
        <div class="flex flex-col gap-1">
          <nav class="flex items-center text-xs font-bold text-slate-400 uppercase tracking-wider">
             <button (click)="goHome()" class="hover:text-indigo-600 transition">Biblioteka</button>
             @for (crumb of breadcrumbs(); track crumb.id) {
               <span class="mx-2 text-slate-300">/</span>
               <button (click)="openFolder(crumb)" class="hover:text-indigo-600 transition truncate max-w-[100px]">{{ crumb.name }}</button>
             }
          </nav>
          <div class="flex items-center gap-2">
            @if (currentFolder()) {
               <button (click)="goUp()" class="p-1 -ml-1 hover:bg-slate-100 rounded-lg text-slate-500 transition">
                  <span class="material-icons-outlined text-xl">arrow_back</span>
               </button>
            }
            <h2 class="text-2xl font-bold text-slate-800 tracking-tight">
               {{ getCurrentFolderName() }}
            </h2>
          </div>
        </div>
        
        <!-- Right: Actions & Search -->
        <div class="flex flex-col md:flex-row items-center gap-3 self-end md:self-auto w-full md:w-auto">
          
          <!-- Search Input -->
          <div class="relative w-full md:w-64 group">
            <span class="material-icons-outlined absolute left-3 top-1/2 -translate-y-1/2 text-slate-400 group-focus-within:text-indigo-500 transition">search</span>
            <input 
              type="text" 
              [ngModel]="searchTerm()" 
              (ngModelChange)="searchTerm.set($event)" 
              placeholder="Szukaj..." 
              class="w-full pl-10 pr-10 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:bg-white transition placeholder-slate-400 text-slate-700">
             
             @if (searchTerm()) {
               <button (click)="searchTerm.set('')" class="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600 p-1">
                 <span class="material-icons-outlined text-sm">close</span>
               </button>
             }
          </div>

          <div class="flex items-center gap-3 w-full md:w-auto">
            <!-- Main Actions -->
            <button (click)="openModal('create_folder')" class="flex-1 md:flex-none flex items-center justify-center gap-2 bg-slate-50 border border-slate-200 hover:bg-slate-100 text-slate-700 px-5 py-2.5 rounded-xl text-sm font-semibold transition whitespace-nowrap">
              <span class="material-icons-outlined">create_new_folder</span>
              <span class="hidden lg:inline">Folder</span>
            </button>
            
            <button (click)="openModal('create_note')" class="flex-1 md:flex-none flex items-center justify-center gap-2 bg-slate-50 border border-slate-200 hover:bg-slate-100 text-slate-700 px-5 py-2.5 rounded-xl text-sm font-semibold transition whitespace-nowrap">
              <span class="material-icons-outlined">note_add</span>
              <span class="hidden lg:inline">Notatka</span>
            </button>

            <input type="file" #fileInput hidden (change)="onFileSelected($event)" multiple>
            <button (click)="fileInput.click()" class="flex-1 md:flex-none flex items-center justify-center gap-2 bg-gradient-to-r from-fuchsia-600 to-indigo-600 hover:brightness-110 text-white px-5 py-2.5 rounded-xl text-sm font-semibold transition shadow-lg shadow-indigo-200 whitespace-nowrap">
              <span class="material-icons-outlined">upload_file</span>
              <span>Wgraj</span>
            </button>
          </div>
        </div>
      </div>

      <!-- Content Area -->
      <div class="flex-1 overflow-y-auto bg-slate-50/50">
        @if (filteredItems().length === 0) {
          
          @if (searchTerm()) {
             <!-- Search Empty State -->
             <div class="flex flex-col items-center justify-center h-full text-slate-400 animate-fade-in pb-12">
                <div class="w-24 h-24 bg-slate-100 rounded-full flex items-center justify-center mb-4">
                   <span class="material-icons-outlined text-4xl text-slate-300">search_off</span>
                </div>
                <p class="text-slate-600 font-bold mb-1">Brak wyników</p>
                <p class="text-xs mb-4">Nie znaleziono plików pasujących do "{{ searchTerm() }}"</p>
                <button (click)="searchTerm.set('')" class="text-indigo-600 text-sm font-bold hover:underline">Wyczyść wyszukiwanie</button>
             </div>
          } @else {
             <!-- Folder Empty State -->
             <div class="flex flex-col items-center justify-center h-full text-slate-400 animate-fade-in pb-12">
               <div class="w-32 h-32 bg-slate-100 rounded-full flex items-center justify-center mb-6 shadow-inner">
                  <span class="material-icons-outlined text-5xl text-slate-300">folder_open</span>
               </div>
               <h3 class="text-xl font-bold text-slate-700 mb-2">Folder jest pusty</h3>
               <p class="text-slate-500 max-w-xs text-center mb-6">Rozpocznij organizację dokumentacji dodając nowe pliki.</p>
             </div>
          }

        } @else {
          <div class="p-6 grid grid-cols-2 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6 gap-6 animate-fade-in">
              @for (item of filteredItems(); track item.id) {
                <div 
                  (click)="onItemClick(item)"
                  class="group relative bg-white rounded-2xl p-4 shadow-sm border border-slate-100 hover:border-indigo-300 hover:shadow-xl hover:shadow-indigo-100/50 cursor-pointer transition-all duration-300 flex flex-col items-center text-center transform hover:-translate-y-1">
                  
                  <!-- Thumbnail / Icon Area -->
                  <div class="w-20 h-20 mb-4 rounded-2xl flex items-center justify-center transition-transform group-hover:scale-105 overflow-hidden shadow-inner relative" [ngClass]="getIconBg(item)">
                     @if (item.type === 'file' && (item.fileType === 'jpg' || item.fileType === 'png') && item.url) {
                        <img [src]="getSafeUrl(item.url)" class="w-full h-full object-cover" alt="Preview">
                     } @else {
                        <span class="material-icons-outlined text-4xl" [ngClass]="getIconColor(item)">{{ getIcon(item) }}</span>
                     }
                  </div>
                  
                  <div class="w-full">
                    <div class="flex items-center justify-center gap-1.5 mb-1">
                      <span class="material-icons-round text-[16px] flex-shrink-0" [ngClass]="getIconColor(item)">
                        {{ getIcon(item) }}
                      </span>
                      <p class="text-sm font-semibold text-slate-700 truncate" [title]="item.name">{{ item.name }}</p>
                    </div>
                    <p class="text-[10px] uppercase font-bold text-slate-400 tracking-wider">
                      {{ item.type === 'folder' ? item.date : item.size }}
                    </p>
                  </div>

                  <!-- Quick Actions -->
                  <div class="absolute top-2 right-2 flex flex-col gap-1 opacity-0 group-hover:opacity-100 transition-all translate-x-2 group-hover:translate-x-0">
                    <button (click)="startRenaming($event, item)" class="w-8 h-8 flex items-center justify-center bg-white shadow-sm border border-slate-100 rounded-lg hover:bg-slate-50 text-slate-500 hover:text-indigo-600 transition">
                      <span class="material-icons-outlined text-base">edit</span>
                    </button>
                    <button (click)="deleteItem($event, item)" class="w-8 h-8 flex items-center justify-center bg-white shadow-sm border border-slate-100 rounded-lg hover:bg-red-50 text-slate-500 hover:text-red-600 transition">
                      <span class="material-icons-outlined text-base">delete</span>
                    </button>
                  </div>
                </div>
              }
            </div>
        }
      </div>

      <!-- Footer Stats -->
      <div class="bg-white border-t border-slate-200 px-6 py-2 text-xs text-slate-400 flex justify-between items-center">
         <span>{{ filteredItems().length }} elementów</span>
         <span>Widok siatki</span>
      </div>

      <!-- Input Modal -->
      @if (inputModalMode) {
        <div class="absolute inset-0 z-50 flex items-center justify-center bg-black/20 backdrop-blur-sm p-4 animate-fade-in">
          <div class="bg-white p-8 rounded-3xl shadow-2xl w-full max-w-sm animate-scale-in">
            <h3 class="font-bold text-xl mb-2 text-slate-800">
                @switch(inputModalMode) {
                    @case('create_folder') { Nowy Folder }
                    @case('create_note') { Nowa Notatka }
                    @case('rename') { Zmień nazwę }
                }
            </h3>
            <p class="text-sm text-slate-500 mb-6">Wprowadź nazwę poniżej.</p>
            <input #nameInput type="text" [value]="inputInitialValue" class="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl mb-6 focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 outline-none transition" (keyup.enter)="confirmInput(nameInput.value)">
            <div class="flex justify-end gap-3">
              <button (click)="inputModalMode = null" class="px-5 py-2.5 text-slate-600 hover:bg-slate-100 rounded-xl transition font-medium">Anuluj</button>
              <button (click)="confirmInput(nameInput.value)" class="px-5 py-2.5 bg-indigo-600 text-white rounded-xl hover:bg-indigo-700 transition font-medium shadow-lg shadow-indigo-200">
                Zapisz
              </button>
            </div>
          </div>
        </div>
      }

      <!-- Preview / Editor Modal -->
      @if (previewItem) {
        <div class="absolute inset-0 z-50 flex flex-col bg-[#0B0F19]/95 backdrop-blur-md animate-fade-in text-white">
          <div class="flex items-center justify-between p-4 border-b border-white/10">
             <div class="flex items-center gap-4">
               <button (click)="closePreview()" class="p-2 hover:bg-white/10 rounded-full transition text-slate-400 hover:text-white">
                 <span class="material-icons-outlined">arrow_back</span>
               </button>
               <div>
                 <h3 class="font-semibold text-lg">{{ previewItem!.name }}</h3>
                 <p class="text-xs text-slate-400">{{ previewItem!.size }}</p>
               </div>
             </div>
             
             @if (isEditableText(previewItem!)) {
                <button (click)="saveTextContent()" class="px-4 py-2 bg-indigo-600 text-white rounded-lg hover:bg-indigo-500 transition font-bold text-sm shadow-lg shadow-indigo-500/30 flex items-center gap-2">
                    <span class="material-icons-outlined text-sm">save</span> Zapisz
                </button>
             } @else {
                 <a [href]="getSafeUrl(previewItem!.url)" [download]="previewItem!.name" class="p-2 hover:bg-white/10 rounded-lg transition text-slate-300 hover:text-white">
                      <span class="material-icons-outlined">download</span>
                 </a>
             }
          </div>

          <div class="flex-1 flex items-center justify-center p-8 overflow-hidden relative">
             @if (previewItem!.fileType === 'jpg' || previewItem!.fileType === 'png') {
               <img [src]="getSafeUrl(previewItem!.url)" class="max-w-full max-h-full object-contain rounded-lg shadow-2xl">
             } @else if (previewItem!.fileType === 'pdf') {
               <iframe [src]="getSafeUrl(previewItem!.url)" class="w-full h-full bg-white rounded-lg shadow-2xl border-0 max-w-5xl"></iframe>
             } @else if (isEditableText(previewItem!)) {
                <!-- Text Editor -->
                <textarea [(ngModel)]="editorContent" class="w-full h-full max-w-4xl bg-[#1E293B] text-slate-200 font-mono p-6 rounded-xl border border-slate-700 focus:border-indigo-500 outline-none resize-none shadow-2xl"></textarea>
             } @else {
               <div class="text-center">
                 <div class="w-24 h-24 bg-white/10 rounded-2xl flex items-center justify-center mx-auto mb-6 backdrop-blur-sm">
                    <span class="material-icons-outlined text-6xl text-slate-300">description</span>
                 </div>
                 <h3 class="text-xl font-medium mb-2">Podgląd niedostępny</h3>
                 <a [href]="getSafeUrl(previewItem!.url)" [download]="previewItem!.name" class="inline-block mt-6 px-6 py-3 bg-white text-slate-900 rounded-xl font-semibold hover:bg-slate-200 transition">
                   Pobierz plik
                 </a>
               </div>
             }
          </div>
        </div>
      }
    </div>
  `,
  styles: [`
    @keyframes scale-in { from { transform: scale(0.95); opacity: 0; } to { transform: scale(1); opacity: 1; } }
    .animate-scale-in { animation: scale-in 0.2s cubic-bezier(0.16, 1, 0.3, 1); }
    .animate-fade-in { animation: fadeIn 0.3s ease-out; }
    @keyframes fadeIn { from { opacity: 0; } to { opacity: 1; } }
  `]
})
export class FileManagerComponent {
  dataService = inject(DataService);
  sanitizer = inject(DomSanitizer);
  
  breadcrumbs = this.dataService.breadcrumbs;
  currentItems = this.dataService.currentItems;
  currentFolder = this.dataService.currentFolderId;
  viewMode = this.dataService.viewMode;
  sortBy = this.dataService.sortBy;
  sortAscending = this.dataService.sortAscending;

  // Search State
  searchTerm = signal('');

  // Computed Filtered Items
  filteredItems = computed(() => {
    const term = this.searchTerm().trim().toLowerCase();
    const items = this.currentItems();
    
    if (!term) return items;
    return items.filter(item => item.name.toLowerCase().includes(term));
  });

  inputModalMode: 'create_folder' | 'create_note' | 'rename' | null = null;
  inputInitialValue = '';
  editingItemId: string | null = null;
  previewItem: FileItem | null = null;
  editorContent = '';

  @ViewChild('nameInput') nameInput!: ElementRef;
  @ViewChild('fileInput') fileInput!: ElementRef;

  goHome() { this.dataService.setCurrentFolder(null); }
  
  goUp() {
    const parent = this.dataService.items().find(i => i.id === this.currentFolder());
    this.dataService.setCurrentFolder(parent ? parent.parentId : null);
  }

  getCurrentFolderName() {
    const folder = this.dataService.items().find(i => i.id === this.currentFolder());
    return folder ? folder.name : 'Biblioteka';
  }

  openFolder(item: FileItem) { 
    this.dataService.setCurrentFolder(item.id); 
    this.searchTerm.set(''); // Clear search when navigating
  }

  onItemClick(item: FileItem) {
    if (item.type === 'folder') {
      this.openFolder(item);
    } else {
      this.previewItem = item;
      if (this.isEditableText(item)) {
         this.editorContent = item.content || '';
         // Try loading content from original file if not in memory (for uploaded txts - simplified logic)
         if (!this.editorContent && item.originalFile) {
            const reader = new FileReader();
            reader.onload = (e) => this.editorContent = e.target?.result as string;
            reader.readAsText(item.originalFile);
         }
      }
    }
  }

  onFileSelected(event: Event) {
    const input = event.target as HTMLInputElement;
    if (input.files) {
      Array.from(input.files).forEach(file => {
        this.dataService.uploadFile(file);
      });
      input.value = '';
    }
  }

  openModal(mode: 'create_folder' | 'create_note') {
    this.inputModalMode = mode;
    this.inputInitialValue = '';
    setTimeout(() => this.nameInput?.nativeElement.focus(), 50);
  }

  startRenaming(e: Event, item: FileItem) {
    e.stopPropagation();
    this.inputModalMode = 'rename';
    this.inputInitialValue = item.name;
    this.editingItemId = item.id;
    setTimeout(() => {
        if(this.nameInput) {
            this.nameInput.nativeElement.focus();
            this.nameInput.nativeElement.select();
        }
    }, 50);
  }

  confirmInput(value: string) {
    if (!value.trim()) return;
    
    if (this.inputModalMode === 'create_folder') {
      this.dataService.createFolder(value.trim());
    } else if (this.inputModalMode === 'create_note') {
      this.dataService.createTextFile(value.trim());
    } else if (this.inputModalMode === 'rename' && this.editingItemId) {
      this.dataService.renameItem(this.editingItemId, value.trim());
    }
    
    this.inputModalMode = null;
    this.editingItemId = null;
  }

  deleteItem(e: Event, item: FileItem) {
    e.stopPropagation();
    if (confirm(`Czy na pewno usunąć "${item.name}"?`)) {
      this.dataService.deleteItem(item.id);
    }
  }

  closePreview() {
    this.previewItem = null;
    this.editorContent = '';
  }

  isEditableText(item: FileItem) {
     return item.fileType === 'txt' || item.fileType === 'md';
  }

  saveTextContent() {
     if (this.previewItem && this.isEditableText(this.previewItem)) {
        this.dataService.updateFileContent(this.previewItem.id, this.editorContent);
        // We close preview to refresh state essentially, or keep it open. Let's keep open but show toast (handled in service)
     }
  }

  getSafeUrl(url: string | undefined): SafeUrl | string | undefined {
    if (!url) return undefined;
    return this.sanitizer.bypassSecurityTrustUrl(url);
  }

  getIcon(item: FileItem) {
    switch (item.type) {
      case 'folder': return 'folder';
      case 'file':
        if (item.fileType === 'pdf') return 'picture_as_pdf';
        if (item.fileType === 'docx') return 'description';
        if (item.fileType === 'jpg' || item.fileType === 'png') return 'image';
        if (item.fileType === 'txt' || item.fileType === 'md') return 'article';
        return 'insert_drive_file';
      default: return 'folder';
    }
  }
  
  getIconColor(item: FileItem) {
    if (item.type === 'folder') return 'text-amber-500';
    if (item.fileType === 'pdf') return 'text-red-500';
    if (item.fileType === 'docx') return 'text-blue-500';
    if (item.fileType === 'jpg' || item.fileType === 'png') return 'text-fuchsia-500';
    if (item.fileType === 'txt' || item.fileType === 'md') return 'text-slate-500';
    return 'text-slate-400';
  }

  getIconBg(item: FileItem) {
    if (item.type === 'folder') return 'bg-amber-50 border border-amber-100';
    if (item.fileType === 'pdf') return 'bg-red-50 border border-red-100';
    if (item.fileType === 'docx') return 'bg-blue-50 border border-blue-100';
    if (item.fileType === 'jpg' || item.fileType === 'png') return 'bg-fuchsia-50 border border-fuchsia-100';
    if (item.fileType === 'txt' || item.fileType === 'md') return 'bg-slate-50 border border-slate-200';
    return 'bg-slate-50 border border-slate-100';
  }
}