import { Component, inject, signal, computed } from '@angular/core';
import { CommonModule } from '@angular/common';
import { GeminiService, PlantDetails } from '../services/gemini.service';
import { DataService, SavedPlant } from '../services/data.service';
import { NotificationService } from '../services/notification.service';

@Component({
  selector: 'app-garden',
  standalone: true,
  imports: [CommonModule],
  template: `
    <div class="h-full flex flex-col md:flex-row overflow-hidden bg-slate-50/50">
      
      <!-- Left Panel: Scanner -->
      <div class="w-full md:w-1/2 p-6 flex flex-col h-full overflow-y-auto custom-scrollbar">
         
         <div class="mb-6">
            <h2 class="text-3xl font-bold text-emerald-800 mb-2 flex items-center gap-2">
               <span class="material-icons-round text-emerald-600">local_florist</span> Nebula Flora
            </h2>
            <p class="text-slate-500">Zrób zdjęcie rośliny, aby otrzymać natychmiastową diagnozę i porady pielęgnacyjne od AI.</p>
         </div>

         <!-- Upload Area -->
         <div class="relative bg-white border-2 border-dashed border-slate-300 rounded-3xl p-8 text-center hover:border-emerald-400 transition-all group shadow-sm hover:shadow-lg mb-8"
              [class.border-emerald-500]="selectedImage()">
            
            <input type="file" #fileInput (change)="onFileSelected($event)" accept="image/*" class="absolute inset-0 w-full h-full opacity-0 cursor-pointer z-10">
            
            @if (selectedImage()) {
               <div class="relative w-full h-64 md:h-80 rounded-2xl overflow-hidden shadow-inner bg-slate-100">
                  <img [src]="selectedImage()" class="w-full h-full object-contain">
                  <button (click)="clearImage($event)" class="absolute top-2 right-2 p-2 bg-black/50 text-white rounded-full hover:bg-red-500 transition z-20">
                     <span class="material-icons-round">close</span>
                  </button>
               </div>
            } @else {
               <div class="py-12 flex flex-col items-center">
                  <div class="w-20 h-20 bg-emerald-50 text-emerald-600 rounded-full flex items-center justify-center mb-4 group-hover:scale-110 transition">
                     <span class="material-icons-round text-4xl">add_a_photo</span>
                  </div>
                  <h3 class="font-bold text-slate-700 text-lg">Dodaj zdjęcie rośliny</h3>
                  <p class="text-slate-400 text-sm mt-1">Kliknij lub upuść plik tutaj</p>
               </div>
            }
         </div>

         <!-- Action Button -->
         @if (selectedImage() && !currentAnalysis()) {
            <button (click)="analyzePlant()" [disabled]="isLoading()" 
               class="w-full py-4 bg-gradient-to-r from-emerald-600 to-teal-600 text-white rounded-xl font-bold shadow-lg shadow-emerald-200 hover:shadow-xl hover:scale-[1.02] transition flex items-center justify-center gap-2 disabled:opacity-50 disabled:cursor-wait">
               @if (isLoading()) {
                  <span class="material-icons-round animate-spin">sync</span> Analizowanie liści...
               } @else {
                  <span class="material-icons-round">search</span> Zidentyfikuj Roślinę
               }
            </button>
         }

         <!-- Analysis Result -->
         @if (currentAnalysis()) {
            <div class="bg-white rounded-3xl shadow-xl border border-emerald-100 overflow-hidden animate-slide-up">
               <div class="bg-emerald-600 p-6 text-white relative overflow-hidden">
                  <div class="absolute -right-6 -top-6 w-24 h-24 bg-white/10 rounded-full"></div>
                  <h3 class="text-2xl font-bold">{{ currentAnalysis()!.name }}</h3>
                  <p class="text-emerald-100 italic">{{ currentAnalysis()!.scientificName }}</p>
               </div>
               
               <div class="p-6 space-y-6">
                  <p class="text-slate-600 leading-relaxed">{{ currentAnalysis()!.description }}</p>
                  
                  <div class="grid grid-cols-2 gap-4">
                     <div class="bg-blue-50 p-4 rounded-xl border border-blue-100">
                        <div class="flex items-center gap-2 text-blue-700 font-bold mb-1">
                           <span class="material-icons-round text-sm">water_drop</span> Podlewanie
                        </div>
                        <p class="text-sm text-slate-700">{{ currentAnalysis()!.care.watering }}</p>
                     </div>
                     <div class="bg-amber-50 p-4 rounded-xl border border-amber-100">
                        <div class="flex items-center gap-2 text-amber-700 font-bold mb-1">
                           <span class="material-icons-round text-sm">wb_sunny</span> Słońce
                        </div>
                        <p class="text-sm text-slate-700">{{ currentAnalysis()!.care.sunlight }}</p>
                     </div>
                     <div class="bg-amber-900/10 p-4 rounded-xl border border-amber-900/10">
                        <div class="flex items-center gap-2 text-amber-900 font-bold mb-1">
                           <span class="material-icons-round text-sm">grass</span> Ziemia
                        </div>
                        <p class="text-sm text-slate-700">{{ currentAnalysis()!.care.soil }}</p>
                     </div>
                     <div class="bg-red-50 p-4 rounded-xl border border-red-100">
                        <div class="flex items-center gap-2 text-red-700 font-bold mb-1">
                           <span class="material-icons-round text-sm">thermostat</span> Temp.
                        </div>
                        <p class="text-sm text-slate-700">{{ currentAnalysis()!.care.temperature }}</p>
                     </div>
                  </div>

                  <div class="bg-slate-50 p-4 rounded-xl border border-slate-100 text-sm text-slate-600 italic">
                     <span class="font-bold text-slate-700 block mb-1">💡 Ciekawostka:</span>
                     {{ currentAnalysis()!.funFact }}
                  </div>

                  <button (click)="saveToGarden()" class="w-full py-3 border-2 border-emerald-600 text-emerald-700 font-bold rounded-xl hover:bg-emerald-50 transition flex items-center justify-center gap-2">
                     <span class="material-icons-round">favorite</span> Zapisz do Mojego Ogrodu
                  </button>
               </div>
            </div>
         }
      </div>

      <!-- Right Panel: My Garden -->
      <div class="w-full md:w-1/2 bg-white border-l border-slate-200 p-6 flex flex-col h-full overflow-hidden">
         <div class="flex items-center justify-between mb-6">
            <h3 class="font-bold text-xl text-slate-800">Mój Ogród</h3>
            <span class="px-3 py-1 bg-emerald-100 text-emerald-700 rounded-full text-xs font-bold">{{ myPlants().length }} roślin</span>
         </div>
         
         <div class="flex-1 overflow-y-auto custom-scrollbar space-y-4 pb-10">
            @if (myPlants().length === 0) {
               <div class="flex flex-col items-center justify-center h-64 text-slate-400">
                  <span class="material-icons-round text-5xl mb-3 opacity-50">yard</span>
                  <p>Twój ogród jest pusty.</p>
                  <p class="text-xs">Zidentyfikuj i zapisz rośliny, aby je tutaj zobaczyć.</p>
               </div>
            }

            @for (plant of myPlants(); track plant.id) {
               <div class="flex gap-4 p-4 rounded-2xl border border-slate-100 hover:border-emerald-200 hover:shadow-md transition group bg-slate-50/50">
                  <div class="w-20 h-20 rounded-xl bg-white shadow-sm flex-shrink-0 overflow-hidden">
                     @if (plant.imageUrl) {
                        <img [src]="plant.imageUrl" class="w-full h-full object-cover">
                     } @else {
                        <div class="w-full h-full flex items-center justify-center text-emerald-200">
                           <span class="material-icons-round text-3xl">local_florist</span>
                        </div>
                     }
                  </div>
                  <div class="flex-1 min-w-0">
                     <div class="flex justify-between items-start">
                        <h4 class="font-bold text-slate-800 truncate">{{ plant.name }}</h4>
                        <button (click)="deletePlant(plant.id)" class="text-slate-300 hover:text-red-500 opacity-0 group-hover:opacity-100 transition">
                           <span class="material-icons-round text-sm">delete</span>
                        </button>
                     </div>
                     <p class="text-xs text-emerald-600 italic mb-2">{{ plant.scientificName }}</p>
                     
                     <div class="flex gap-2 text-[10px] text-slate-500">
                        <span class="flex items-center gap-1 bg-white px-2 py-1 rounded border border-slate-100">
                           <span class="material-icons-round text-[10px] text-blue-500">water_drop</span> {{ truncate(plant.care.watering) }}
                        </span>
                        <span class="flex items-center gap-1 bg-white px-2 py-1 rounded border border-slate-100">
                           <span class="material-icons-round text-[10px] text-amber-500">wb_sunny</span> {{ truncate(plant.care.sunlight) }}
                        </span>
                     </div>
                  </div>
               </div>
            }
         </div>
      </div>

    </div>
  `,
  styles: [`
    .custom-scrollbar::-webkit-scrollbar { width: 6px; }
    .custom-scrollbar::-webkit-scrollbar-track { background: transparent; }
    .custom-scrollbar::-webkit-scrollbar-thumb { background: #cbd5e1; border-radius: 3px; }
    @keyframes slideUp { from { opacity: 0; transform: translateY(20px); } to { opacity: 1; transform: translateY(0); } }
    .animate-slide-up { animation: slideUp 0.5s cubic-bezier(0.16, 1, 0.3, 1); }
  `]
})
export class GardenComponent {
  gemini = inject(GeminiService);
  dataService = inject(DataService);
  notificationService = inject(NotificationService);

  selectedImage = signal<string | null>(null);
  isLoading = signal(false);
  currentAnalysis = signal<PlantDetails | null>(null);
  
  myPlants = this.dataService.plants;

  onFileSelected(event: Event) {
    const input = event.target as HTMLInputElement;
    if (input.files && input.files[0]) {
      const file = input.files[0];
      const reader = new FileReader();
      reader.onload = (e) => {
         this.selectedImage.set(e.target?.result as string);
         this.currentAnalysis.set(null); // Reset prev analysis
      };
      reader.readAsDataURL(file);
    }
    input.value = '';
  }

  clearImage(e: Event) {
    e.stopPropagation();
    this.selectedImage.set(null);
    this.currentAnalysis.set(null);
  }

  async analyzePlant() {
    if (!this.selectedImage()) return;
    
    this.isLoading.set(true);
    // Remove data:image/jpeg;base64, prefix
    const base64 = this.selectedImage()!.split(',')[1];
    
    const result = await this.gemini.identifyPlant(base64);
    
    if (result) {
      this.currentAnalysis.set(result);
    } else {
      this.notificationService.show('Nie udało się zidentyfikować rośliny.', 'error');
    }
    this.isLoading.set(false);
  }

  saveToGarden() {
    if (this.currentAnalysis()) {
       this.dataService.savePlant(this.currentAnalysis()!, this.selectedImage() || undefined);
       this.currentAnalysis.set(null);
       this.selectedImage.set(null);
    }
  }

  deletePlant(id: string) {
    if(confirm('Usunąć tę roślinę z ogrodu?')) {
       this.dataService.deletePlant(id);
    }
  }

  truncate(text: string, length: number = 15): string {
     if (text.length <= length) return text;
     return text.substring(0, length) + '...';
  }
}