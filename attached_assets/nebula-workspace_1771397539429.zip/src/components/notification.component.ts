import { Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { NotificationService } from '../services/notification.service';

@Component({
  selector: 'app-notification',
  standalone: true,
  imports: [CommonModule],
  template: `
    <div class="fixed bottom-6 right-6 z-[100] flex flex-col gap-3 pointer-events-none">
      @for (note of notificationService.notifications(); track note.id) {
        <div class="pointer-events-auto min-w-[300px] max-w-sm bg-white rounded-xl shadow-lg border-l-4 p-4 flex items-start gap-3 animate-slide-in backdrop-blur-sm bg-opacity-95"
             [ngClass]="{
               'border-green-500': note.type === 'success',
               'border-red-500': note.type === 'error',
               'border-blue-500': note.type === 'info',
               'border-amber-500': note.type === 'warning'
             }">
           
           <!-- Icon -->
           <div class="mt-0.5">
             @if (note.type === 'success') { <span class="material-icons-outlined text-green-600">check_circle</span> }
             @if (note.type === 'error') { <span class="material-icons-outlined text-red-600">error</span> }
             @if (note.type === 'info') { <span class="material-icons-outlined text-blue-600">info</span> }
             @if (note.type === 'warning') { <span class="material-icons-outlined text-amber-600">warning</span> }
           </div>

           <div class="flex-1">
             <p class="text-sm font-medium text-slate-800 leading-tight">{{ note.message }}</p>
           </div>
           
           <button (click)="notificationService.remove(note.id)" class="text-slate-400 hover:text-slate-600 transition">
             <span class="material-icons-outlined text-sm">close</span>
           </button>
        </div>
      }
    </div>
  `,
  styles: [`
    @keyframes slideIn {
      from { transform: translateX(100%); opacity: 0; }
      to { transform: translateX(0); opacity: 1; }
    }
    .animate-slide-in {
      animation: slideIn 0.3s cubic-bezier(0.16, 1, 0.3, 1);
    }
  `]
})
export class NotificationComponent {
  notificationService = inject(NotificationService);
}