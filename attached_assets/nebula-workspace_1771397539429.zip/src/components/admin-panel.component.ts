import { Component, computed, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { DataService, User, FileItem } from '../services/data.service';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-admin-panel',
  standalone: true,
  imports: [CommonModule, FormsModule],
  template: `
    <div class="flex flex-col h-full bg-white rounded-3xl shadow-sm border border-slate-200 overflow-hidden relative">
      
      <!-- Admin Header -->
      <div class="bg-gradient-to-r from-slate-900 to-[#0B1121] text-white p-6 flex flex-col md:flex-row justify-between items-center gap-4 relative overflow-hidden">
         <!-- Abstract Abstract -->
         <div class="absolute inset-0 bg-grid opacity-10 pointer-events-none"></div>
         <div class="absolute -right-10 -top-10 w-40 h-40 bg-red-500/10 rounded-full blur-3xl"></div>

         <div class="relative z-10">
            <h2 class="text-2xl font-bold flex items-center gap-2">
               <div class="p-2 bg-red-500/20 rounded-lg border border-red-500/30">
                 <span class="material-icons-round text-red-500">admin_panel_settings</span>
               </div>
               Centrum Dowodzenia
            </h2>
            <p class="text-slate-400 text-sm mt-1 ml-1">Uprawnienia: <span class="text-red-400 font-bold">ROOT</span></p>
         </div>
         
         <div class="flex bg-white/10 p-1 rounded-xl backdrop-blur-sm relative z-10">
            <button (click)="activeView = 'users'" 
               [class.bg-white]="activeView === 'users'"
               [class.text-slate-900]="activeView === 'users'"
               [class.text-slate-300]="activeView !== 'users'"
               [class.shadow-md]="activeView === 'users'"
               class="px-5 py-2 rounded-lg text-sm font-bold transition-all duration-300 flex items-center gap-2">
               <span class="material-icons-round text-sm">group</span>
               Użytkownicy
            </button>
            <button (click)="activeView = 'files'"
               [class.bg-white]="activeView === 'files'"
               [class.text-slate-900]="activeView === 'files'"
               [class.text-slate-300]="activeView !== 'files'"
               [class.shadow-md]="activeView === 'files'"
               class="px-5 py-2 rounded-lg text-sm font-bold transition-all duration-300 flex items-center gap-2">
               <span class="material-icons-round text-sm">storage</span>
               Pliki
            </button>
         </div>
      </div>

      <!-- Stats Row (Computed) -->
      <div class="grid grid-cols-1 md:grid-cols-3 gap-0 border-b border-slate-200 bg-slate-50">
         <div class="p-6 border-b md:border-b-0 md:border-r border-slate-200 flex items-center gap-4 animate-slide-up" style="animation-delay: 0.1s">
            <div class="w-12 h-12 rounded-full bg-blue-100 text-blue-600 flex items-center justify-center">
               <span class="material-icons-round">people</span>
            </div>
            <div>
               <p class="text-xs text-slate-500 font-bold uppercase tracking-wider">Użytkownicy</p>
               <p class="text-2xl font-bold text-slate-800">{{ users().length }}</p>
            </div>
         </div>
         <div class="p-6 border-b md:border-b-0 md:border-r border-slate-200 flex items-center gap-4 animate-slide-up" style="animation-delay: 0.2s">
            <div class="w-12 h-12 rounded-full bg-amber-100 text-amber-600 flex items-center justify-center">
               <span class="material-icons-round">folder_special</span>
            </div>
            <div>
               <p class="text-xs text-slate-500 font-bold uppercase tracking-wider">Pliki i Foldery</p>
               <p class="text-2xl font-bold text-slate-800">{{ allFiles().length }}</p>
            </div>
         </div>
         <div class="p-6 flex items-center gap-4 animate-slide-up" style="animation-delay: 0.3s">
            <div class="w-12 h-12 rounded-full bg-emerald-100 text-emerald-600 flex items-center justify-center">
               <span class="material-icons-round">cloud_done</span>
            </div>
            <div>
               <p class="text-xs text-slate-500 font-bold uppercase tracking-wider">Zajęte Miejsce</p>
               <p class="text-2xl font-bold text-slate-800">{{ totalStorage }}</p>
            </div>
         </div>
      </div>

      <!-- Content -->
      <div class="flex-1 overflow-y-auto bg-slate-50/50 p-6 relative">
         
         <!-- USERS VIEW -->
         @if (activeView === 'users') {
            <div class="bg-white rounded-2xl shadow-sm border border-slate-200 overflow-hidden animate-fade-in">
               <table class="w-full text-left border-collapse">
                  <thead class="bg-slate-50/80 backdrop-blur border-b border-slate-200">
                     <tr>
                        <th class="p-5 text-xs font-bold text-slate-500 uppercase tracking-wider">Tożsamość</th>
                        <th class="p-5 text-xs font-bold text-slate-500 uppercase tracking-wider">Kontakt</th>
                        <th class="p-5 text-xs font-bold text-slate-500 uppercase tracking-wider">Uprawnienia</th>
                        <th class="p-5 text-xs font-bold text-slate-500 uppercase tracking-wider text-right">Zarządzanie</th>
                     </tr>
                  </thead>
                  <tbody>
                     @for (user of users(); track user.id) {
                        <tr class="border-b border-slate-100 hover:bg-slate-50 transition group">
                           <td class="p-5">
                              <div class="flex items-center gap-4">
                                 <div class="w-10 h-10 rounded-xl flex items-center justify-center font-bold text-sm shadow-sm"
                                      [ngClass]="user.role === 'admin' ? 'bg-red-100 text-red-600' : 'bg-indigo-100 text-indigo-600'">
                                    {{ (user.name || user.email).charAt(0).toUpperCase() }}
                                 </div>
                                 <div>
                                    <div class="font-bold text-slate-800">{{ user.name || 'Anonim' }}</div>
                                    <div class="text-xs text-slate-400">ID: {{ user.id.substring(0,8) }}...</div>
                                 </div>
                              </div>
                           </td>
                           <td class="p-5 text-sm font-medium text-slate-600">{{ user.email }}</td>
                           <td class="p-5">
                              <span [class]="user.role === 'admin' ? 'bg-red-50 text-red-700 border border-red-200' : 'bg-green-50 text-green-700 border border-green-200'" class="px-3 py-1 rounded-full text-xs font-bold uppercase tracking-wide">
                                 {{ user.role }}
                              </span>
                           </td>
                           <td class="p-5 text-right">
                              @if (user.role !== 'admin') {
                                 <div class="flex justify-end gap-2 opacity-60 group-hover:opacity-100 transition">
                                    <button (click)="resetPassword(user)" class="p-2 hover:bg-blue-50 text-blue-600 rounded-lg transition" title="Resetuj hasło">
                                       <span class="material-icons-round text-sm">lock_reset</span>
                                    </button>
                                    <button (click)="deleteUser(user)" class="p-2 hover:bg-red-50 text-red-600 rounded-lg transition" title="Usuń konto">
                                       <span class="material-icons-round text-sm">delete_forever</span>
                                    </button>
                                 </div>
                              }
                           </td>
                        </tr>
                     }
                  </tbody>
               </table>
            </div>
         }

         <!-- FILES VIEW -->
         @if (activeView === 'files') {
            <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-5 animate-fade-in">
               @for (file of allFiles(); track file.id) {
                  <div class="bg-white p-5 rounded-2xl shadow-sm border border-slate-200 flex flex-col relative group hover:border-cyan-300 hover:shadow-lg hover:shadow-cyan-100/50 transition-all duration-300 transform hover:-translate-y-1">
                     
                     <div class="flex items-start justify-between mb-4">
                        <div class="w-12 h-12 rounded-xl flex items-center justify-center shadow-inner" 
                             [ngClass]="file.type === 'folder' ? 'bg-amber-50 text-amber-500' : 'bg-blue-50 text-blue-500'">
                           <span class="material-icons-round text-2xl">{{ file.type === 'folder' ? 'folder' : 'description' }}</span>
                        </div>
                        <span class="text-[10px] font-bold bg-slate-100 text-slate-500 px-2 py-1 rounded-md">{{ file.size || 'DIR' }}</span>
                     </div>
                     
                     <div class="mb-2">
                        <p class="font-bold text-slate-800 truncate" [title]="file.name">{{ file.name }}</p>
                        <p class="text-xs text-slate-400 mt-1">
                           Właściciel: <span class="text-indigo-600 font-medium bg-indigo-50 px-1 rounded">{{ getOwnerName(file.ownerId) }}</span>
                        </p>
                     </div>

                     <div class="absolute top-4 right-4 opacity-0 group-hover:opacity-100 transition-opacity">
                        <button (click)="deleteFile(file.id)" class="w-8 h-8 flex items-center justify-center bg-white border border-red-100 text-red-500 rounded-lg hover:bg-red-500 hover:text-white transition shadow-sm">
                           <span class="material-icons-round text-sm">delete</span>
                        </button>
                     </div>
                  </div>
               }
            </div>
         }
      </div>
    </div>
  `,
  styles: [`
    .bg-grid { background-image: radial-gradient(rgba(255,255,255,0.1) 1px, transparent 1px); background-size: 20px 20px; }
    
    @keyframes slideUp { from { transform: translateY(10px); opacity: 0; } to { transform: translateY(0); opacity: 1; } }
    .animate-slide-up { animation: slideUp 0.4s ease-out forwards; opacity: 0; }
    
    .animate-fade-in { animation: fadeIn 0.3s ease-out; }
    @keyframes fadeIn { from { opacity: 0; } to { opacity: 1; } }
  `]
})
export class AdminPanelComponent {
  dataService = inject(DataService);
  
  users = this.dataService.allUsers;
  allFiles = this.dataService.items;
  
  activeView: 'users' | 'files' = 'users';

  // Computed Stats
  get totalStorage(): string {
     const totalBytes = this.allFiles().reduce((acc, item) => acc + (item.sizeBytes || 0), 0);
     if (totalBytes === 0) return '0 B';
     const k = 1024;
     const sizes = ['B', 'KB', 'MB', 'GB'];
     const i = Math.floor(Math.log(totalBytes) / Math.log(k));
     return parseFloat((totalBytes / Math.pow(k, i)).toFixed(1)) + ' ' + sizes[i];
  }

  getOwnerName(ownerId: string): string {
    const user = this.users().find(u => u.id === ownerId);
    return user ? (user.name || user.email) : 'Nieznany';
  }

  resetPassword(user: User) {
    if(confirm(`Czy na pewno wysłać reset hasła do ${user.email}?`)) {
       this.dataService.adminResetUserPassword(user.id);
    }
  }

  deleteUser(user: User) {
    if(confirm(`UWAGA: Czy na pewno usunąć użytkownika ${user.name} i WSZYSTKIE jego pliki? Tej operacji nie można cofnąć.`)) {
       this.dataService.adminDeleteUser(user.id);
    }
  }

  deleteFile(fileId: string) {
    if(confirm('Usunąć ten plik permanentnie z bazy danych?')) {
       this.dataService.deleteItem(fileId);
    }
  }
}