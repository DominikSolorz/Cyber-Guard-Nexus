import { Component, inject, signal, ViewChild, ElementRef } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { GeminiService } from '../services/gemini.service';

interface SupportMsg {
  role: 'bot' | 'user';
  text: string;
}

@Component({
  selector: 'app-support-bot',
  standalone: true,
  imports: [CommonModule, FormsModule],
  template: `
    <div class="fixed bottom-6 right-6 z-[90] flex flex-col items-end">
      
      <!-- Chat Window -->
      @if (isOpen) {
        <div class="mb-4 w-[350px] h-[450px] bg-white rounded-2xl shadow-2xl border border-slate-200 flex flex-col overflow-hidden animate-scale-in">
          <!-- Header -->
          <div class="bg-gradient-to-r from-indigo-600 to-blue-600 p-4 flex items-center justify-between text-white">
             <div class="flex items-center gap-3">
               <div class="w-8 h-8 rounded-full bg-white/20 flex items-center justify-center">
                 <span class="material-icons-outlined text-sm">support_agent</span>
               </div>
               <div>
                 <h3 class="font-bold text-sm">Pomoc Lumina</h3>
                 <p class="text-[10px] text-indigo-100">Odpowiadamy natychmiast</p>
               </div>
             </div>
             <button (click)="isOpen = false" class="hover:bg-white/10 rounded-full p-1 transition"><span class="material-icons-outlined">close</span></button>
          </div>

          <!-- Messages -->
          <div class="flex-1 overflow-y-auto p-4 bg-slate-50 space-y-3" #scrollContainer>
             @for (msg of messages(); track $index) {
                <div [class.items-end]="msg.role === 'user'" [class.items-start]="msg.role === 'bot'" class="flex flex-col">
                   <div [class.bg-indigo-600]="msg.role === 'user'" 
                        [class.text-white]="msg.role === 'user'"
                        [class.bg-white]="msg.role === 'bot'"
                        [class.text-slate-700]="msg.role === 'bot'"
                        [class.border]="msg.role === 'bot'"
                        class="px-3 py-2 rounded-xl text-sm max-w-[85%] shadow-sm leading-snug">
                     {{ msg.text }}
                   </div>
                </div>
             }
             @if (isTyping) {
               <div class="flex items-center gap-1 ml-2">
                 <span class="w-1.5 h-1.5 bg-slate-400 rounded-full animate-bounce"></span>
                 <span class="w-1.5 h-1.5 bg-slate-400 rounded-full animate-bounce delay-100"></span>
                 <span class="w-1.5 h-1.5 bg-slate-400 rounded-full animate-bounce delay-200"></span>
               </div>
             }
          </div>

          <!-- Input -->
          <div class="p-3 bg-white border-t border-slate-100 flex gap-2">
            <input 
               [(ngModel)]="userInput" 
               (keyup.enter)="sendMessage()"
               placeholder="Zapytaj o reset hasła..." 
               class="flex-1 bg-slate-50 border border-slate-200 rounded-lg px-3 py-2 text-sm focus:border-indigo-500 outline-none transition">
            <button (click)="sendMessage()" [disabled]="!userInput.trim() || isTyping" class="p-2 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700 transition disabled:opacity-50">
               <span class="material-icons-outlined text-sm">send</span>
            </button>
          </div>
        </div>
      }

      <!-- Toggle Button -->
      <button (click)="toggleChat()" class="w-14 h-14 bg-indigo-600 hover:bg-indigo-700 text-white rounded-full shadow-lg shadow-indigo-600/30 flex items-center justify-center transition hover:scale-105 active:scale-95 group">
        @if (!isOpen) {
           <span class="material-icons-outlined text-2xl group-hover:animate-wiggle">chat_bubble</span>
        } @else {
           <span class="material-icons-outlined text-2xl">expand_more</span>
        }
      </button>
    </div>
  `,
  styles: [`
    @keyframes scaleIn { from { transform: scale(0.9) translateY(20px); opacity: 0; } to { transform: scale(1) translateY(0); opacity: 1; } }
    .animate-scale-in { animation: scaleIn 0.2s ease-out; }
    @keyframes wiggle { 0%, 100% { transform: rotate(0); } 25% { transform: rotate(-10deg); } 75% { transform: rotate(10deg); } }
    .group-hover\\:animate-wiggle:hover { animation: wiggle 0.3s ease-in-out; }
  `]
})
export class SupportBotComponent {
  private gemini = inject(GeminiService);
  
  isOpen = false;
  isTyping = false;
  userInput = '';
  messages = signal<SupportMsg[]>([
    { role: 'bot', text: 'Cześć! Jestem wirtualnym asystentem Lumina. Jak mogę Ci pomóc? Np. "Zapomniałem hasła" lub "Jak założyć konto?".' }
  ]);

  @ViewChild('scrollContainer') private scrollContainer!: ElementRef;

  toggleChat() {
    this.isOpen = !this.isOpen;
    if (this.isOpen) setTimeout(() => this.scrollToBottom(), 100);
  }

  async sendMessage() {
    if (!this.userInput.trim() || this.isTyping) return;

    const text = this.userInput;
    this.userInput = '';
    this.messages.update(m => [...m, { role: 'user', text }]);
    this.scrollToBottom();
    this.isTyping = true;

    try {
      // Create a specific context for the support bot
      const response = await this.gemini.chat(text, [], undefined, `
        Jesteś Asystentem Wsparcia Technicznego (Helpdesk) dla aplikacji Lumina AI.
        
        Twoja wiedza:
        1. Logowanie: Jeśli ktoś zapomniał hasła, powiedz mu, żeby wszedł w zakładkę "Kontakt" i wybrał temat "Wsparcie Techniczne" lub "Reset Hasła". Użytkownik otrzyma wtedy maila.
        2. Rejestracja: Jest darmowa. Wymaga maila i telefonu.
        3. Funkcje: Lumina to asystent prawny i menedżer plików.
        
        Zasady:
        - Bądź uprzejmy i krótki.
        - Zawsze kieruj do zakładki Kontakt w sprawach konta (reset hasła, zmiana maila).
        - Nie wymyślaj procedur, których nie ma. Procedura to: Kontakt -> Formularz -> Mail od Supportu.
      `);
      
      this.messages.update(m => [...m, { role: 'bot', text: response.text }]);
    } catch (e) {
      this.messages.update(m => [...m, { role: 'bot', text: 'Przepraszam, mam chwilowe problemy z łącznością. Proszę skorzystać z formularza Kontakt.' }]);
    } finally {
      this.isTyping = false;
      setTimeout(() => this.scrollToBottom(), 100);
    }
  }

  scrollToBottom() {
    if (this.scrollContainer) {
      this.scrollContainer.nativeElement.scrollTop = this.scrollContainer.nativeElement.scrollHeight;
    }
  }
}