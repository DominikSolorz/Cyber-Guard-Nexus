import { Component, ElementRef, inject, signal, ViewChild, computed } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { GeminiService, ChatAttachment } from '../services/gemini.service';
import { NotificationService } from '../services/notification.service';
import { VoiceService } from '../services/voice.service';
import { DataService, FileItem } from '../services/data.service';

interface Message {
  role: 'user' | 'assistant';
  text: string;
  image?: string; // Generated image
  attachment?: { name: string, type: string }; // User uploaded file preview info
  grounding?: any[];
  isThinking?: boolean;
}

@Component({
  selector: 'app-ai-chat',
  standalone: true,
  imports: [CommonModule, FormsModule],
  template: `
    <div class="flex flex-col h-full bg-white rounded-3xl shadow-sm border border-slate-200 overflow-hidden relative">
      
      <!-- Header -->
      <div class="p-4 border-b border-slate-100 flex justify-between items-center bg-white z-10 backdrop-blur-sm">
        <div class="flex items-center gap-3">
          <div class="w-10 h-10 rounded-xl bg-gradient-to-tr from-cyan-500 to-blue-600 flex items-center justify-center shadow-lg shadow-cyan-500/20">
             <span class="material-icons-outlined text-white">psychology</span>
          </div>
          <div>
            <h2 class="font-bold text-slate-800">Nebula Intelligence</h2>
            <div class="flex items-center gap-1.5">
               <span class="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></span>
               <p class="text-xs text-slate-500 font-medium">Gemini 2.5 Flash • Multimodal</p>
            </div>
          </div>
        </div>
        
        <div class="flex items-center gap-2">
            <!-- Voice Settings Toggle -->
            <button (click)="showVoiceSettings = !showVoiceSettings" class="p-2 rounded-xl hover:bg-slate-100 text-slate-500 hover:text-cyan-600 transition relative">
               <span class="material-icons-outlined">settings_voice</span>
               @if(voiceService.isSpeaking()) {
                 <span class="absolute top-1 right-1 w-2 h-2 bg-green-500 rounded-full animate-ping"></span>
               }
            </button>

            <div class="flex bg-slate-100 p-1 rounded-xl">
                <button (click)="mode = 'chat'" 
                  [class.bg-white]="mode === 'chat'" 
                  [class.shadow-sm]="mode === 'chat'" 
                  [class.text-cyan-600]="mode === 'chat'"
                  [class.text-slate-500]="mode !== 'chat'"
                  class="px-3 py-1.5 rounded-lg text-sm font-bold transition-all">
                  Czat
                </button>
                <button (click)="mode = 'image'" 
                  [class.bg-white]="mode === 'image'" 
                  [class.shadow-sm]="mode === 'image'"
                  [class.text-purple-600]="mode === 'image'"
                  [class.text-slate-500]="mode !== 'image'" 
                  class="px-3 py-1.5 rounded-lg text-sm font-bold transition-all">
                  Kreacja
                </button>
            </div>
        </div>
      </div>

      <!-- Messages -->
      <div class="flex-1 overflow-y-auto p-6 space-y-8 bg-slate-50/50 relative" #scrollContainer>
        
        @if (messages().length === 0) {
           <div class="h-full flex flex-col items-center justify-center text-slate-400 animate-fade-in">
             <div class="w-24 h-24 bg-white rounded-3xl shadow-lg shadow-cyan-100 border border-slate-100 flex items-center justify-center mb-6 relative group">
                <span class="material-icons-outlined text-5xl text-cyan-500 group-hover:scale-110 transition duration-500">auto_awesome</span>
                @if (voiceService.isListening()) {
                  <div class="absolute inset-0 rounded-3xl border-2 border-cyan-500 animate-ping"></div>
                }
             </div>
             <h3 class="text-2xl font-bold text-slate-800 mb-2">Jak mogę Ci pomóc?</h3>
             <p class="text-slate-500 max-w-sm text-center text-sm leading-relaxed mb-10">
               Analizuję dokumenty, generuję obrazy i rozmawiam głosem.
             </p>
             
             <div class="grid grid-cols-1 sm:grid-cols-2 gap-3 max-w-xl w-full">
                <button (click)="openFilePicker()" class="text-left p-4 bg-white border border-slate-200 hover:border-cyan-300 rounded-2xl shadow-sm hover:shadow-md transition text-xs text-slate-600 font-medium group">
                   <span class="flex items-center gap-2 text-cyan-500 mb-1">
                      <span class="material-icons-outlined text-sm">upload_file</span> Przeanalizuj dokument
                   </span>
                   Wybierz plik z biblioteki do analizy AI.
                </button>
                <button (click)="startListening()" class="text-left p-4 bg-white border border-slate-200 hover:border-cyan-300 rounded-2xl shadow-sm hover:shadow-md transition text-xs text-slate-600 font-medium group">
                   <span class="flex items-center gap-2 text-purple-500 mb-1">
                      <span class="material-icons-outlined text-sm">mic</span> Rozmowa głosowa
                   </span>
                   Zadaj pytanie używając mikrofonu.
                </button>
             </div>
           </div>
        }

        @for (msg of messages(); track $index) {
          <div [class.justify-end]="msg.role === 'user'" class="flex gap-4 group">
             @if (msg.role === 'assistant') {
               <div class="w-8 h-8 rounded-lg bg-cyan-600 flex items-center justify-center text-white flex-shrink-0 mt-2 shadow-md cursor-pointer hover:bg-cyan-700 transition" (click)="speakMessage(msg.text)">
                 @if(voiceService.isSpeaking() && currentSpeakingMsgIndex === $index) {
                   <span class="material-icons-outlined text-sm animate-pulse">volume_up</span>
                 } @else {
                   <span class="material-icons-outlined text-sm">psychology</span>
                 }
               </div>
             }
             
             <div [class.bg-gradient-to-br]="msg.role === 'user'"
                  [class.from-cyan-600]="msg.role === 'user'"
                  [class.to-blue-600]="msg.role === 'user'"
                  [class.text-white]="msg.role === 'user'"
                  [class.rounded-tr-none]="msg.role === 'user'"
                  
                  [class.bg-white]="msg.role === 'assistant'"
                  [class.text-slate-700]="msg.role === 'assistant'"
                  [class.shadow-sm]="msg.role === 'assistant'"
                  [class.border]="msg.role === 'assistant'"
                  [class.border-slate-200]="msg.role === 'assistant'"
                  [class.rounded-tl-none]="msg.role === 'assistant'"

                  class="max-w-[85%] rounded-2xl px-6 py-4 text-sm leading-relaxed relative shadow-md">
                
                @if (msg.attachment) {
                  <div class="mb-3 p-3 bg-white/10 rounded-xl border border-white/20 flex items-center gap-3 backdrop-blur-sm">
                     <span class="material-icons-outlined text-2xl opacity-80">
                        {{ msg.attachment.type.includes('pdf') ? 'picture_as_pdf' : 'image' }}
                     </span>
                     <div class="overflow-hidden">
                        <p class="font-bold text-xs truncate">{{ msg.attachment.name }}</p>
                        <p class="text-[10px] opacity-70">Załączono do analizy</p>
                     </div>
                  </div>
                }

                @if (msg.isThinking) {
                  <div class="flex gap-2 items-center h-6 opacity-80">
                    <span class="text-xs font-bold uppercase tracking-widest text-cyan-500">Analiza</span>
                    <span class="relative flex h-3 w-3">
                      <span class="animate-ping absolute inline-flex h-full w-full rounded-full bg-cyan-400 opacity-75"></span>
                      <span class="relative inline-flex rounded-full h-3 w-3 bg-cyan-500"></span>
                    </span>
                  </div>
                } @else {
                  <div class="whitespace-pre-wrap">{{ msg.text }}</div>
                  
                  @if (msg.image) {
                    <div class="mt-4 rounded-xl overflow-hidden shadow-lg border border-slate-100 group-hover:scale-[1.01] transition duration-500">
                       <img [src]="msg.image" class="w-full h-auto object-cover max-h-[400px]">
                    </div>
                  }

                  @if (msg.grounding && msg.grounding.length > 0) {
                    <div class="mt-4 pt-3 border-t border-slate-100/50">
                       <p class="text-[10px] uppercase font-bold text-slate-400 mb-2 flex items-center gap-1">
                         <span class="material-icons-outlined text-[14px]">public</span> Źródła
                       </p>
                       <div class="flex flex-wrap gap-2">
                         @for (chunk of msg.grounding; track $index) {
                            @if (chunk.web?.uri) {
                                <a [href]="chunk.web.uri" target="_blank" class="flex items-center gap-1 bg-slate-50 hover:bg-slate-100 border border-slate-200 rounded-lg px-2 py-1.5 text-xs text-cyan-600 transition truncate max-w-[200px]">
                                  <span class="truncate">{{ chunk.web.title || 'Link' }}</span>
                                  <span class="material-icons-outlined text-[10px]">open_in_new</span>
                                </a>
                            }
                         }
                       </div>
                    </div>
                  }

                  <!-- Message Actions -->
                   @if (msg.role === 'assistant') {
                      <div class="absolute -bottom-6 left-0 flex gap-2 opacity-0 group-hover:opacity-100 transition-opacity">
                         <button (click)="speakMessage(msg.text, $index)" class="p-1 text-slate-400 hover:text-cyan-600 transition" title="Odsłuchaj">
                            <span class="material-icons-outlined text-sm">volume_up</span>
                         </button>
                         <button (click)="copyToClipboard(msg.text)" class="p-1 text-slate-400 hover:text-cyan-600 transition" title="Kopiuj">
                            <span class="material-icons-outlined text-sm">content_copy</span>
                         </button>
                      </div>
                   }
                }
             </div>
          </div>
        }
      </div>

      <!-- Attachment Preview -->
      @if (pendingAttachment) {
        <div class="absolute bottom-[80px] left-4 right-4 z-20 animate-fade-in">
           <div class="bg-white border border-slate-200 rounded-2xl p-3 shadow-xl flex items-center justify-between">
              <div class="flex items-center gap-3">
                 <div class="w-10 h-10 rounded-lg bg-cyan-50 border border-cyan-100 flex items-center justify-center text-cyan-600">
                    <span class="material-icons-outlined">attach_file</span>
                 </div>
                 <div>
                    <p class="text-sm font-bold text-slate-800 truncate max-w-[200px]">{{ pendingAttachment.name }}</p>
                    <p class="text-xs text-slate-500">Gotowy do analizy</p>
                 </div>
              </div>
              <button (click)="pendingAttachment = null" class="p-2 hover:bg-red-50 text-slate-400 hover:text-red-500 rounded-lg transition">
                 <span class="material-icons-outlined">close</span>
              </button>
           </div>
        </div>
      }

      <!-- Input Area -->
      <div class="p-4 bg-white border-t border-slate-100 relative">
        <div class="relative max-w-4xl mx-auto flex items-end gap-2">
          
          <button (click)="openFilePicker()" class="p-3 mb-1 text-slate-400 hover:text-cyan-600 hover:bg-slate-50 rounded-xl transition" title="Załącz plik z biblioteki">
             <span class="material-icons-outlined text-2xl">add_photo_alternate</span>
          </button>

          <div class="flex-1 relative">
            <textarea 
              [(ngModel)]="userInput" 
              (keyup.enter)="sendMessage()"
              [placeholder]="voiceService.isListening() ? 'Słucham...' : (mode === 'chat' ? 'Zadaj pytanie lub załącz dokument...' : 'Opisz obraz...')"
              [disabled]="isLoading || voiceService.isListening()"
              rows="1"
              class="w-full pl-5 pr-12 py-4 bg-slate-50 border border-slate-200 rounded-2xl focus:ring-2 focus:ring-cyan-500/20 focus:border-cyan-500 outline-none transition shadow-inner text-slate-700 disabled:opacity-60 placeholder-slate-400 font-medium resize-none overflow-hidden"
              style="min-height: 56px; max-height: 120px"
              oninput="this.style.height = ''; this.style.height = this.scrollHeight + 'px'"></textarea>
            
            <!-- Mic Button inside input -->
            <button (click)="toggleRecording()" 
               [class.text-red-500]="voiceService.isListening()"
               [class.animate-pulse]="voiceService.isListening()"
               [class.text-slate-400]="!voiceService.isListening()"
               class="absolute right-3 bottom-3 p-1.5 hover:bg-slate-200 rounded-lg transition">
               <span class="material-icons-outlined">{{ voiceService.isListening() ? 'mic_off' : 'mic' }}</span>
            </button>
          </div>
          
          <button (click)="sendMessage()" [disabled]="(!userInput.trim() && !pendingAttachment) || isLoading" 
            class="mb-1 aspect-square h-[56px] bg-cyan-600 hover:bg-cyan-700 text-white rounded-2xl transition shadow-lg shadow-cyan-200 disabled:opacity-50 disabled:shadow-none flex items-center justify-center transform active:scale-95">
             @if (isLoading) {
               <span class="material-icons-outlined animate-spin text-xl">sync</span>
             } @else {
               <span class="material-icons-outlined text-xl">send</span>
             }
          </button>
        </div>
      </div>

      <!-- File Picker Modal -->
      @if (showFilePicker) {
         <div class="absolute inset-0 z-50 bg-black/50 backdrop-blur-sm flex items-center justify-center p-4 animate-fade-in" (click)="showFilePicker = false">
            <div class="bg-white rounded-3xl shadow-2xl w-full max-w-lg overflow-hidden flex flex-col max-h-[80vh]" (click)="$event.stopPropagation()">
               <div class="p-5 border-b border-slate-100 flex justify-between items-center bg-slate-50">
                  <h3 class="font-bold text-slate-800">Wybierz plik do analizy</h3>
                  <button (click)="showFilePicker = false" class="text-slate-400 hover:text-slate-600"><span class="material-icons-outlined">close</span></button>
               </div>
               <div class="flex-1 overflow-y-auto p-2">
                  @if (availableFiles().length === 0) {
                     <div class="p-8 text-center text-slate-400">
                        <span class="material-icons-outlined text-4xl mb-2">folder_off</span>
                        <p>Brak plików w bibliotece.</p>
                     </div>
                  }
                  @for (file of availableFiles(); track file.id) {
                     <div (click)="selectFile(file)" class="flex items-center gap-3 p-3 hover:bg-slate-50 rounded-xl cursor-pointer transition border border-transparent hover:border-cyan-100">
                        <div class="w-10 h-10 rounded-lg flex items-center justify-center text-white" 
                             [ngClass]="{'bg-red-500': file.fileType === 'pdf', 'bg-blue-500': file.fileType === 'docx', 'bg-purple-500': file.fileType === 'jpg' || file.fileType === 'png'}">
                           <span class="material-icons-outlined">{{ file.type === 'folder' ? 'folder' : 'description' }}</span>
                        </div>
                        <div class="flex-1 overflow-hidden">
                           <p class="font-bold text-sm text-slate-800 truncate">{{ file.name }}</p>
                           <p class="text-xs text-slate-400">{{ file.size }} • {{ file.date }}</p>
                        </div>
                     </div>
                  }
               </div>
            </div>
         </div>
      }

      <!-- Voice Settings Modal -->
      @if (showVoiceSettings) {
         <div class="absolute top-16 right-4 w-72 bg-white rounded-2xl shadow-xl border border-slate-100 z-50 p-4 animate-fade-in">
            <h4 class="font-bold text-sm text-slate-800 mb-3 flex items-center gap-2">
               <span class="material-icons-outlined text-cyan-500">record_voice_over</span> Ustawienia głosu
            </h4>
            
            <div class="space-y-2 max-h-60 overflow-y-auto custom-scrollbar">
               @for (voice of voiceService.availableVoices(); track voice.name) {
                  <button (click)="voiceService.setVoice(voice.name); showVoiceSettings = false" 
                     class="w-full text-left px-3 py-2 rounded-lg text-xs font-medium transition flex items-center justify-between"
                     [class.bg-cyan-50]="voiceService.selectedVoice()?.name === voice.name"
                     [class.text-cyan-700]="voiceService.selectedVoice()?.name === voice.name"
                     [class.text-slate-600]="voiceService.selectedVoice()?.name !== voice.name"
                     [class.hover:bg-slate-50]="voiceService.selectedVoice()?.name !== voice.name">
                     <span>{{ voice.name }}</span>
                     @if(voiceService.selectedVoice()?.name === voice.name) {
                        <span class="material-icons-outlined text-sm">check</span>
                     }
                  </button>
               }
            </div>
         </div>
      }

    </div>
  `
})
export class AiChatComponent {
  private gemini = inject(GeminiService);
  private notificationService = inject(NotificationService);
  private dataService = inject(DataService);
  public voiceService = inject(VoiceService);
  
  messages = signal<Message[]>([]);
  userInput = '';
  isLoading = false;
  mode: 'chat' | 'image' = 'chat';
  
  showFilePicker = false;
  showVoiceSettings = false;
  
  pendingAttachment: FileItem | null = null;
  currentSpeakingMsgIndex: number | null = null;

  @ViewChild('scrollContainer') private scrollContainer!: ElementRef;

  // Filter only files (no folders) for attachment
  availableFiles = computed(() => this.dataService.items().filter(i => i.type === 'file'));

  prefill(text: string) {
    this.userInput = text;
  }

  openFilePicker() {
    this.showFilePicker = true;
  }

  selectFile(file: FileItem) {
    this.pendingAttachment = file;
    this.showFilePicker = false;
    this.notificationService.show(`Wybrano plik: ${file.name}`, 'info');
  }

  async toggleRecording() {
    if (this.voiceService.isListening()) {
      this.voiceService.stopListening();
    } else {
      try {
        const text = await this.voiceService.listen();
        this.userInput = text;
      } catch (error: any) {
        this.notificationService.show(error.toString(), 'error');
      }
    }
  }

  speakMessage(text: string, index?: number) {
    if (this.voiceService.isSpeaking()) {
      this.voiceService.stopSpeaking();
      this.currentSpeakingMsgIndex = null;
    } else {
      this.currentSpeakingMsgIndex = index ?? null;
      this.voiceService.speak(text);
    }
  }

  copyToClipboard(text: string) {
    navigator.clipboard.writeText(text);
    this.notificationService.show('Skopiowano do schowka', 'success');
  }

  async sendMessage() {
    if ((!this.userInput.trim() && !this.pendingAttachment) || this.isLoading) return;

    const text = this.userInput;
    const attachmentInfo = this.pendingAttachment ? { name: this.pendingAttachment.name, type: this.pendingAttachment.fileType || 'file' } : undefined;
    
    // Prepare attachment for API if exists
    let chatAttachment: ChatAttachment | null = null;
    if (this.pendingAttachment && this.pendingAttachment.originalFile) {
       try {
          const base64 = await this.fileToBase64(this.pendingAttachment.originalFile);
          chatAttachment = {
             mimeType: this.pendingAttachment.originalFile.type,
             data: base64
          };
       } catch (e) {
          this.notificationService.show('Błąd odczytu pliku', 'error');
       }
    }

    this.userInput = '';
    this.pendingAttachment = null;
    this.isLoading = true;

    // Add User Message
    this.messages.update(m => [...m, { role: 'user', text, attachment: attachmentInfo }]);
    this.scrollToBottom();

    // Add Placeholder Assistant Message
    this.messages.update(m => [...m, { role: 'assistant', text: '', isThinking: true }]);
    this.scrollToBottom();

    try {
      if (this.mode === 'image') {
         // Image Generation Mode
         const imageBase64 = await this.gemini.generateImage(text);
         if (!imageBase64) {
           this.notificationService.show('Nie udało się wygenerować obrazu.', 'error');
         }
         this.messages.update(m => {
           const newM = [...m];
           newM.pop(); 
           newM.push({
              role: 'assistant',
              text: imageBase64 ? 'Oto wizualizacja Twojego pomysłu:' : 'Przepraszam, wystąpił problem z generatorem obrazów.',
              image: imageBase64 || undefined
           });
           return newM;
         });
      } else {
         // Chat Mode (Text or Multimodal)
         const history = this.messages()
          .slice(0, -2) // Exclude current interaction
          .filter(m => m.role !== 'assistant' || !m.isThinking) 
          .map(m => ({
              role: m.role,
              parts: [{ text: m.text }]
          }));

         const response = await this.gemini.chat(text, history, chatAttachment);
         
         this.messages.update(m => {
           const newM = [...m];
           newM.pop(); 
           newM.push({
              role: 'assistant',
              text: response.text || 'Brak odpowiedzi.',
              grounding: response.grounding
           });
           return newM;
         });
         
         // Auto-read response if user used voice recently (optional UX choice, keeping manual for now unless requested)
      }
    } catch (e) {
      this.notificationService.show('Błąd połączenia z Lumina AI.', 'error');
      this.messages.update(m => {
         const newM = [...m];
         newM.pop();
         newM.push({role: 'assistant', text: 'Przepraszam, wystąpił błąd krytyczny połączenia.'});
         return newM;
      });
    }

    this.isLoading = false;
    setTimeout(() => this.scrollToBottom(), 100);
  }

  scrollToBottom() {
    if (this.scrollContainer) {
      this.scrollContainer.nativeElement.scrollTop = this.scrollContainer.nativeElement.scrollHeight;
    }
  }

  private fileToBase64(file: File): Promise<string> {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.readAsDataURL(file);
      reader.onload = () => {
         const result = reader.result as string;
         // Remove Data URL prefix (e.g. "data:image/png;base64,") to get pure base64
         const base64 = result.split(',')[1];
         resolve(base64);
      };
      reader.onerror = error => reject(error);
    });
  }
}