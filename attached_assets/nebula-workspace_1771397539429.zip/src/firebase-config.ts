export const firebaseConfig = {
  apiKey: "AIzaSyAkd_jglBXySTaytjvB2YeZjm-2zl38RIs",
  authDomain: "gen-lang-client-0736087580.firebaseapp.com",
  projectId: "gen-lang-client-0736087580",
  storageBucket: "gen-lang-client-0736087580.firebasestorage.app",
  messagingSenderId: "506310770294",
  appId: "1:506310770294:web:000000000000" // Generic placeholder for AppID as it wasn't provided, but Auth/Firestore often work without strict AppID matching in web SDKs
};