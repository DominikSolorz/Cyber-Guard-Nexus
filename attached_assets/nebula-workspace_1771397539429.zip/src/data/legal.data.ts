export const LEGAL_CONTENT = {
  rodo: `
    <h4 class="font-bold mb-2">Klauzula informacyjna RODO (Art. 13)</h4>
    <p class="mb-2">Zgodnie z art. 13 ust. 1 i ust. 2 ogólnego rozporządzenia o ochronie danych osobowych z dnia 27 kwietnia 2016 r. (RODO) informujemy, iż:</p>
    <ol class="list-decimal pl-5 space-y-2">
      <li><strong>Administrator Danych:</strong> Administratorem Pani/Pana danych osobowych jest Nebula Tech Sp. z o.o. z siedzibą w Warszawie, ul. Kosmiczna 42, 00-001 Warszawa.</li>
      <li><strong>Inspektor Danych:</strong> Kontakt z Inspektorem Ochrony Danych możliwy jest pod adresem: privacy@nebula.ai.</li>
      <li><strong>Cel przetwarzania:</strong> Pani/Pana dane osobowe przetwarzane będą w celu świadczenia usług Cloud Computing, obsługi zapytań oraz analizy AI.</li>
      <li><strong>Prawa osoby:</strong> Posiada Pani/Pan prawo dostępu do treści swoich danych, ich sprostowania, usunięcia, ograniczenia przetwarzania.</li>
    </ol>
  `,
  privacy: `
    <h4 class="font-bold mb-2">Polityka Prywatności i Plików Cookies</h4>
    <p class="mb-4">Niniejsza Polityka określa zasady funkcjonowania ekosystemu Nebula Workspace.</p>
    
    <h5 class="font-semibold mt-4">§1. Pliki Cookies</h5>
    <p>System Nebula wykorzystuje cookies sesyjne do utrzymania połączenia z chmurą.</p>

    <h5 class="font-semibold mt-4">§2. Bezpieczeństwo Danych</h5>
    <p>Dane są szyfrowane algorytmem AES-256 w spoczynku i TLS 1.3 w transmisji.</p>
  `,
  terms: `
    <h4 class="font-bold mb-2">Regulamin Świadczenia Usług Nebula Workspace</h4>
    
    <h5 class="font-semibold mt-4">§1. Postanowienia ogólne</h5>
    <p>1. Regulamin określa zasady korzystania z platformy Nebula Workspace.</p>
    
    <h5 class="font-semibold mt-4">§2. Odpowiedzialność</h5>
    <p>1. Nebula AI (moduł sztucznej inteligencji) jest systemem wspomagającym i może generować nieścisłe informacje (tzw. halucynacje).</p>
    
    <h5 class="font-semibold mt-4">§3. Płatności</h5>
    <p>1. Konto podstawowe jest darmowe. Funkcje Premium (nielimitowane AI) podlegają cennikowi Enterprise.</p>
  `
};