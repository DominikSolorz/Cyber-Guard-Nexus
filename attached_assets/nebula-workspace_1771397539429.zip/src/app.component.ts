import { Component, inject, signal, effect } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AuthComponent } from './components/auth.component';
import { FileManagerComponent } from './components/file-manager.component';
import { AiChatComponent } from './components/ai-chat.component';
import { MindMapComponent } from './components/mind-map.component';
import { LandingPageComponent } from './components/landing-page.component';
import { NotificationComponent } from './components/notification.component';
import { AdminPanelComponent } from './components/admin-panel.component';
import { SettingsComponent } from './components/settings.component';
import { SupportBotComponent } from './components/support-bot.component';
import { DashboardComponent } from './components/dashboard.component';
import { TasksComponent } from './components/tasks.component';
import { DataService } from './services/data.service';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [
    CommonModule, 
    AuthComponent, 
    FileManagerComponent, 
    AiChatComponent,
    MindMapComponent, 
    LandingPageComponent, 
    NotificationComponent, 
    AdminPanelComponent, 
    SettingsComponent,
    SupportBotComponent,
    DashboardComponent,
    TasksComponent
  ],
  template: `
    <app-notification></app-notification>

    @if (isAuthenticated()) {
      <!-- NEBULA DASHBOARD LAYOUT -->
      <div class="flex h-screen font-['Outfit'] overflow-hidden transition-colors duration-500" 
           [ngClass]="isDarkMode() ? 'bg-[#020617] text-white' : 'bg-[#F0F4F8] text-slate-800'">
        
        <!-- SIDEBAR (Desktop: Fixed, Mobile: Overlay) -->
        <aside class="fixed inset-y-0 left-0 w-72 z-50 transform transition-transform duration-300 shadow-2xl flex flex-col border-r backdrop-blur-xl"
               [ngClass]="{
                 'translate-x-0': sidebarOpen,
                 '-translate-x-full': !sidebarOpen,
                 'md:translate-x-0': true,
                 'md:relative': true,
                 'bg-[#020617] border-white/5': isDarkMode(),
                 'bg-white border-slate-200': !isDarkMode()
               }">
          
          <!-- Brand Header -->
          <div class="h-20 flex items-center gap-3 px-6 border-b"
               [ngClass]="isDarkMode() ? 'border-white/5 bg-[#0B1121]' : 'border-slate-100 bg-white'">
            <div class="w-10 h-10 rounded-xl flex items-center justify-center shadow-lg transition-colors duration-500 bg-cyan-600">
               <span class="material-icons-round text-white text-xl">cloud_circle</span>
            </div>
            <div>
               <h1 class="font-bold tracking-wide text-lg" [class.text-white]="isDarkMode()" [class.text-slate-800]="!isDarkMode()">Nebula Workspace</h1>
               <div class="flex items-center gap-1.5">
                  <div class="w-1.5 h-1.5 rounded-full" [style.background-color]="currentUser()?.preferences?.accentHex"></div>
                  <p class="text-[10px] uppercase font-bold tracking-widest transition-colors" [style.color]="currentUser()?.preferences?.accentHex">
                     System Online
                  </p>
               </div>
            </div>
            <!-- Mobile Close -->
            <button class="ml-auto md:hidden transition" (click)="closeSidebar()" [class]="isDarkMode() ? 'text-slate-400 hover:text-white' : 'text-slate-400 hover:text-slate-800'">
               <span class="material-icons-round">close</span>
            </button>
          </div>

          <!-- Navigation -->
          <nav class="flex-1 px-4 py-6 space-y-1.5 overflow-y-auto custom-scrollbar">
            
            <div class="px-2 mb-2 text-[10px] font-bold uppercase tracking-widest opacity-50">Workspace</div>
            
            <button (click)="setActiveTab('dashboard')" 
               class="w-full flex items-center gap-3 px-4 py-3 rounded-l-xl transition-all group border-r-2"
               [ngClass]="getNavClass('dashboard')">
               <span class="material-icons-round transition-colors" [style.color]="activeTab === 'dashboard' ? currentUser()?.preferences?.accentHex : ''">dashboard</span>
               <span class="font-medium group-hover:opacity-100 opacity-90">Kokpit</span>
            </button>
            
            <button (click)="setActiveTab('files')" 
               class="w-full flex items-center gap-3 px-4 py-3 rounded-l-xl transition-all group border-r-2"
               [ngClass]="getNavClass('files')">
               <span class="material-icons-round transition-colors" [style.color]="activeTab === 'files' ? currentUser()?.preferences?.accentHex : ''">folder_open</span>
               <span class="font-medium group-hover:opacity-100 opacity-90">Pliki</span>
            </button>
            
            <button (click)="setActiveTab('tasks')" 
               class="w-full flex items-center gap-3 px-4 py-3 rounded-l-xl transition-all group border-r-2"
               [ngClass]="getNavClass('tasks')">
               <span class="material-icons-round transition-colors" [style.color]="activeTab === 'tasks' ? currentUser()?.preferences?.accentHex : ''">check_circle</span>
               <span class="font-medium group-hover:opacity-100 opacity-90">Zadania</span>
            </button>

            <button (click)="setActiveTab('mind')" 
               class="w-full flex items-center gap-3 px-4 py-3 rounded-l-xl transition-all group border-r-2"
               [ngClass]="getNavClass('mind')">
               <span class="material-icons-round transition-colors" [style.color]="activeTab === 'mind' ? currentUser()?.preferences?.accentHex : ''">hub</span>
               <span class="font-medium group-hover:opacity-100 opacity-90">Mapa Myśli</span>
            </button>

            <div class="mt-6 px-2 mb-2 text-[10px] font-bold uppercase tracking-widest opacity-50">Inteligencja</div>

            <button (click)="setActiveTab('ai')" 
               class="w-full flex items-center gap-3 px-4 py-3 rounded-l-xl transition-all group border-r-2"
               [ngClass]="getNavClass('ai')">
               <span class="material-icons-round transition-colors" [style.color]="activeTab === 'ai' ? currentUser()?.preferences?.accentHex : ''">psychology</span>
               <span class="font-medium group-hover:opacity-100 opacity-90">Lumina AI</span>
            </button>

            <div class="mt-6 px-2 mb-2 text-[10px] font-bold uppercase tracking-widest opacity-50">System</div>
            
            <button (click)="setActiveTab('settings')" 
               class="w-full flex items-center gap-3 px-4 py-3 rounded-l-xl transition-all group border-r-2"
               [ngClass]="getNavClass('settings')">
               <span class="material-icons-round transition-colors" [style.color]="activeTab === 'settings' ? currentUser()?.preferences?.accentHex : ''">tune</span>
               <span class="font-medium group-hover:opacity-100 opacity-90">Ustawienia</span>
            </button>

            @if (isAdmin()) {
               <button (click)="setActiveTab('admin')" 
                  class="w-full flex items-center gap-3 px-4 py-3 rounded-l-xl transition-all group border-r-2 mt-4"
                  [ngClass]="getNavClass('admin')">
                  <span class="material-icons-round text-red-500">admin_panel_settings</span>
                  <span class="font-medium group-hover:opacity-100 opacity-90">Panel Admina</span>
               </button>
            }
          </nav>
          
          <!-- LoFi Player Widget -->
          <div class="mx-4 mb-4 p-3 rounded-xl flex items-center gap-3 transition" 
               [ngClass]="isDarkMode() ? 'bg-white/5 border border-white/10' : 'bg-slate-50 border border-slate-200'">
             <button (click)="toggleMusic()" class="w-10 h-10 rounded-full flex items-center justify-center text-white shadow-md transition hover:scale-105 active:scale-95"
                [style.background]="musicPlaying ? '#ef4444' : currentUser()?.preferences?.accentHex">
                <span class="material-icons-round">{{ musicPlaying ? 'pause' : 'play_arrow' }}</span>
             </button>
             <div class="overflow-hidden">
                <p class="text-xs font-bold truncate opacity-90">Focus Music</p>
                <div class="flex items-center gap-1 h-3">
                   @if (musicPlaying) {
                     <span class="w-0.5 h-full bg-slate-400 animate-music-bar"></span>
                     <span class="w-0.5 h-full bg-slate-400 animate-music-bar delay-75"></span>
                     <span class="w-0.5 h-full bg-slate-400 animate-music-bar delay-150"></span>
                     <span class="text-[10px] opacity-60 ml-1">Odtwarzanie...</span>
                   } @else {
                     <span class="text-[10px] opacity-60">Pauza</span>
                   }
                </div>
             </div>
          </div>

          <!-- User Footer -->
          <div class="p-4 border-t" [ngClass]="isDarkMode() ? 'border-white/5 bg-[#020617]' : 'border-slate-200 bg-white'">
            <div class="flex items-center gap-3 p-3 rounded-xl transition cursor-pointer group border border-transparent" 
                 (click)="showUserMenu = !showUserMenu"
                 [ngClass]="isDarkMode() ? 'hover:bg-white/5 hover:border-white/10' : 'hover:bg-slate-100 hover:border-slate-200'">
               
               <img [src]="currentUser()?.avatarUrl || 'https://ui-avatars.com/api/?name=' + currentUser()?.name + '&background=random'" 
                    class="w-9 h-9 rounded-lg object-cover shadow-sm ring-2"
                    [style.ring-color]="currentUser()?.preferences?.accentHex">

               <div class="flex-1 overflow-hidden">
                 <p class="text-sm font-bold truncate" [class.text-white]="isDarkMode()" [class.text-slate-800]="!isDarkMode()">{{ currentUser()?.name }}</p>
                 <p class="text-[10px] text-slate-500 truncate">{{ currentUser()?.email }}</p>
               </div>
               <span class="material-icons-round text-slate-500 transition">unfold_more</span>
            </div>

            <!-- User Menu Dropup -->
            @if (showUserMenu) {
               <div class="absolute bottom-20 left-4 right-4 border rounded-xl shadow-2xl overflow-hidden animate-fade-in z-50"
                    [ngClass]="isDarkMode() ? 'bg-[#1E293B] border-white/10' : 'bg-white border-slate-200'">
                  <button (click)="setActiveTab('settings'); showUserMenu = false" class="w-full text-left px-4 py-3 text-sm flex items-center gap-2 transition font-medium"
                          [ngClass]="isDarkMode() ? 'text-slate-300 hover:bg-white/10' : 'text-slate-600 hover:bg-slate-50'">
                     <span class="material-icons-round text-lg">person</span>
                     Mój Profil
                  </button>
                  <button (click)="logout()" class="w-full text-left px-4 py-3 hover:bg-red-500/20 hover:text-red-400 text-sm flex items-center gap-2 transition font-medium border-t"
                          [ngClass]="isDarkMode() ? 'text-slate-300 border-white/10' : 'text-slate-600 border-slate-100'">
                     <span class="material-icons-round text-lg">logout</span>
                     Wyloguj się
                  </button>
               </div>
            }
          </div>
        </aside>

        <!-- BACKDROP for Mobile Sidebar -->
        @if (sidebarOpen) {
           <div class="fixed inset-0 bg-black/60 backdrop-blur-sm z-40 md:hidden animate-fade-in" (click)="closeSidebar()"></div>
        }

        <!-- MAIN CONTENT AREA -->
        <main class="flex-1 flex flex-col h-full relative w-full overflow-hidden transition-colors duration-500"
              [ngClass]="isDarkMode() ? 'bg-slate-900/50' : 'bg-slate-100'">
           
           <!-- Mobile Header (Only visible on < md) -->
           <header class="md:hidden h-16 flex items-center justify-between px-4 shrink-0 z-30 shadow-md transition-colors"
                   [ngClass]="isDarkMode() ? 'bg-[#020617] text-white' : 'bg-white text-slate-800'">
              <div class="flex items-center gap-2">
                 <div class="w-8 h-8 rounded-lg flex items-center justify-center bg-cyan-600">
                    <span class="material-icons-round text-sm text-white">cloud_circle</span>
                 </div>
                 <span class="font-bold text-lg">Nebula</span>
              </div>
              <button (click)="toggleSidebar()" class="p-2 rounded-lg transition"
                 [ngClass]="isDarkMode() ? 'bg-white/5 hover:bg-white/10 text-white' : 'bg-slate-100 hover:bg-slate-200 text-slate-800'">
                 <span class="material-icons-round text-2xl">menu</span>
              </button>
           </header>

           <!-- Dynamic Content -->
           <div class="flex-1 overflow-hidden relative">
              @if (activeTab === 'dashboard') {
                 <app-dashboard class="h-full block animate-fade-in"></app-dashboard>
              } @else if (activeTab === 'files') {
                 <div class="h-full p-4 md:p-6">
                    <app-file-manager class="h-full block animate-fade-in"></app-file-manager>
                 </div>
              } @else if (activeTab === 'tasks') {
                 <app-tasks class="h-full block animate-fade-in"></app-tasks>
              } @else if (activeTab === 'ai') {
                 <div class="h-full p-4 md:p-6">
                   <app-ai-chat class="h-full block animate-fade-in"></app-ai-chat>
                 </div>
              } @else if (activeTab === 'mind') {
                 <div class="h-full p-4 md:p-6">
                   <app-mind-map class="h-full block animate-fade-in"></app-mind-map>
                 </div>
              } @else if (activeTab === 'settings') {
                 <div class="h-full p-4 md:p-6">
                   <app-settings class="h-full block animate-fade-in"></app-settings>
                 </div>
              } @else if (activeTab === 'admin' && isAdmin()) {
                 <div class="h-full p-4 md:p-6">
                   <app-admin-panel class="h-full block animate-fade-in"></app-admin-panel>
                 </div>
              }
           </div>

        </main>
        
        <!-- Invisible Audio Element -->
        <audio #audioPlayer loop src="https://cdn.pixabay.com/audio/2022/05/27/audio_1808fbf07a.mp3"></audio>

      </div>
    } @else {
      <!-- PUBLIC LAYOUT (Landing / Auth) -->
      @if (currentView() === 'landing') {
        <app-landing-page (onNavigate)="navigateToAuth($event)"></app-landing-page>
      } @else {
        <app-auth 
          [initialMode]="currentView()" 
          (onBack)="currentView.set('landing')">
        </app-auth>
        <app-support-bot></app-support-bot>
      }
    }
  `,
  styles: [`
    .animate-fade-in { animation: fadeIn 0.3s ease-out; }
    @keyframes fadeIn { from { opacity: 0; } to { opacity: 1; } }
    @keyframes musicBar { 0%, 100% { height: 30%; } 50% { height: 100%; } }
    .animate-music-bar { animation: musicBar 1s infinite ease-in-out; }
    .custom-scrollbar::-webkit-scrollbar { width: 4px; }
    .custom-scrollbar::-webkit-scrollbar-track { background: transparent; }
    .custom-scrollbar::-webkit-scrollbar-thumb { background: #334155; border-radius: 2px; }
  `]
})
export class AppComponent {
  dataService = inject(DataService);
  isAuthenticated = this.dataService.isAuthenticated;
  currentUser = this.dataService.currentUser;
  isAdmin = this.dataService.isAdmin;
  
  currentView = signal<'landing' | 'login' | 'register'>('landing');
  
  // Set default tab back to Dashboard
  activeTab: 'dashboard' | 'files' | 'tasks' | 'ai' | 'admin' | 'settings' | 'mind' = 'dashboard';
  
  sidebarOpen = false;
  showUserMenu = false;
  musicPlaying = false;
  
  toggleMusic() {
    const audio = document.querySelector('audio') as HTMLAudioElement;
    if (!audio) return;
    
    if (this.musicPlaying) {
      audio.pause();
    } else {
      audio.volume = 0.3;
      audio.play().catch(e => console.log('Audio play failed', e));
    }
    this.musicPlaying = !this.musicPlaying;
  }

  constructor() {
    // Global Theme Effect
    effect(() => {
       const user = this.currentUser();
       if (user) {
         // Apply Dark Mode Class to Body
         if (user.preferences.theme === 'light') {
           document.body.classList.add('light-mode');
         } else {
           document.body.classList.remove('light-mode');
         }

         // Update RGB variable for glows
         const rgb = this.hexToRgb(user.preferences.accentHex);
         if (rgb) {
            document.documentElement.style.setProperty('--primary-rgb', `${rgb.r}, ${rgb.g}, ${rgb.b}`);
         }
       } else {
         // Default to dark mode if not logged in
         document.body.classList.remove('light-mode');
         document.documentElement.style.setProperty('--primary-rgb', '6, 182, 212'); // Cyan default for Workspace
       }
    });
  }

  isDarkMode() {
     return this.currentUser()?.preferences.theme === 'dark';
  }

  getNavClass(tab: string) {
    const isActive = this.activeTab === tab;
    const isDark = this.isDarkMode();
    
    let classes = "";
    
    // Background & Text Color
    if (isActive) {
       classes += isDark ? "bg-white/10 text-white " : "bg-slate-200 text-slate-900 ";
       classes += "border-current ";
    } else {
       classes += isDark ? "text-slate-400 hover:bg-white/5 hover:text-white border-transparent " : "text-slate-500 hover:bg-slate-100 hover:text-slate-900 border-transparent ";
    }

    return classes;
  }
  
  // Helper
  hexToRgb(hex: string) {
    const result = /^#?([a-f\d]{2})([a-f\d]{2})([a-f\d]{2})$/i.exec(hex);
    return result ? {
      r: parseInt(result[1], 16),
      g: parseInt(result[2], 16),
      b: parseInt(result[3], 16)
    } : null;
  }

  navigateToAuth(mode: 'login' | 'register') {
    this.currentView.set(mode);
  }

  toggleSidebar() {
    this.sidebarOpen = !this.sidebarOpen;
  }

  closeSidebar() {
    this.sidebarOpen = false;
  }

  setActiveTab(tab: any) {
    this.activeTab = tab;
    this.sidebarOpen = false; // Close sidebar on mobile after selection
  }

  logout() {
    this.dataService.logout();
    this.currentView.set('landing');
    this.showUserMenu = false;
    this.activeTab = 'dashboard';
    this.sidebarOpen = false;
    this.musicPlaying = false;
  }
}