import { Injectable, signal } from '@angular/core';

export interface AppNotification {
  id: string;
  type: 'success' | 'error' | 'info' | 'warning';
  message: string;
}

@Injectable({
  providedIn: 'root'
})
export class NotificationService {
  readonly notifications = signal<AppNotification[]>([]);

  show(message: string, type: 'success' | 'error' | 'info' | 'warning' = 'info') {
    const id = crypto.randomUUID();
    const newNotification: AppNotification = { id, type, message };
    
    this.notifications.update(current => [...current, newNotification]);

    // Auto-remove after 4 seconds
    setTimeout(() => {
      this.remove(id);
    }, 4000);
  }

  remove(id: string) {
    this.notifications.update(current => current.filter(n => n.id !== id));
  }
}