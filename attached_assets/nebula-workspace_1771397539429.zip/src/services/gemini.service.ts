import { Injectable } from '@angular/core';
import { GoogleGenAI, Type } from '@google/genai';
import { firebaseConfig } from '../firebase-config';

export interface ChatAttachment {
  mimeType: string;
  data: string; // base64
}

export interface GraphNode {
  id: string;
  label: string;
  type: 'file' | 'concept';
  color?: string;
}

export interface GraphLink {
  source: string;
  target: string;
}

export interface GraphData {
  nodes: GraphNode[];
  links: GraphLink[];
}

export interface PlantDetails {
  name: string;
  scientificName: string;
  description: string;
  care: {
    watering: string;
    sunlight: string;
    soil: string;
    temperature: string;
  };
  funFact: string;
}

@Injectable({
  providedIn: 'root'
})
export class GeminiService {
  private ai: GoogleGenAI;
  private apiKey: string;

  constructor() {
    // Use the key provided in the config/prompt
    this.apiKey = firebaseConfig.apiKey || process.env['API_KEY'] || '';
    this.ai = new GoogleGenAI({ apiKey: this.apiKey });
  }

  private isKeyValid(): boolean {
      // Basic check: length and not placeholder
      return this.apiKey.length > 20 && !this.apiKey.startsWith('WKLEJ');
  }

  async chat(message: string, history: any[] = [], attachment?: ChatAttachment | null, systemInstructionOverride?: string) {
    if (!this.isKeyValid()) {
        return { 
           text: "Tryb Demo: Nie wykryto poprawnego klucza Gemini API. System działa w trybie symulacji.", 
           grounding: [] 
        };
    }

    try {
      const currentMessageParts: any[] = [{ text: message }];

      if (attachment) {
        currentMessageParts.push({
          inlineData: {
            mimeType: attachment.mimeType,
            data: attachment.data
          }
        });
      }

      const defaultInstruction = `
        Jesteś Nebula Intelligence - zaawansowanym asystentem AI zintegrowanym z systemem plików.
        Twoje zadania:
        1. Analiza dokumentów i obrazów.
        2. Pomoc w organizacji pracy.
        3. Odpowiadanie na pytania techniczne i kreatywne.
        Bądź pomocny, profesjonalny i zwięzły.
      `;

      const response = await this.ai.models.generateContent({
        model: 'gemini-2.5-flash',
        contents: [
            ...history,
            { role: 'user', parts: currentMessageParts }
        ],
        config: {
          tools: [{ googleSearch: {} }], 
          systemInstruction: systemInstructionOverride || defaultInstruction
        }
      });
      
      const text = response.text;
      const grounding = response.candidates?.[0]?.groundingMetadata?.groundingChunks || [];
      
      return { text, grounding };
    } catch (error) {
      console.error('Gemini Chat Error:', error);
      return { text: "Przepraszam, nie udało mi się przetworzyć Twojego zapytania. Sprawdź połączenie lub klucz API.", grounding: [] };
    }
  }

  async generateImage(prompt: string): Promise<string | null> {
    if (!this.isKeyValid()) return null;
    try {
      const response = await this.ai.models.generateImages({
        model: 'imagen-4.0-generate-001',
        prompt: prompt,
        config: {
          numberOfImages: 1,
          aspectRatio: '16:9',
          outputMimeType: 'image/jpeg'
        }
      });

      const base64 = response.generatedImages?.[0]?.image?.imageBytes;
      return base64 ? `data:image/jpeg;base64,${base64}` : null;
    } catch (error) {
      console.error('Gemini Image Error:', error);
      return null;
    }
  }

  async generateKnowledgeGraph(fileNames: string[]): Promise<GraphData | null> {
    // Keeping this method for compatibility, though less used in Garden app
    if (!this.isKeyValid()) return null;
    
    try {
      if (fileNames.length === 0) return { nodes: [], links: [] };

      const prompt = `
        Oto lista plików: ${JSON.stringify(fileNames)}.
        Stwórz graf powiązań. Zwróć JSON.
      `;

      const response = await this.ai.models.generateContent({
        model: 'gemini-2.5-flash',
        contents: prompt,
        config: {
          responseMimeType: 'application/json',
          responseSchema: {
             type: Type.OBJECT,
             properties: {
                nodes: {
                   type: Type.ARRAY,
                   items: {
                      type: Type.OBJECT,
                      properties: {
                         id: { type: Type.STRING },
                         label: { type: Type.STRING },
                         type: { type: Type.STRING, enum: ['file', 'concept'] }
                      }
                   }
                },
                links: {
                   type: Type.ARRAY,
                   items: {
                      type: Type.OBJECT,
                      properties: {
                         source: { type: Type.STRING },
                         target: { type: Type.STRING }
                      }
                   }
                }
             }
          }
        }
      });

      const jsonStr = response.text;
      if (!jsonStr) return null;
      
      return JSON.parse(jsonStr) as GraphData;

    } catch (error) {
      console.error('Gemini Graph Error:', error);
      return null;
    }
  }

  async identifyPlant(base64Image: string): Promise<PlantDetails | null> {
    if (!this.isKeyValid()) return null;

    try {
      const prompt = `
        Zidentyfikuj roślinę na zdjęciu. Zwróć dane w formacie JSON w języku polskim.
        Wymagane pola:
        - name (polska nazwa potoczna)
        - scientificName (nazwa łacińska)
        - description (krótki opis w 2 zdaniach)
        - care (obiekt z polami: watering, sunlight, soil, temperature - krótkie porady po polsku)
        - funFact (jedna ciekawostka po polsku)
      `;
      
      const response = await this.ai.models.generateContent({
        model: 'gemini-2.5-flash',
        contents: [
           {
              role: 'user',
              parts: [
                 { text: prompt },
                 { inlineData: { mimeType: 'image/jpeg', data: base64Image } }
              ]
           }
        ],
        config: {
           responseMimeType: 'application/json',
           responseSchema: {
              type: Type.OBJECT,
              properties: {
                 name: { type: Type.STRING },
                 scientificName: { type: Type.STRING },
                 description: { type: Type.STRING },
                 care: {
                    type: Type.OBJECT,
                    properties: {
                       watering: { type: Type.STRING },
                       sunlight: { type: Type.STRING },
                       soil: { type: Type.STRING },
                       temperature: { type: Type.STRING }
                    }
                 },
                 funFact: { type: Type.STRING }
              }
           }
        }
      });
      
      const jsonStr = response.text;
      if (!jsonStr) return null;
      return JSON.parse(jsonStr) as PlantDetails;
      
    } catch (e) {
      console.error('Plant ID Error:', e);
      return null;
    }
  }
}