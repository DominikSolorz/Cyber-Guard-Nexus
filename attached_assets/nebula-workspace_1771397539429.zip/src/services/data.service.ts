import { Injectable, signal, computed, effect, inject } from '@angular/core';
import { NotificationService } from './notification.service';
import { FirebaseService } from './firebase.service';
import { PlantDetails } from './gemini.service';

export interface FileItem {
  id: string;
  ownerId: string;
  parentId: string | null;
  name: string;
  type: 'folder' | 'file';
  fileType?: 'pdf' | 'docx' | 'jpg' | 'png' | 'txt' | 'md' | 'unknown';
  date: string;
  size?: string;
  sizeBytes?: number;
  url?: string;
  originalFile?: File; // Only present immediately after upload before refresh
  content?: string; 
}

export interface Task {
  id: string;
  ownerId: string;
  title: string;
  status: 'todo' | 'in-progress' | 'done';
  priority: 'low' | 'medium' | 'high';
  createdAt: string;
}

export interface UserPreferences {
  theme: 'dark' | 'light';
  accentColor: string;
  accentHex: string;
  reduceMotion: boolean;
}

export interface User {
  id: string;
  email: string;
  role: 'user' | 'admin';
  name?: string;
  avatarUrl?: string;
  preferences: UserPreferences;
  firstName?: string; // Legacy mapping
  lastName?: string;  // Legacy mapping
  phone?: string;
  verified?: boolean;
}

export interface SavedPlant extends PlantDetails {
   id: string;
   ownerId: string;
   imageUrl?: string;
   dateAdded: string;
}

export type SortOption = 'name' | 'date' | 'size';
export type ViewMode = 'grid' | 'list';

@Injectable({
  providedIn: 'root'
})
export class DataService {
  private firebase = inject(FirebaseService);
  private notificationService = inject(NotificationService);

  // Fallback user state for when Firebase API is not enabled
  private demoUser = signal<User | null>(null);

  // --- Auth State ---
  // Computed from Firebase User OR Demo User
  readonly currentUser = computed<User | null>(() => {
      // 1. Check if we have a forced demo user (bypassing Firebase errors)
      const forcedUser = this.demoUser();
      if (forcedUser) return forcedUser;

      // 2. Check real Firebase user
      const fbUser = this.firebase.user();
      if (!fbUser) return null;
      
      // HARDCODED ADMIN LOGIC FOR 'gonzok17'
      const isAdmin = fbUser.email === 'gonzok17@nebula.admin' || fbUser.email?.startsWith('gonzok17@');

      return {
          id: fbUser.uid,
          email: fbUser.email || '',
          name: fbUser.displayName || fbUser.email?.split('@')[0],
          avatarUrl: fbUser.photoURL || undefined,
          role: isAdmin ? 'admin' : 'user', 
          firstName: fbUser.displayName?.split(' ')[0] || '',
          preferences: { theme: 'dark', accentColor: 'cyan', accentHex: '#06b6d4', reduceMotion: false } // Default prefs
      };
  });

  readonly isAuthenticated = computed(() => this.currentUser() !== null);
  readonly isAdmin = computed(() => this.currentUser()?.role === 'admin');

  // --- UI Preferences ---
  readonly viewMode = signal<ViewMode>('grid');
  readonly sortBy = signal<SortOption>('name');
  readonly sortAscending = signal<boolean>(true);

  // --- Data State ---
  readonly items = signal<FileItem[]>([]);
  readonly tasks = signal<Task[]>([]);
  readonly plants = signal<SavedPlant[]>([]);
  readonly currentFolderId = signal<string | null>(null);
  
  // Admin only: list of all users
  readonly allUsers = computed<User[]>(() => {
     if (this.isAdmin() && this.currentUser()) {
         return [this.currentUser()!];
     }
     return [];
  });

  // Listeners unsubscriptions
  private filesUnsub: any;
  private tasksUnsub: any;

  constructor() {
    effect(() => {
        const user = this.firebase.user();
        
        if (user) {
            // Subscribe to real data
            this.filesUnsub = this.firebase.subscribeToFiles((files) => {
                this.items.set(files);
            });
            this.tasksUnsub = this.firebase.subscribeToTasks((tasks) => {
                this.tasks.set(tasks);
            });
        } else {
            // Cleanup subscriptions if logged out
            if(this.filesUnsub) this.filesUnsub();
            if(this.tasksUnsub) this.tasksUnsub();
            
            // If we are NOT in forced demo mode, clear data.
            if (!this.demoUser()) {
                this.items.set([]);
                this.tasks.set([]);
                this.plants.set([]);
            }
        }
    });
  }

  // --- Computed Views ---
  readonly currentItems = computed(() => {
    const rawItems = this.items().filter(item => item.parentId === this.currentFolderId());
    return this.sortItems(rawItems);
  });
  
  readonly userTasks = computed(() => this.tasks());

  readonly breadcrumbs = computed(() => {
    const crumbs = [];
    let currentId = this.currentFolderId();
    // Safety check to prevent infinite loops in bad data
    let depth = 0;
    while (currentId && depth < 10) {
      const folder = this.items().find(i => i.id === currentId);
      if (folder) {
        crumbs.unshift(folder);
        currentId = folder.parentId;
      } else {
        break;
      }
      depth++;
    }
    return crumbs;
  });

  private sortItems(list: FileItem[]) {
     return list.sort((a, b) => {
      if (a.type !== b.type) return a.type === 'folder' ? -1 : 1;
      let comparison = 0;
      switch (this.sortBy()) {
        case 'name': comparison = a.name.localeCompare(b.name); break;
        case 'date': comparison = a.date.localeCompare(b.date); break;
        case 'size': comparison = (a.sizeBytes || 0) - (b.sizeBytes || 0); break;
      }
      return this.sortAscending() ? comparison : -comparison;
    });
  }

  // --- Actions ---

  // Method to bypass Firebase auth errors (Identity Toolkit not enabled)
  forceLogin(username: string) {
      const isAdmin = username === 'gonzok17' || username === 'gonzok17@nebula.admin';
      
      this.demoUser.set({
          id: 'local-admin-' + Date.now(),
          email: username.includes('@') ? username : `${username}@nebula.local`,
          name: isAdmin ? 'Administrator Gonzok' : username,
          role: isAdmin ? 'admin' : 'user',
          firstName: 'Gonzok',
          preferences: { theme: 'dark', accentColor: 'cyan', accentHex: '#06b6d4', reduceMotion: false }
      });
      
      this.notificationService.show('Zalogowano w trybie lokalnym (API Error Bypass)', 'success');
  }

  toggleViewMode() {
    this.viewMode.update(mode => mode === 'grid' ? 'list' : 'grid');
  }

  logout() {
    this.firebase.logout();
    this.demoUser.set(null); // Clear local override
    this.currentFolderId.set(null);
  }

  // --- File Actions ---
  setCurrentFolder(id: string | null) { this.currentFolderId.set(id); }

  async createFolder(name: string) {
    if (!this.currentUser()) return;
    
    // Check if we are in demo mode (no real firebase user)
    if (this.demoUser()) {
        this.addLocalItem({
            id: crypto.randomUUID(),
            ownerId: this.currentUser()!.id,
            parentId: this.currentFolderId(),
            name,
            type: 'folder',
            date: new Date().toISOString().split('T')[0],
            size: '',
            sizeBytes: 0
        });
        return;
    }

    await this.firebase.addFile({
      name,
      type: 'folder',
      parentId: this.currentFolderId(),
      date: new Date().toISOString().split('T')[0],
      size: '',
      sizeBytes: 0
    });
    this.notificationService.show(`Folder "${name}" utworzony w chmurze`, 'success');
  }

  async createTextFile(name: string, content: string = '') {
    const safeName = name.endsWith('.txt') || name.endsWith('.md') ? name : `${name}.txt`;
    const ext = safeName.endsWith('.md') ? 'md' : 'txt';
    const blob = new Blob([content]);
    
    // Demo mode fallback
    if (this.demoUser()) {
        this.addLocalItem({
            id: crypto.randomUUID(),
            ownerId: this.currentUser()!.id,
            parentId: this.currentFolderId(),
            name: safeName,
            type: 'file',
            fileType: ext,
            date: new Date().toISOString().split('T')[0],
            size: this.formatSize(blob.size),
            sizeBytes: blob.size,
            content: content
        });
        return;
    }

    await this.firebase.addFile({
      name: safeName,
      type: 'file',
      parentId: this.currentFolderId(),
      fileType: ext,
      date: new Date().toISOString().split('T')[0],
      size: this.formatSize(blob.size),
      sizeBytes: blob.size,
      content: content
    });
  }

  async updateFileContent(id: string, newContent: string) {
     const blob = new Blob([newContent]);
     
     if (this.demoUser()) {
         this.items.update(curr => curr.map(i => i.id === id ? {...i, content: newContent} : i));
         this.notificationService.show('Zapisano lokalnie', 'success');
         return;
     }

     await this.firebase.updateFile(id, {
         content: newContent,
         size: this.formatSize(blob.size),
         sizeBytes: blob.size
     });
     this.notificationService.show('Zapisano w bazie danych', 'success');
  }

  async uploadFile(file: File) {
    const fileType = this.detectFileType(file.name, file.type);
    this.notificationService.show('Wysyłanie pliku...', 'info');
    
    try {
        let url = '';
        if (!this.demoUser()) {
             // Upload to Firebase Storage only if real user
            url = await this.firebase.uploadFile(file);
        } else {
             // Mock URL for demo
             url = URL.createObjectURL(file);
        }
        
        const fileData = {
            name: file.name,
            type: 'file',
            parentId: this.currentFolderId(),
            fileType,
            date: new Date().toISOString().split('T')[0],
            size: this.formatSize(file.size),
            sizeBytes: file.size,
            url: url,
            originalFile: file // Keep reference for local preview
        };

        if (this.demoUser()) {
             this.addLocalItem({...fileData, id: crypto.randomUUID(), ownerId: this.currentUser()!.id} as FileItem);
             this.notificationService.show('Plik dodany lokalnie', 'success');
        } else {
             // Add metadata to Firestore
            await this.firebase.addFile(fileData);
            this.notificationService.show('Plik wysłany na serwer', 'success');
        }

    } catch(e) {
        this.notificationService.show('Błąd wysyłania', 'error');
    }
  }

  async renameItem(id: string, newName: string) {
    if(this.demoUser()) {
        this.items.update(curr => curr.map(i => i.id === id ? {...i, name: newName} : i));
        return;
    }
    await this.firebase.updateFile(id, { name: newName });
  }

  async deleteItem(id: string) {
    if(this.demoUser()) {
        this.items.update(curr => curr.filter(i => i.id !== id));
        this.notificationService.show('Usunięto', 'info');
        return;
    }
    await this.firebase.deleteFile(id);
    this.notificationService.show('Usunięto z chmury', 'info');
  }

  // --- Task Actions ---
  async addTask(title: string, priority: Task['priority'] = 'medium') {
    if(this.demoUser()) {
        this.tasks.update(curr => [...curr, {
            id: crypto.randomUUID(),
            ownerId: this.currentUser()!.id,
            title,
            status: 'todo',
            priority,
            createdAt: new Date().toISOString()
        }]);
        return;
    }
    await this.firebase.addTask({
        title,
        status: 'todo',
        priority
    });
  }

  async updateTaskStatus(id: string, status: Task['status']) {
    if (this.demoUser()) {
        this.tasks.update(curr => curr.map(t => t.id === id ? {...t, status} : t));
        return;
    }
    await this.firebase.updateTask(id, { status });
  }

  async deleteTask(id: string) {
    if (this.demoUser()) {
        this.tasks.update(curr => curr.filter(t => t.id !== id));
        return;
    }
    await this.firebase.deleteTask(id);
  }

  // --- Plant Actions ---
  savePlant(details: PlantDetails, imageUrl?: string) {
     const newPlant: SavedPlant = {
        ...details,
        id: crypto.randomUUID(),
        ownerId: this.currentUser()?.id || 'anon',
        imageUrl,
        dateAdded: new Date().toISOString()
     };
     this.plants.update(curr => [...curr, newPlant]);
     this.notificationService.show('Roślina dodana do ogrodu', 'success');
  }

  deletePlant(id: string) {
     this.plants.update(curr => curr.filter(p => p.id !== id));
     this.notificationService.show('Roślina usunięta', 'info');
  }

  // --- Helpers ---
  private addLocalItem(item: FileItem) {
      this.items.update(curr => [...curr, item]);
  }

  private detectFileType(name: string, mime: string): FileItem['fileType'] {
    const ext = name.split('.').pop()?.toLowerCase();
    if (mime.includes('image') || ['jpg', 'jpeg', 'png', 'gif'].includes(ext || '')) {
       return (ext === 'png' || mime.includes('png')) ? 'png' : 'jpg';
    }
    if (mime.includes('pdf') || ext === 'pdf') return 'pdf';
    if (mime.includes('word') || ext === 'docx' || ext === 'doc') return 'docx';
    if (ext === 'txt') return 'txt';
    if (ext === 'md') return 'md';
    return 'unknown';
  }

  private formatSize(bytes: number): string {
    if (bytes === 0) return '0 B';
    const k = 1024;
    const sizes = ['B', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(1)) + ' ' + sizes[i];
  }
  
  // Admin stubs (no real backend for user management in this MVP)
  adminResetUserPassword(userId: string) {
      this.notificationService.show('Funkcja dostępna tylko w pełnej konsoli Firebase.', 'warning');
  }
  
  adminDeleteUser(userId: string) {
      this.notificationService.show('Funkcja dostępna tylko w pełnej konsoli Firebase.', 'warning');
  }
  
  updateUser(u: any) { this.notificationService.show('Zapisano zmiany w profilu', 'success'); } 
  updatePreferences(p: any) {}
  setSort(o: any) { this.sortBy.set(o); }
}