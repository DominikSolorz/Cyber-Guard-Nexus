import { Injectable, signal } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class VoiceService {
  private recognition: any;
  private synthesis = window.speechSynthesis;
  
  readonly isListening = signal(false);
  readonly isSpeaking = signal(false);
  readonly availableVoices = signal<SpeechSynthesisVoice[]>([]);
  readonly selectedVoice = signal<SpeechSynthesisVoice | null>(null);

  constructor() {
    this.initSpeechRecognition();
    this.loadVoices();
    
    // Voices are loaded asynchronously in some browsers
    if (this.synthesis.onvoiceschanged !== undefined) {
      this.synthesis.onvoiceschanged = () => this.loadVoices();
    }
  }

  private initSpeechRecognition() {
    if ('webkitSpeechRecognition' in window) {
      const v = (window as any).webkitSpeechRecognition;
      this.recognition = new v();
      this.recognition.continuous = false;
      this.recognition.lang = 'pl-PL';
      this.recognition.interimResults = false;
      this.recognition.maxAlternatives = 1;
    }
  }

  private loadVoices() {
    const voices = this.synthesis.getVoices().filter(v => v.lang.includes('pl'));
    this.availableVoices.set(voices);
    
    // Auto-select first available Polish voice if not set
    if (!this.selectedVoice() && voices.length > 0) {
      this.selectedVoice.set(voices[0]);
    }
  }

  setVoice(voiceName: string) {
    const voice = this.availableVoices().find(v => v.name === voiceName);
    if (voice) this.selectedVoice.set(voice);
  }

  listen(): Promise<string> {
    return new Promise((resolve, reject) => {
      if (!this.recognition) {
        reject('Przeglądarka nie obsługuje rozpoznawania mowy.');
        return;
      }

      this.isListening.set(true);
      this.recognition.start();

      this.recognition.onresult = (event: any) => {
        const transcript = event.results[0][0].transcript;
        this.isListening.set(false);
        resolve(transcript);
      };

      this.recognition.onerror = (event: any) => {
        this.isListening.set(false);
        reject('Błąd mikrofonu: ' + event.error);
      };

      this.recognition.onend = () => {
        this.isListening.set(false);
      };
    });
  }

  stopListening() {
    if (this.recognition) this.recognition.stop();
    this.isListening.set(false);
  }

  speak(text: string) {
    if (this.synthesis.speaking) {
      this.synthesis.cancel();
    }

    const utterance = new SpeechSynthesisUtterance(text);
    utterance.lang = 'pl-PL';
    
    if (this.selectedVoice()) {
      utterance.voice = this.selectedVoice();
    }

    utterance.onstart = () => this.isSpeaking.set(true);
    utterance.onend = () => this.isSpeaking.set(false);
    utterance.onerror = () => this.isSpeaking.set(false);

    this.synthesis.speak(utterance);
  }

  stopSpeaking() {
    this.synthesis.cancel();
    this.isSpeaking.set(false);
  }
}