import { Injectable, signal } from '@angular/core';
import { initializeApp, FirebaseApp } from 'firebase/app';
import { getAuth, signInWithPopup, GoogleAuthProvider, signOut, User as FireUser, onAuthStateChanged, createUserWithEmailAndPassword, signInWithEmailAndPassword, updateProfile, linkWithPopup, unlink } from 'firebase/auth';
import { getFirestore, collection, addDoc, query, where, onSnapshot, doc, updateDoc, deleteDoc } from 'firebase/firestore';
import { getStorage, ref, uploadBytes, getDownloadURL } from 'firebase/storage';
import { firebaseConfig } from '../firebase-config';
import { NotificationService } from './notification.service';

@Injectable({
  providedIn: 'root'
})
export class FirebaseService {
  private app: FirebaseApp | undefined;
  public auth: any;
  public db: any;
  public storage: any;

  readonly user = signal<FireUser | null>(null);
  readonly isInitialized = signal(false);
  
  // Removed demoMode signal
  // Removed demoStore

  constructor(private notificationService: NotificationService) {
    this.initialize();
  }

  private initialize() {
    try {
      // Initialize Firebase directly
      this.app = initializeApp(firebaseConfig);
      this.auth = getAuth(this.app);
      this.db = getFirestore(this.app);
      this.storage = getStorage(this.app);
      
      onAuthStateChanged(this.auth, (u: FireUser | null) => {
        this.user.set(u);
      });

      this.isInitialized.set(true);

    } catch (e: any) {
      console.error('Firebase init failed', e);
      this.notificationService.show('Błąd inicjalizacji Firebase. Sprawdź konfigurację.', 'error');
    }
  }

  // --- Auth Methods ---

  async loginWithGoogle() {
    const provider = new GoogleAuthProvider();
    provider.addScope('email');
    provider.addScope('profile');
    provider.setCustomParameters({ prompt: 'select_account' });

    try {
      await signInWithPopup(this.auth, provider);
      this.notificationService.show('Zalogowano przez Google', 'success');
    } catch (e: any) {
      this.handleAuthError(e);
      throw e;
    }
  }

  async loginEmail(email: string, pass: string) {
    try {
      await signInWithEmailAndPassword(this.auth, email, pass);
      this.notificationService.show('Zalogowano pomyślnie', 'success');
    } catch (e: any) {
      this.handleAuthError(e);
      throw e;
    }
  }

  async registerEmail(email: string, pass: string, name: string) {
    try {
      const cred = await createUserWithEmailAndPassword(this.auth, email, pass);
      await updateProfile(cred.user, { displayName: name });
      this.notificationService.show('Konto utworzone', 'success');
    } catch (e: any) {
      this.handleAuthError(e);
      throw e;
    }
  }

  async logout() {
    if (!this.auth) return;
    try {
      await signOut(this.auth);
      this.notificationService.show('Wylogowano', 'info');
    } catch (e: any) {
      console.error(e);
    }
  }

  // --- Account Linking ---

  async linkGoogle() {
    if (!this.user()) return;
    const provider = new GoogleAuthProvider();
    try {
      await linkWithPopup(this.user()!, provider);
      this.notificationService.show('Połączono konto Google', 'success');
    } catch (e: any) {
      this.handleAuthError(e);
    }
  }

  async unlinkGoogle() {
    if (!this.user()) return;
    try {
      await unlink(this.user()!, 'google.com');
      this.notificationService.show('Rozłączono konto Google', 'success');
    } catch (e: any) {
      this.notificationService.show('Błąd rozłączania: ' + e.message, 'error');
    }
  }

  // --- Firestore Data Methods ---

  subscribeToFiles(callback: (files: any[]) => void) {
    if (!this.user() || !this.db) return;
    
    const q = query(collection(this.db, 'files'), where('ownerId', '==', this.user()?.uid));
    
    return onSnapshot(q, (snapshot) => {
      const files = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
      callback(files);
    }, (error) => {
       console.error("Firestore subscription error", error);
       this.notificationService.show('Błąd pobierania plików', 'error');
    });
  }

  subscribeToTasks(callback: (tasks: any[]) => void) {
    if (!this.user() || !this.db) return;
    
    const q = query(collection(this.db, 'tasks'), where('ownerId', '==', this.user()?.uid));
    
    return onSnapshot(q, (snapshot) => {
      const tasks = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
      callback(tasks);
    }, (error) => {
       console.error("Firestore subscription error", error);
    });
  }

  // --- CRUD Operations ---

  async addFile(fileData: any) {
    try {
      // Sanitize undefined values
      const cleanData = JSON.parse(JSON.stringify(fileData));
      await addDoc(collection(this.db, 'files'), {
        ...cleanData,
        ownerId: this.user()?.uid,
        createdAt: new Date().toISOString()
      });
    } catch (e) {
      console.error(e);
      this.notificationService.show('Błąd zapisu pliku w bazie', 'error');
    }
  }

  async updateFile(id: string, data: any) {
    try {
        await updateDoc(doc(this.db, 'files', id), data);
    } catch(e) {
        this.notificationService.show('Błąd aktualizacji pliku', 'error');
    }
  }

  async deleteFile(id: string) {
    try {
        await deleteDoc(doc(this.db, 'files', id));
    } catch(e) {
        this.notificationService.show('Błąd usuwania pliku', 'error');
    }
  }

  async addTask(taskData: any) {
    try {
        await addDoc(collection(this.db, 'tasks'), {
            ...taskData,
            ownerId: this.user()?.uid,
            createdAt: new Date().toISOString()
        });
    } catch(e) {
        this.notificationService.show('Błąd dodawania zadania', 'error');
    }
  }

  async updateTask(id: string, data: any) {
    try {
      const docRef = doc(this.db, 'tasks', id);
      await updateDoc(docRef, data);
    } catch(e) {
      console.error(e);
    }
  }

  async deleteTask(id: string) {
    try {
      await deleteDoc(doc(this.db, 'tasks', id));
    } catch(e) {
      console.error(e);
    }
  }

  // --- Storage ---
  
  async uploadFile(file: File): Promise<string> {
      if (!this.user()) throw new Error('User not logged in');
      if (!this.storage) throw new Error('Storage not initialized');
      
      const path = `users/${this.user()!.uid}/${Date.now()}_${file.name}`;
      const storageRef = ref(this.storage, path);
      
      const snapshot = await uploadBytes(storageRef, file);
      const url = await getDownloadURL(snapshot.ref);
      return url;
  }

  // --- Helpers ---

  // Helper to maintain interface compatibility with components that might check this
  // In real mode, we are never in "demoMode", but the signal existed in the interface.
  // We can remove it, but check usages. Based on provided files, AuthComponent uses it.
  // Let's keep a dummy signal that is always false to prevent compilation errors in templates.
  readonly demoMode = signal(false);

  private handleAuthError(e: any) {
      if (e.code === 'auth/popup-closed-by-user') {
         this.notificationService.show('Logowanie anulowane.', 'info');
      } else if (e.code === 'auth/popup-blocked') {
         this.notificationService.show('Przeglądarka zablokowała okno logowania.', 'error');
      } else if (e.code === 'auth/operation-not-allowed') {
         this.notificationService.show('Metoda logowania jest wyłączona w konsoli Firebase.', 'error');
      } else if (e.code === 'auth/api-key-not-valid') {
         this.notificationService.show('Błąd konfiguracji: Nieprawidłowy klucz API.', 'error');
      } else {
         this.notificationService.show('Błąd logowania: ' + e.message, 'error');
      }
  }
}