import { Injectable, computed, inject, signal } from '@angular/core';
import { FirebaseService } from './firebase.service';
import { DataService } from './data.service';
import { NotificationService } from './notification.service';

export interface CloudStatus {
  online: boolean;
  syncing: boolean;
  lastSync: Date | null;
  googleConnected: boolean;
  googleAccount?: string;
  storageUsage: number;
  totalStorage: number;
}

@Injectable({
  providedIn: 'root'
})
export class CloudService {
  private firebase = inject(FirebaseService);
  private dataService = inject(DataService);
  private notificationService = inject(NotificationService);

  // Reactive state derived from real services
  readonly status = computed<CloudStatus>(() => {
    const user = this.firebase.user();
    const items = this.dataService.items();
    
    // Check if Google Provider is linked
    const googleProvider = user?.providerData.find(p => p.providerId === 'google.com');
    
    // Calculate real storage usage from file metadata
    const usedBytes = items.reduce((acc, i) => acc + (i.sizeBytes || 0), 0);

    return {
      online: navigator.onLine,
      syncing: false, // Firestore handles sync automatically, we consider it 'synced' mostly
      lastSync: new Date(), // Real-time
      googleConnected: !!googleProvider,
      googleAccount: googleProvider?.email || user?.email || undefined,
      storageUsage: usedBytes,
      totalStorage: 1024 * 1024 * 1024 // 1GB Limit (Soft limit for UI)
    };
  });

  constructor() {
    // Add online/offline listeners
    window.addEventListener('online', () => this.notificationService.show('Jesteś online.', 'success'));
    window.addEventListener('offline', () => this.notificationService.show('Przeszedłeś w tryb offline.', 'warning'));
  }

  async connectGoogleAccount(): Promise<boolean> {
    await this.firebase.linkGoogle();
    return !!this.status().googleConnected;
  }

  async disconnectGoogle() {
    await this.firebase.unlinkGoogle();
  }

  async syncData() {
    // Firestore sync is automatic
    this.notificationService.show('Synchronizacja z bazą danych jest automatyczna.', 'info');
  }
}