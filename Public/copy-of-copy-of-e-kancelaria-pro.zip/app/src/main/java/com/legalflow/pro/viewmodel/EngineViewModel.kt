
package com.legalflow.pro.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.legalflow.pro.LegalFlowApp
import com.legalflow.pro.data.*
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.util.Date

class EngineViewModel : ViewModel() {
    private val dao = LegalFlowApp.database.caseDao()
    
    // State
    val cases = dao.getAllCases().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    
    private val _activeCaseId = MutableStateFlow<String?>(null)
    
    val activeCaseFiles = _activeCaseId.flatMapLatest { id ->
        if (id == null) flowOf(emptyList()) else dao.getFilesForCase(id)
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Engine Actions
    fun createCase(title: String, client: String) {
        viewModelScope.launch {
            val newCase = CaseEntity(title = title, clientName = client, description = "Nowa sprawa")
            dao.insertCase(newCase)
        }
    }
    
    fun advanceState(caseEntity: CaseEntity) {
        viewModelScope.launch {
            val nextState = when(caseEntity.state) {
                FlowState.DRAFT -> FlowState.EVIDENCE
                FlowState.EVIDENCE -> FlowState.FILED
                FlowState.FILED -> FlowState.IN_COURT
                FlowState.IN_COURT -> FlowState.VERDICT
                FlowState.VERDICT -> FlowState.ARCHIVED
                FlowState.ARCHIVED -> FlowState.DRAFT
            }
            dao.insertCase(caseEntity.copy(state = nextState, lastUpdate = Date()))
        }
    }
    
    fun selectCase(id: String) {
        _activeCaseId.value = id
    }
    
    fun addFile(name: String, uri: String) {
        val cid = _activeCaseId.value ?: return
        viewModelScope.launch {
            dao.insertFile(FileEntity(caseId = cid, name = name, type = FileType.OTHER, uriString = uri))
        }
    }

    fun deleteFile(file: FileEntity) {
        viewModelScope.launch {
            dao.deleteFile(file)
        }
    }

    fun renameFile(fileId: String, newName: String) {
        viewModelScope.launch {
            dao.renameFile(fileId, newName)
        }
    }
}
