
package com.legalflow.pro

import android.app.Application
import androidx.room.Room
import com.legalflow.pro.data.AppDatabase

class LegalFlowApp : Application() {
    companion object {
        lateinit var database: AppDatabase
    }

    override fun onCreate() {
        super.onCreate()
        database = Room.databaseBuilder(
            applicationContext,
            AppDatabase::class.java,
            "legal_flow_db_v1"
        ).fallbackToDestructiveMigration().build()
    }
}
