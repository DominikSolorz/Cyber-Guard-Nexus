
package com.legalflow.pro.ui.components

import androidx.compose.animation.Crossfade
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.legalflow.pro.data.FileEntity
import com.legalflow.pro.data.FileType

enum class ViewMode { LIST, GRID, CAROUSEL }

@Composable
fun FileExplorer(
    files: List<FileEntity>,
    onAddFile: () -> Unit,
    onDeleteFile: (FileEntity) -> Unit,
    onRenameFile: (String, String) -> Unit,
    modifier: Modifier = Modifier
) {
    var viewMode by remember { mutableStateOf(ViewMode.LIST) }
    
    // Dialog States
    var fileToDelete by remember { mutableStateOf<FileEntity?>(null) }
    var fileToRename by remember { mutableStateOf<FileEntity?>(null) }

    Column(modifier = modifier.fillMaxWidth()) {
        // --- Toolbar ---
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 8.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                "Akta Sprawy (${files.size})",
                style = MaterialTheme.typography.titleMedium,
                color = Color.White
            )
            
            // View Switcher
            Row(
                modifier = Modifier
                    .background(MaterialTheme.colorScheme.surface, RoundedCornerShape(8.dp))
                    .padding(2.dp)
            ) {
                ViewModeButton(Icons.Default.ViewList, viewMode == ViewMode.LIST) { viewMode = ViewMode.LIST }
                ViewModeButton(Icons.Default.GridView, viewMode == ViewMode.GRID) { viewMode = ViewMode.GRID }
                ViewModeButton(Icons.Default.ViewCarousel, viewMode == ViewMode.CAROUSEL) { viewMode = ViewMode.CAROUSEL }
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        // --- Content Area ---
        Box(modifier = Modifier.weight(1f)) {
            if (files.isEmpty()) {
                Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(Icons.Default.FolderOpen, null, tint = Color.Gray, modifier = Modifier.size(48.dp))
                        Text("Brak plików", color = Color.Gray)
                        Button(onClick = onAddFile, modifier = Modifier.padding(top = 8.dp)) {
                            Text("Dodaj pierwszy plik")
                        }
                    }
                }
            } else {
                Crossfade(targetState = viewMode, label = "ViewTransition") { mode ->
                    when (mode) {
                        ViewMode.LIST -> ListView(
                            files, 
                            onMenuRename = { fileToRename = it },
                            onMenuDelete = { fileToDelete = it }
                        )
                        ViewMode.GRID -> GridView(
                            files,
                            onMenuRename = { fileToRename = it },
                            onMenuDelete = { fileToDelete = it }
                        )
                        ViewMode.CAROUSEL -> CarouselView(
                            files,
                            onMenuRename = { fileToRename = it },
                            onMenuDelete = { fileToDelete = it }
                        )
                    }
                }
            }
        }
        
        // Add Button
        if (files.isNotEmpty()) {
            Box(modifier = Modifier.fillMaxWidth().padding(16.dp), contentAlignment = Alignment.CenterEnd) {
                FloatingActionButton(onClick = onAddFile, containerColor = MaterialTheme.colorScheme.primary) {
                    Icon(Icons.Default.UploadFile, "Dodaj")
                }
            }
        }
    }

    // --- Dialogs ---
    if (fileToDelete != null) {
        AlertDialog(
            onDismissRequest = { fileToDelete = null },
            title = { Text("Usunąć plik?") },
            text = { Text("Czy na pewno chcesz usunąć '${fileToDelete?.name}'?") },
            confirmButton = {
                Button(onClick = { onDeleteFile(fileToDelete!!); fileToDelete = null }, colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error)) {
                    Text("Usuń")
                }
            },
            dismissButton = { TextButton(onClick = { fileToDelete = null }) { Text("Anuluj") } }
        )
    }

    if (fileToRename != null) {
        var newName by remember { mutableStateOf(fileToRename!!.name) }
        AlertDialog(
            onDismissRequest = { fileToRename = null },
            title = { Text("Zmień nazwę") },
            text = { OutlinedTextField(value = newName, onValueChange = { newName = it }, label = { Text("Nowa nazwa") }) },
            confirmButton = {
                Button(onClick = { 
                    if(newName.isNotEmpty()) {
                        onRenameFile(fileToRename!!.id, newName)
                        fileToRename = null 
                    }
                }) { Text("Zapisz") }
            },
            dismissButton = { TextButton(onClick = { fileToRename = null }) { Text("Anuluj") } }
        )
    }
}

@Composable
fun ViewModeButton(icon: ImageVector, isActive: Boolean, onClick: () -> Unit) {
    IconButton(
        onClick = onClick,
        colors = IconButtonDefaults.iconButtonColors(
            contentColor = if (isActive) MaterialTheme.colorScheme.primary else Color.Gray
        )
    ) {
        Icon(icon, null)
    }
}

// --- Menu Component ---
@Composable
fun FileContextMenu(
    expanded: Boolean,
    onDismiss: () -> Unit,
    onRename: () -> Unit,
    onDelete: () -> Unit
) {
    DropdownMenu(
        expanded = expanded,
        onDismissRequest = onDismiss
    ) {
        DropdownMenuItem(
            text = { Text("Zmień nazwę") },
            leadingIcon = { Icon(Icons.Default.Edit, null) },
            onClick = { onRename(); onDismiss() }
        )
        DropdownMenuItem(
            text = { Text("Usuń", color = Color.Red) },
            leadingIcon = { Icon(Icons.Default.Delete, null, tint = Color.Red) },
            onClick = { onDelete(); onDismiss() }
        )
    }
}

// --- LIST VIEW ---
@Composable
fun ListView(
    files: List<FileEntity>, 
    onMenuRename: (FileEntity) -> Unit,
    onMenuDelete: (FileEntity) -> Unit
) {
    LazyColumn(
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        items(files) { file ->
            var menuExpanded by remember { mutableStateOf(false) }
            
            Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
                Row(
                    modifier = Modifier.fillMaxWidth().padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    FileIcon(file.type)
                    Spacer(modifier = Modifier.width(16.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text(file.name, style = MaterialTheme.typography.bodyMedium, color = Color.White)
                        Text(file.type.name, style = MaterialTheme.typography.labelSmall, color = Color.Gray)
                    }
                    Box {
                        IconButton(onClick = { menuExpanded = true }) {
                            Icon(Icons.Default.MoreVert, null, tint = Color.Gray)
                        }
                        FileContextMenu(
                            expanded = menuExpanded,
                            onDismiss = { menuExpanded = false },
                            onRename = { onMenuRename(file) },
                            onDelete = { onMenuDelete(file) }
                        )
                    }
                }
            }
        }
    }
}

// --- GRID VIEW ---
@Composable
fun GridView(
    files: List<FileEntity>,
    onMenuRename: (FileEntity) -> Unit,
    onMenuDelete: (FileEntity) -> Unit
) {
    LazyVerticalGrid(
        columns = GridCells.Fixed(2),
        contentPadding = PaddingValues(16.dp),
        horizontalArrangement = Arrangement.spacedBy(12.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        items(files) { file ->
            var menuExpanded by remember { mutableStateOf(false) }
            
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                modifier = Modifier.aspectRatio(1f)
            ) {
                Box(modifier = Modifier.fillMaxSize()) {
                    // Menu Button (Top Right)
                    Box(modifier = Modifier.align(Alignment.TopEnd)) {
                        IconButton(onClick = { menuExpanded = true }) {
                            Icon(Icons.Default.MoreVert, null, tint = Color.Gray)
                        }
                        FileContextMenu(
                            expanded = menuExpanded,
                            onDismiss = { menuExpanded = false },
                            onRename = { onMenuRename(file) },
                            onDelete = { onMenuDelete(file) }
                        )
                    }
                    
                    // Content
                    Column(
                        modifier = Modifier.align(Alignment.Center).padding(12.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        FileIcon(file.type, size = 48)
                        Spacer(modifier = Modifier.height(12.dp))
                        Text(
                            file.name, 
                            style = MaterialTheme.typography.bodySmall, 
                            color = Color.White, 
                            maxLines = 2, 
                            overflow = TextOverflow.Ellipsis,
                            textAlign = androidx.compose.ui.text.style.TextAlign.Center
                        )
                    }
                }
            }
        }
    }
}

// --- CAROUSEL VIEW ---
@Composable
fun CarouselView(
    files: List<FileEntity>,
    onMenuRename: (FileEntity) -> Unit,
    onMenuDelete: (FileEntity) -> Unit
) {
    Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
        LazyRow(
            contentPadding = PaddingValues(horizontal = 32.dp),
            horizontalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            items(files) { file ->
                var menuExpanded by remember { mutableStateOf(false) }

                Card(
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    modifier = Modifier.width(220.dp).height(320.dp),
                    elevation = CardDefaults.cardElevation(defaultElevation = 8.dp)
                ) {
                    Box(modifier = Modifier.fillMaxSize()) {
                         // Menu Button
                        Box(modifier = Modifier.align(Alignment.TopEnd).padding(4.dp)) {
                            IconButton(onClick = { menuExpanded = true }) {
                                Icon(Icons.Default.MoreVert, null, tint = Color.Gray)
                            }
                            FileContextMenu(
                                expanded = menuExpanded,
                                onDismiss = { menuExpanded = false },
                                onRename = { onMenuRename(file) },
                                onDelete = { onMenuDelete(file) }
                            )
                        }

                        Column(
                            modifier = Modifier.align(Alignment.Center).padding(24.dp),
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.Center
                        ) {
                            FileIcon(file.type, size = 80)
                            Spacer(modifier = Modifier.height(24.dp))
                            Text(
                                file.name,
                                style = MaterialTheme.typography.titleMedium,
                                color = Color.White,
                                textAlign = androidx.compose.ui.text.style.TextAlign.Center
                            )
                            Spacer(modifier = Modifier.height(8.dp))
                            SuggestionChip(onClick = {}, label = { Text(file.type.name) })
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun FileIcon(type: FileType, size: Int = 24) {
    val (icon, color) = when (type) {
        FileType.PDF -> Icons.Default.PictureAsPdf to Color(0xFFEF4444)
        FileType.IMG -> Icons.Default.Image to Color(0xFF3B82F6)
        FileType.DOC -> Icons.Default.Description to Color(0xFF3B82F6)
        FileType.OTHER -> Icons.Default.InsertDriveFile to Color.Gray
    }
    Icon(icon, null, tint = color, modifier = Modifier.size(size.dp))
}
