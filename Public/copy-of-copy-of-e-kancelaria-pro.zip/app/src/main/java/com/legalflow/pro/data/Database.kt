
package com.legalflow.pro.data

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface CaseDao {
    @Query("SELECT * FROM cases ORDER BY lastUpdate DESC")
    fun getAllCases(): Flow<List<CaseEntity>>

    @Query("SELECT * FROM cases WHERE id = :id")
    suspend fun getCase(id: String): CaseEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertCase(caseEntity: CaseEntity)

    @Delete
    suspend fun deleteCase(caseEntity: CaseEntity)
    
    // Files
    @Query("SELECT * FROM files WHERE caseId = :caseId ORDER BY addedAt DESC")
    fun getFilesForCase(caseId: String): Flow<List<FileEntity>>
    
    @Insert
    suspend fun insertFile(file: FileEntity)

    @Delete
    suspend fun deleteFile(file: FileEntity)

    @Query("UPDATE files SET name = :newName WHERE id = :fileId")
    suspend fun renameFile(fileId: String, newName: String)
}

@Database(entities = [CaseEntity::class, FileEntity::class], version = 1, exportSchema = false)
@TypeConverters(Converters::class)
abstract class AppDatabase : RoomDatabase() {
    abstract fun caseDao(): CaseDao
}
