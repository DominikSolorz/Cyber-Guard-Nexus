
package com.legalflow.pro

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.viewModels
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.legalflow.pro.data.CaseEntity
import com.legalflow.pro.data.FlowState
import com.legalflow.pro.ui.components.FileExplorer
import com.legalflow.pro.ui.theme.LegalFlowTheme
import com.legalflow.pro.viewmodel.EngineViewModel

class MainActivity : ComponentActivity() {
    private val viewModel: EngineViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            LegalFlowTheme {
                Surface(modifier = Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
                    LegalApp(viewModel)
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun LegalApp(viewModel: EngineViewModel) {
    var showNewCaseDialog by remember { mutableStateOf(false) }
    var activeCaseForFiles by remember { mutableStateOf<CaseEntity?>(null) }
    
    val cases by viewModel.cases.collectAsState()
    val activeFiles by viewModel.activeCaseFiles.collectAsState()
    
    // Sheet State
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)

    Scaffold(
        floatingActionButton = {
            FloatingActionButton(onClick = { showNewCaseDialog = true }, containerColor = MaterialTheme.colorScheme.primary) {
                Icon(Icons.Default.Add, "Nowa Sprawa")
            }
        }
    ) { padding ->
        Column(modifier = Modifier.padding(padding).padding(16.dp)) {
            // Header
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.Balance, null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(32.dp))
                Spacer(modifier = Modifier.width(12.dp))
                Column {
                    Text("LegalFlow Pro", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
                    Text("Silnik Zarządzania Sprawami", style = MaterialTheme.typography.labelMedium, color = Color.Gray)
                }
            }
            Spacer(modifier = Modifier.height(24.dp))
            
            // Stats Row
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                StatCard("W toku", cases.count { it.state == FlowState.IN_COURT }.toString(), Color(0xFFEAB308))
                StatCard("Złożone", cases.count { it.state == FlowState.FILED }.toString(), Color(0xFFA855F7))
                StatCard("Wyroki", cases.count { it.state == FlowState.VERDICT }.toString(), Color(0xFF22C55E))
            }
            Spacer(modifier = Modifier.height(24.dp))

            // Case List
            Text("Aktywne Sprawy", style = MaterialTheme.typography.titleMedium, color = Color.Gray)
            Spacer(modifier = Modifier.height(8.dp))
            
            LazyColumn(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                items(cases) { caseItem ->
                    CaseCard(
                        caseEntity = caseItem, 
                        onNextState = { viewModel.advanceState(caseItem) },
                        onOpenFiles = { 
                            viewModel.selectCase(caseItem.id)
                            activeCaseForFiles = caseItem 
                        }
                    )
                }
                if(cases.isEmpty()) {
                    item { Text("Brak spraw. Utwórz nową.", color = Color.DarkGray, modifier = Modifier.padding(top=16.dp)) }
                }
            }
        }
    }
    
    // Dialogs & Sheets
    if (showNewCaseDialog) {
        NewCaseDialog(
            onDismiss = { showNewCaseDialog = false }, 
            onCreate = { t, c -> viewModel.createCase(t, c); showNewCaseDialog = false }
        )
    }
    
    if (activeCaseForFiles != null) {
        ModalBottomSheet(
            onDismissRequest = { activeCaseForFiles = null },
            sheetState = sheetState,
            containerColor = MaterialTheme.colorScheme.background
        ) {
            // --- TUTAJ JEST NOWY EKSPLORATOR Z FUNKCJAMI EDYCJI ---
            FileExplorer(
                files = activeFiles,
                onAddFile = {
                    val type = listOf("Umowa", "Zdjęcie", "Wniosek").random()
                    viewModel.addFile("$type ${System.currentTimeMillis() % 100}.pdf", "content://fake")
                },
                onRenameFile = { id, newName -> viewModel.renameFile(id, newName) },
                onDeleteFile = { file -> viewModel.deleteFile(file) },
                modifier = Modifier.fillMaxHeight(0.8f)
            )
        }
    }
}

@Composable
fun StatCard(label: String, value: String, color: Color) {
    Card(
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        modifier = Modifier.width(100.dp)
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Text(value, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold, color = color)
            Text(label, style = MaterialTheme.typography.labelSmall, color = Color.Gray)
        }
    }
}

@Composable
fun CaseCard(caseEntity: CaseEntity, onNextState: () -> Unit, onOpenFiles: () -> Unit) {
    val stateColor = Color(caseEntity.state.colorHex)
    
    Card(
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            // Header
            Row(horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                Box(
                    modifier = Modifier
                        .background(stateColor.copy(alpha = 0.2f), RoundedCornerShape(4.dp))
                        .padding(horizontal = 8.dp, vertical = 4.dp)
                ) {
                    Text(caseEntity.state.label, color = stateColor, style = MaterialTheme.typography.labelSmall)
                }
            }
            
            Spacer(modifier = Modifier.height(8.dp))
            Text(caseEntity.title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            Text(caseEntity.clientName, style = MaterialTheme.typography.bodyMedium, color = Color.Gray)
            
            Spacer(modifier = Modifier.height(16.dp))
            
            // Action Buttons
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(
                    onClick = onOpenFiles,
                    modifier = Modifier.weight(1f),
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primaryContainer, contentColor = MaterialTheme.colorScheme.onPrimaryContainer)
                ) {
                    Icon(Icons.Default.Folder, null, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Pliki")
                }
                
                Button(
                    onClick = onNextState,
                    modifier = Modifier.weight(1f),
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.background)
                ) {
                    Text("Status")
                    Spacer(modifier = Modifier.width(8.dp))
                    Icon(Icons.Default.ArrowForward, null, modifier = Modifier.size(16.dp))
                }
            }
        }
    }
}

@Composable
fun NewCaseDialog(onDismiss: () -> Unit, onCreate: (String, String) -> Unit) {
    var title by remember { mutableStateOf("") }
    var client by remember { mutableStateOf("") }
    
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Nowa Sprawa") },
        text = {
            Column {
                OutlinedTextField(value = title, onValueChange = { title = it }, label = { Text("Tytuł") })
                Spacer(modifier = Modifier.height(8.dp))
                OutlinedTextField(value = client, onValueChange = { client = it }, label = { Text("Klient") })
            }
        },
        confirmButton = {
            Button(onClick = { if(title.isNotEmpty()) onCreate(title, client) }) { Text("Utwórz") }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Anuluj") }
        }
    )
}
