
package com.legalflow.pro.data

import androidx.room.*
import java.util.Date
import java.util.UUID

// Nowy Silnik Stanów
enum class FlowState(val label: String, val colorHex: Long) {
    DRAFT("Szkic", 0xFF9CA3AF),         // Szary
    EVIDENCE("Dowody", 0xFF3B82F6),     // Niebieski
    FILED("Złożona", 0xFFA855F7),       // Fioletowy
    IN_COURT("W Sądzie", 0xFFEAB308),   // Żółty
    VERDICT("Wyrok", 0xFF22C55E),       // Zielony
    ARCHIVED("Archiwum", 0xFF4B5563)    // Ciemny szary
}

enum class FileType { PDF, IMG, DOC, OTHER }

@Entity(tableName = "cases")
data class CaseEntity(
    @PrimaryKey val id: String = UUID.randomUUID().toString(),
    val title: String,
    val clientName: String,
    val description: String,
    val state: FlowState = FlowState.DRAFT,
    val lastUpdate: Date = Date(),
    val courtDate: Date? = null
)

@Entity(tableName = "files")
data class FileEntity(
    @PrimaryKey val id: String = UUID.randomUUID().toString(),
    val caseId: String,
    val name: String,
    val type: FileType,
    val uriString: String,
    val addedAt: Date = Date()
)

// Converters
class Converters {
    @TypeConverter fun fromDate(date: Date?): Long? = date?.time
    @TypeConverter fun toDate(millis: Long?): Date? = millis?.let { Date(it) }
}
