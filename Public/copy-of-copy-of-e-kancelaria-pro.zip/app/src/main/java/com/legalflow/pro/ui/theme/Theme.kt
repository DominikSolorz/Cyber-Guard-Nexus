
package com.legalflow.pro.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

val CyberBlack = Color(0xFF0F172A)
val CyberDark = Color(0xFF1E293B)
val CyberBlue = Color(0xFF3B82F6)
val CyberPurple = Color(0xFF8B5CF6)
val TextWhite = Color(0xFFF8FAFC)

private val DarkScheme = darkColorScheme(
    primary = CyberBlue,
    secondary = CyberPurple,
    background = CyberBlack,
    surface = CyberDark,
    onPrimary = Color.White,
    onBackground = TextWhite,
    onSurface = TextWhite
)

@Composable
fun LegalFlowTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = DarkScheme,
        content = content
    )
}
