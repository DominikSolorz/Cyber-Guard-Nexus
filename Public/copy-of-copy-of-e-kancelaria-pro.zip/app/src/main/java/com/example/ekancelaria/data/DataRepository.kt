
package com.example.ekancelaria.data

import android.content.Context
import android.content.SharedPreferences
import com.example.ekancelaria.model.CaseFile
import com.example.ekancelaria.model.CaseFolder
import com.example.ekancelaria.model.CaseStatus
import com.example.ekancelaria.model.ChatMessage
import com.example.ekancelaria.model.LegalCase
import com.example.ekancelaria.model.User
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.emptyFlow
import kotlinx.coroutines.launch
import java.util.Date
import java.util.UUID

object DataRepository {
    private val _currentUser = MutableStateFlow<User?>(null)
    val currentUser = _currentUser.asStateFlow()

    private var database: AppDatabase? = null
    private var caseDao: CaseDao? = null
    private var chatDao: ChatDao? = null
    private var prefs: SharedPreferences? = null
    
    val cases: Flow<List<LegalCase>> 
        get() = caseDao?.getAllCases() ?: emptyFlow()
        
    val chatMessages: Flow<List<ChatMessage>>
        get() = chatDao?.getAllMessages() ?: emptyFlow()

    private val scope = CoroutineScope(Dispatchers.IO)

    fun initialize(context: Context) {
        database = AppDatabase.getDatabase(context)
        caseDao = database?.caseDao()
        chatDao = database?.chatDao()
        prefs = context.getSharedPreferences("ekancelaria_prefs", Context.MODE_PRIVATE)

        val savedUsername = prefs?.getString("logged_user", null)
        val savedRole = prefs?.getString("logged_role", "user") ?: "user"
        
        if (savedUsername != null) {
            _currentUser.value = User(UUID.randomUUID().toString(), savedUsername, savedRole)
        } else {
             _currentUser.value = null
        }
    }

    fun login(username: String, role: String) {
        prefs?.edit()
            ?.putString("logged_user", username)
            ?.putString("logged_role", role)
            ?.apply()
        _currentUser.value = User(UUID.randomUUID().toString(), username, role)
    }

    fun logout() {
        prefs?.edit()?.remove("logged_user")?.remove("logged_role")?.apply()
        _currentUser.value = null
    }

    // --- CASE OPERATIONS ---

    fun addCase(title: String, desc: String) {
        scope.launch {
            val newCase = LegalCase(
                title = title,
                description = desc,
                status = CaseStatus.NEW,
                deadline = Date()
            )
            caseDao?.insertCase(newCase)
        }
    }

    fun deleteCase(caseId: String) {
        scope.launch {
            caseDao?.deleteCase(caseId)
        }
    }

    // --- FOLDER OPERATIONS ---

    fun addFolder(caseId: String, name: String) {
        scope.launch {
            val currentCase = caseDao?.getCaseById(caseId) ?: return@launch
            val updatedFolders = currentCase.folders + CaseFolder(name = name)
            caseDao?.updateCase(currentCase.copy(folders = updatedFolders))
        }
    }

    fun renameFolder(caseId: String, folderId: String, newName: String) {
        scope.launch {
            val currentCase = caseDao?.getCaseById(caseId) ?: return@launch
            val updatedFolders = currentCase.folders.map { 
                if (it.id == folderId) it.copy(name = newName) else it 
            }
            caseDao?.updateCase(currentCase.copy(folders = updatedFolders))
        }
    }

    fun deleteFolder(caseId: String, folderId: String) {
        scope.launch {
            val currentCase = caseDao?.getCaseById(caseId) ?: return@launch
            val updatedFolders = currentCase.folders.filter { it.id != folderId }
            val updatedFiles = currentCase.files.map { 
                if (it.folderId == folderId) it.copy(folderId = null) else it 
            }
            caseDao?.updateCase(currentCase.copy(folders = updatedFolders, files = updatedFiles))
        }
    }

    // --- FILE OPERATIONS ---
    
    fun addFile(caseId: String, folderId: String?, file: CaseFile) {
        scope.launch {
            val currentCase = caseDao?.getCaseById(caseId) ?: return@launch
            val updatedFiles = currentCase.files + file
            caseDao?.updateCase(currentCase.copy(files = updatedFiles))
        }
    }
    
    fun renameFile(caseId: String, fileId: String, newName: String) {
        scope.launch {
            val currentCase = caseDao?.getCaseById(caseId) ?: return@launch
            val updatedFiles = currentCase.files.map { 
                if (it.id == fileId) it.copy(name = newName) else it 
            }
            caseDao?.updateCase(currentCase.copy(files = updatedFiles))
        }
    }
    
    // Nowa funkcja do aktualizacji treści (żeby podgląd działał i się zapisywał)
    fun updateFileContent(caseId: String, fileId: String, newContent: String) {
        scope.launch {
            val currentCase = caseDao?.getCaseById(caseId) ?: return@launch
            val updatedFiles = currentCase.files.map { 
                if (it.id == fileId) it.copy(content = newContent) else it 
            }
            caseDao?.updateCase(currentCase.copy(files = updatedFiles))
        }
    }

    fun deleteFile(caseId: String, fileId: String) {
        scope.launch {
            val currentCase = caseDao?.getCaseById(caseId) ?: return@launch
            val updatedFiles = currentCase.files.filter { it.id != fileId }
            caseDao?.updateCase(currentCase.copy(files = updatedFiles))
        }
    }

    fun saveChatMessage(text: String, isUser: Boolean) {
        scope.launch {
            val msg = ChatMessage(text = text, isUser = isUser)
            chatDao?.insertMessage(msg)
        }
    }
}
