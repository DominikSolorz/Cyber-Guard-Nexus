
package com.example.ekancelaria.viewmodel

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.OpenableColumns
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.ekancelaria.BuildConfig
import com.example.ekancelaria.data.DataRepository
import com.example.ekancelaria.model.CaseFile
import com.example.ekancelaria.model.FileType
import com.google.ai.client.generativeai.GenerativeModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.util.Date

class MainViewModel : ViewModel() {
    val currentUser = DataRepository.currentUser
    val cases = DataRepository.cases
    val chatMessages = DataRepository.chatMessages.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    
    private val _searchQuery = MutableStateFlow("")
    val searchQuery = _searchQuery.asStateFlow()
    
    val filteredCases = combine(cases, searchQuery) { casesList, query ->
        if (query.isEmpty()) casesList
        else casesList.filter { it.title.contains(query, ignoreCase = true) }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    private val _isAiThinking = MutableStateFlow(false)
    val isAiThinking = _isAiThinking.asStateFlow()

    private val generativeModel = GenerativeModel(
        modelName = "gemini-2.5-flash",
        apiKey = BuildConfig.GEMINI_API_KEY
    )

    fun onSearchQueryChanged(query: String) {
        _searchQuery.value = query
    }

    // --- Case Actions ---
    fun addCase(title: String, desc: String) = DataRepository.addCase(title, desc)
    fun deleteCase(caseId: String) = DataRepository.deleteCase(caseId)

    // --- Folder Actions ---
    fun addFolder(caseId: String, name: String) = DataRepository.addFolder(caseId, name)
    fun renameFolder(caseId: String, folderId: String, newName: String) = DataRepository.renameFolder(caseId, folderId, newName)
    fun deleteFolder(caseId: String, folderId: String) = DataRepository.deleteFolder(caseId, folderId)

    // --- File Actions ---
    fun renameFile(caseId: String, fileId: String, newName: String) = DataRepository.renameFile(caseId, fileId, newName)
    // Removed updateFileContent as we now use real files, not simulated text
    fun deleteFile(caseId: String, fileId: String) = DataRepository.deleteFile(caseId, fileId)

    // --- Handle Real File Upload ---
    fun handleFileUri(caseId: String, folderId: String?, uri: Uri, context: Context) {
        viewModelScope.launch {
            // 1. We must take persistable permission to access this file later (after reboot/restart)
            try {
                val takeFlags: Int = Intent.FLAG_GRANT_READ_URI_PERMISSION
                context.contentResolver.takePersistableUriPermission(uri, takeFlags)
            } catch (e: Exception) {
                // Some sources (like Downloads) might not support persistence, but we try anyway.
                e.printStackTrace()
            }

            val fileName = getFileName(context, uri) ?: "Dokument"
            val fileType = when {
                fileName.endsWith(".pdf", ignoreCase = true) -> FileType.PDF
                fileName.endsWith(".jpg", ignoreCase = true) || fileName.endsWith(".png", ignoreCase = true) || fileName.endsWith(".jpeg", ignoreCase = true) -> FileType.IMAGE
                fileName.endsWith(".doc", ignoreCase = true) || fileName.endsWith(".docx", ignoreCase = true) -> FileType.WORD
                else -> FileType.OTHER
            }
            
            val fileSize = getFileSize(context, uri)

            // 2. Save the REAL URI string to the database
            val newFile = CaseFile(
                name = fileName,
                type = fileType,
                size = fileSize,
                folderId = folderId,
                contentUri = uri.toString(), // Store the real URI
                content = "" // No fake content
            )
            DataRepository.addFile(caseId, folderId, newFile)
        }
    }

    private fun getFileName(context: Context, uri: Uri): String? {
        var result: String? = null
        if (uri.scheme == "content") {
            val cursor = context.contentResolver.query(uri, null, null, null, null)
            try {
                if (cursor != null && cursor.moveToFirst()) {
                    val index = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                    if (index >= 0) {
                        result = cursor.getString(index)
                    }
                }
            } catch (e: Exception) {
                e.printStackTrace()
            } finally {
                cursor?.close()
            }
        }
        if (result == null) {
            result = uri.path
            val cut = result?.lastIndexOf('/')
            if (cut != null && cut != -1) {
                result = result?.substring(cut + 1)
            }
        }
        return result
    }
    
    private fun getFileSize(context: Context, uri: Uri): String {
        var sizeStr = "Unknown"
        val cursor = context.contentResolver.query(uri, null, null, null, null)
        cursor?.use {
            if (it.moveToFirst()) {
                val sizeIndex = it.getColumnIndex(OpenableColumns.SIZE)
                if (sizeIndex != -1) {
                    val size = it.getLong(sizeIndex)
                    sizeStr = if (size > 1024 * 1024) {
                        String.format("%.1f MB", size / (1024.0 * 1024.0))
                    } else {
                        String.format("%.0f KB", size / 1024.0)
                    }
                }
            }
        }
        return sizeStr
    }

    // --- AI Chat ---
    fun sendMessage(text: String, activeCaseId: String?) {
        DataRepository.saveChatMessage(text, true)
        
        viewModelScope.launch {
            _isAiThinking.value = true
            try {
                val prompt = "Jesteś asystentem w systemie E-Kancelaria Pro. Użytkownik pyta: $text. Odpowiedz krótko."
                val response = generativeModel.generateContent(prompt)
                DataRepository.saveChatMessage(response.text ?: "Błąd AI", false)
            } catch (e: Exception) {
                 DataRepository.saveChatMessage("Błąd połączenia.", false)
            } finally {
                _isAiThinking.value = false
            }
        }
    }
}
