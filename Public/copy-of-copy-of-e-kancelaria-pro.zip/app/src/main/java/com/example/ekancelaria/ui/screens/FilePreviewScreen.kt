
package com.example.ekancelaria.ui.screens

import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Matrix
import android.graphics.pdf.PdfRenderer
import android.net.Uri
import android.os.ParcelFileDescriptor
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.BrokenImage
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.OpenInNew
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import coil.request.ImageRequest
import com.example.ekancelaria.model.FileType
import com.example.ekancelaria.ui.theme.Slate900
import com.example.ekancelaria.viewmodel.MainViewModel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.FileNotFoundException

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun FilePreviewScreen(fileId: String?, viewModel: MainViewModel, onBack: () -> Unit) {
    val cases by viewModel.cases.collectAsState()
    // Szukamy pliku w aktywnej sprawie
    val activeCase = cases.find { c -> c.files.any { it.id == fileId } }
    val file = activeCase?.files?.find { it.id == fileId }
    val context = LocalContext.current

    Scaffold(
        topBar = {
            TopAppBar(
                title = { 
                    Column {
                        Text(file?.name ?: "Podgląd Pliku", style = MaterialTheme.typography.titleMedium, color = Color.White)
                        Text(if (file != null) "Dokument Oryginalny" else "", style = MaterialTheme.typography.labelSmall, color = Color.Gray)
                    }
                },
                navigationIcon = {
                    IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, "Wróć", tint = Color.White) }
                },
                actions = {
                    if (file != null && file.contentUri.isNotEmpty()) {
                        IconButton(onClick = {
                            try {
                                val intent = Intent(Intent.ACTION_VIEW).apply {
                                    setDataAndType(Uri.parse(file.contentUri), when(file.type) {
                                        FileType.PDF -> "application/pdf"
                                        FileType.IMAGE -> "image/*"
                                        FileType.WORD -> "application/msword"
                                        else -> "*/*"
                                    })
                                    addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                                }
                                context.startActivity(intent)
                            } catch (e: Exception) {
                                // Fallback
                            }
                        }) {
                            Icon(Icons.Default.OpenInNew, "Otwórz w zewn. aplikacji", tint = Color.White)
                        }
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = Slate900)
            )
        },
        containerColor = Color(0xFF0F172A)
    ) { padding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
        ) {
            if (file == null) {
                Text("Plik nie znaleziony w bazie.", color = Color.Red, modifier = Modifier.align(Alignment.Center))
            } else {
                if (file.contentUri.isEmpty()) {
                    ErrorView("Brak ścieżki do pliku. Plik mógł zostać dodany w starej wersji aplikacji.")
                } else {
                    when (file.type) {
                        FileType.PDF -> {
                            RealPdfViewer(uriString = file.contentUri)
                        }
                        FileType.IMAGE -> {
                            RealImageViewer(uriString = file.contentUri)
                        }
                        else -> {
                            // Word lub inne formaty
                            Column(
                                modifier = Modifier.align(Alignment.Center),
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                Icon(Icons.Default.Description, null, tint = Color.Gray, modifier = Modifier.size(64.dp))
                                Spacer(modifier = Modifier.height(16.dp))
                                Text("Format: ${file.type}", color = Color.White)
                                Spacer(modifier = Modifier.height(8.dp))
                                Button(onClick = {
                                     try {
                                        val intent = Intent(Intent.ACTION_VIEW).apply {
                                            setDataAndType(Uri.parse(file.contentUri), "*/*")
                                            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                                        }
                                        context.startActivity(intent)
                                    } catch (e: Exception) {
                                        // ignore
                                    }
                                }) {
                                    Text("Otwórz w innej aplikacji")
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun RealImageViewer(uriString: String) {
    Box(modifier = Modifier.fillMaxSize().background(Color.Black)) {
        AsyncImage(
            model = ImageRequest.Builder(LocalContext.current)
                .data(Uri.parse(uriString))
                .crossfade(true)
                .build(),
            contentDescription = "Dokument - Obraz",
            contentScale = ContentScale.Fit,
            modifier = Modifier.fillMaxSize()
        )
    }
}

@Composable
fun RealPdfViewer(uriString: String) {
    val context = LocalContext.current
    // Przechowujemy wyrenderowane strony jako bitmapy
    var pdfBitmaps by remember { mutableStateOf<List<Bitmap>>(emptyList()) }
    var error by remember { mutableStateOf<String?>(null) }
    var isLoading by remember { mutableStateOf(true) }
    
    // Obliczamy szerokość ekranu, aby dopasować stronę PDF
    val displayMetrics = context.resources.displayMetrics
    val screenWidth = displayMetrics.widthPixels

    LaunchedEffect(uriString) {
        withContext(Dispatchers.IO) {
            try {
                val uri = Uri.parse(uriString)
                val fileDescriptor: ParcelFileDescriptor? = try {
                    context.contentResolver.openFileDescriptor(uri, "r")
                } catch (e: FileNotFoundException) {
                    null
                } catch (e: SecurityException) {
                    null // Brak uprawnień
                }

                if (fileDescriptor != null) {
                    val renderer = PdfRenderer(fileDescriptor)
                    val pageCount = renderer.pageCount
                    val pages = mutableListOf<Bitmap>()

                    // Renderujemy max 10 pierwszych stron dla wydajności (można zmienić na paged loading)
                    val limit = minOf(pageCount, 10)

                    for (i in 0 until limit) {
                        val page = renderer.openPage(i)
                        
                        // 1. Obliczamy wymiary docelowe
                        // Skalujemy tak, by szerokość strony pasowała do szerokości ekranu
                        val bitmapWidth = screenWidth
                        val scale = bitmapWidth.toFloat() / page.width.toFloat()
                        val bitmapHeight = (page.height * scale).toInt()
                        
                        // 2. Tworzymy bitmapę
                        val bitmap = Bitmap.createBitmap(bitmapWidth, bitmapHeight, Bitmap.Config.ARGB_8888)
                        
                        // 3. WAŻNE: Wypełniamy tło bielą (inaczej PDFy z przezroczystością będą czarne/niewidoczne)
                        bitmap.eraseColor(android.graphics.Color.WHITE)

                        // 4. WAŻNE: Matrix do skalowania
                        val matrix = Matrix()
                        matrix.postScale(scale, scale)

                        // 5. Renderujemy
                        page.render(bitmap, null, matrix, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
                        
                        pages.add(bitmap)
                        page.close()
                    }
                    renderer.close()
                    fileDescriptor.close()
                    
                    pdfBitmaps = pages
                } else {
                    error = "Nie można uzyskać dostępu do pliku. Sprawdź uprawnienia lub czy plik istnieje."
                }
            } catch (e: Exception) {
                e.printStackTrace()
                error = "Błąd odczytu PDF: ${e.message}"
            } finally {
                isLoading = false
            }
        }
    }

    Box(modifier = Modifier.fillMaxSize().background(Color(0xFF525659))) {
        if (isLoading) {
            CircularProgressIndicator(modifier = Modifier.align(Alignment.Center), color = Color.White)
        } else if (error != null) {
            ErrorView(error!!)
        } else {
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                items(pdfBitmaps.size) { index ->
                    val bitmap = pdfBitmaps[index]
                    
                    Column {
                        Card(
                            elevation = CardDefaults.cardElevation(defaultElevation = 8.dp),
                            shape = MaterialTheme.shapes.extraSmall, // Ostre rogi jak kartka
                        ) {
                            Image(
                                bitmap = bitmap.asImageBitmap(),
                                contentDescription = "Strona ${index + 1}",
                                modifier = Modifier.fillMaxWidth(),
                                contentScale = ContentScale.FillWidth
                            )
                        }
                        Text(
                            "Strona ${index + 1}",
                            color = Color.LightGray,
                            style = MaterialTheme.typography.labelSmall,
                            modifier = Modifier.fillMaxWidth().wrapContentWidth(Alignment.CenterHorizontally).padding(top = 8.dp)
                        )
                    }
                }
                
                if (pdfBitmaps.isEmpty()) {
                    item {
                        Text("Plik PDF jest pusty lub uszkodzony.", color = Color.White, modifier = Modifier.padding(16.dp))
                    }
                }
            }
        }
    }
}

@Composable
fun ErrorView(msg: String) {
    Column(
        modifier = Modifier.fillMaxSize().padding(32.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Icon(Icons.Default.BrokenImage, null, tint = Color.Red, modifier = Modifier.size(64.dp))
        Spacer(modifier = Modifier.height(16.dp))
        Text(msg, color = Color.White, style = MaterialTheme.typography.bodyLarge, textAlign = androidx.compose.ui.text.style.TextAlign.Center)
    }
}
