
package com.example.ekancelaria.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ExitToApp
import androidx.compose.material.icons.filled.Gavel
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Policy
import androidx.compose.material.icons.filled.Psychology
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.unit.dp
import com.example.ekancelaria.ui.theme.BluePrimary
import com.example.ekancelaria.ui.theme.Slate800
import com.example.ekancelaria.ui.theme.Slate900

@Composable
fun AppDrawer(
    currentRoute: String,
    onNavigate: (String) -> Unit,
    onLogout: () -> Unit,
    closeDrawer: () -> Unit
) {
    ModalDrawerSheet(
        drawerContainerColor = Slate900,
        drawerContentColor = Color.White
    ) {
        Column(
            modifier = Modifier
                .fillMaxHeight()
                .padding(16.dp)
        ) {
            // Header
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 24.dp),
                contentAlignment = Alignment.CenterStart
            ) {
                Column {
                    Icon(
                        imageVector = Icons.Default.Gavel,
                        contentDescription = null,
                        tint = BluePrimary,
                        modifier = Modifier.size(40.dp)
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    Text("E-Kancelaria Pro", style = MaterialTheme.typography.headlineSmall)
                    Text("Panel Użytkownika", style = MaterialTheme.typography.bodySmall, color = Color.Gray)
                }
            }
            
            HorizontalDivider(color = Slate800)
            Spacer(modifier = Modifier.height(16.dp))

            // Menu Items
            DrawerItem("Moje Sprawy", Icons.Default.Gavel, currentRoute == "dashboard") {
                onNavigate("dashboard"); closeDrawer()
            }
            DrawerItem("Asystent AI", Icons.Default.Psychology, currentRoute == "ai_assistant") {
                onNavigate("ai_assistant"); closeDrawer()
            }
            DrawerItem("Prywatność i Zasady", Icons.Default.Policy, currentRoute == "privacy") {
                onNavigate("privacy"); closeDrawer()
            }
            
            Spacer(modifier = Modifier.weight(1f))
            
            HorizontalDivider(color = Slate800)
            Spacer(modifier = Modifier.height(16.dp))
            
            DrawerItem("Wyloguj", Icons.Default.ExitToApp, false) {
                onLogout(); closeDrawer()
            }
        }
    }
}

@Composable
fun DrawerItem(label: String, icon: ImageVector, isSelected: Boolean, onClick: () -> Unit) {
    NavigationDrawerItem(
        label = { Text(label) },
        icon = { Icon(icon, null) },
        selected = isSelected,
        onClick = onClick,
        colors = NavigationDrawerItemDefaults.colors(
            selectedContainerColor = BluePrimary.copy(alpha = 0.2f),
            selectedIconColor = BluePrimary,
            selectedTextColor = BluePrimary,
            unselectedContainerColor = Color.Transparent,
            unselectedIconColor = Color.Gray,
            unselectedTextColor = Color.Gray
        ),
        modifier = Modifier.padding(vertical = 4.dp),
        shape = MaterialTheme.shapes.medium
    )
}
