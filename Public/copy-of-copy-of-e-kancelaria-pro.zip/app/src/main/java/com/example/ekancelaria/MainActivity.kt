
package com.example.ekancelaria

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.DrawerValue
import androidx.compose.material3.ModalNavigationDrawer
import androidx.compose.material3.Surface
import androidx.compose.material3.rememberDrawerState
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Modifier
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.example.ekancelaria.data.DataRepository
import com.example.ekancelaria.ui.components.AppDrawer
import com.example.ekancelaria.ui.screens.*
import com.example.ekancelaria.ui.theme.EKancelariaProTheme
import com.example.ekancelaria.viewmodel.MainViewModel
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            EKancelariaProTheme {
                val navController = rememberNavController()
                val viewModel: MainViewModel = viewModel()
                val currentUser by viewModel.currentUser.collectAsState()
                val drawerState = rememberDrawerState(initialValue = DrawerValue.Closed)
                val scope = rememberCoroutineScope()
                
                // Track current route for drawer highlight
                val navBackStackEntry by navController.currentBackStackEntryAsState()
                val currentRoute = navBackStackEntry?.destination?.route ?: ""

                // Determine start destination based on Auth
                val startDest = if (currentUser != null) "dashboard" else "intro"

                // Wrap Authenticated Routes in Drawer
                if (currentUser != null) {
                    ModalNavigationDrawer(
                        drawerState = drawerState,
                        drawerContent = {
                            AppDrawer(
                                currentRoute = currentRoute,
                                onNavigate = { route -> navController.navigate(route) },
                                onLogout = {
                                    DataRepository.logout()
                                    navController.navigate("login") { popUpTo(0) }
                                },
                                closeDrawer = { scope.launch { drawerState.close() } }
                            )
                        }
                    ) {
                        Surface(modifier = Modifier.fillMaxSize()) {
                            NavHost(navController = navController, startDestination = startDest) {
                                composable("intro") {
                                    IntroScreen(onFinish = { navController.navigate("login") })
                                }
                                composable("login") {
                                    LoginScreen(
                                        onLoginSuccess = { navController.navigate("dashboard") { popUpTo("login") { inclusive = true } } },
                                        onNavigateToPrivacy = { navController.navigate("privacy") }
                                    )
                                }
                                composable("privacy") {
                                    PrivacyScreen(onBack = { navController.popBackStack() })
                                }
                                composable("dashboard") {
                                    DashboardScreen(
                                        viewModel = viewModel,
                                        onCaseClick = { caseId -> navController.navigate("case_detail/$caseId") },
                                        onAiClick = { navController.navigate("ai_assistant") },
                                        onMenuClick = { scope.launch { drawerState.open() } }
                                    )
                                }
                                composable("case_detail/{caseId}") { backStackEntry ->
                                    val caseId = backStackEntry.arguments?.getString("caseId")
                                    CaseDetailScreen(
                                        caseId = caseId,
                                        viewModel = viewModel,
                                        onBack = { navController.popBackStack() },
                                        onFileClick = { fileId -> navController.navigate("file_preview/$fileId") }
                                    )
                                }
                                composable("file_preview/{fileId}") { backStackEntry ->
                                    val fileId = backStackEntry.arguments?.getString("fileId")
                                    FilePreviewScreen(
                                        fileId = fileId,
                                        viewModel = viewModel,
                                        onBack = { navController.popBackStack() }
                                    )
                                }
                                composable("ai_assistant") {
                                    AiAssistantScreen(
                                        viewModel = viewModel,
                                        onBack = { navController.popBackStack() }
                                    )
                                }
                            }
                        }
                    }
                } else {
                    // Non-authenticated flow
                     Surface(modifier = Modifier.fillMaxSize()) {
                        NavHost(navController = navController, startDestination = "intro") {
                            composable("intro") {
                                IntroScreen(onFinish = { navController.navigate("login") })
                            }
                            composable("login") {
                                LoginScreen(
                                    onLoginSuccess = { 
                                        navController.navigate("dashboard") { popUpTo(0) } 
                                    },
                                    onNavigateToPrivacy = { navController.navigate("privacy") }
                                )
                            }
                            composable("privacy") {
                                PrivacyScreen(onBack = { navController.popBackStack() })
                            }
                            composable("dashboard") { /* ... */ }
                        }
                    }
                }
            }
        }
    }
}
