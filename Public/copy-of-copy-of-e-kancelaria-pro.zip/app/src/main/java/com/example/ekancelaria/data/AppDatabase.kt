
package com.example.ekancelaria.data

import android.content.Context
import androidx.room.Dao
import androidx.room.Database
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.TypeConverters
import androidx.room.Update
import com.example.ekancelaria.model.ChatMessage
import com.example.ekancelaria.model.Converters
import com.example.ekancelaria.model.LegalCase
import kotlinx.coroutines.flow.Flow

@Dao
interface CaseDao {
    @Query("SELECT * FROM cases ORDER BY deadline ASC")
    fun getAllCases(): Flow<List<LegalCase>>

    @Query("SELECT * FROM cases WHERE id = :id")
    suspend fun getCaseById(id: String): LegalCase?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertCase(legalCase: LegalCase)

    @Update
    suspend fun updateCase(legalCase: LegalCase)

    @Query("DELETE FROM cases WHERE id = :id")
    suspend fun deleteCase(id: String)
}

@Dao
interface ChatDao {
    @Query("SELECT * FROM chat_messages ORDER BY timestamp ASC")
    fun getAllMessages(): Flow<List<ChatMessage>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertMessage(message: ChatMessage)
}

@Database(entities = [LegalCase::class, ChatMessage::class], version = 2, exportSchema = false)
@TypeConverters(Converters::class)
abstract class AppDatabase : RoomDatabase() {
    abstract fun caseDao(): CaseDao
    abstract fun chatDao(): ChatDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getDatabase(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "ekancelaria_db"
                )
                .fallbackToDestructiveMigration() // Uwaga: To czyści bazę przy zmianie wersji (dev only)
                .build()
                INSTANCE = instance
                instance
            }
        }
    }
}
