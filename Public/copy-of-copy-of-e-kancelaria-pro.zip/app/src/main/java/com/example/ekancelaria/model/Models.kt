
package com.example.ekancelaria.model

import androidx.room.Entity
import androidx.room.PrimaryKey
import androidx.room.TypeConverter
import com.google.gson.Gson
import com.google.gson.annotations.SerializedName
import com.google.gson.reflect.TypeToken
import java.util.Date
import java.util.UUID

enum class CaseStatus(val label: String) {
    IN_PROGRESS("W toku"),
    FINISHED("Zakończona"),
    NEW("Nowa")
}

data class CaseFolder(
    @SerializedName("id") val id: String = UUID.randomUUID().toString(),
    @SerializedName("name") val name: String,
    @SerializedName("isExpanded") val isExpanded: Boolean = false
)

data class CaseFile(
    @SerializedName("id") val id: String = UUID.randomUUID().toString(),
    @SerializedName("folderId") val folderId: String? = null, // null = root
    @SerializedName("name") val name: String,
    @SerializedName("type") val type: FileType,
    @SerializedName("size") val size: String,
    @SerializedName("dateAdded") val dateAdded: Date = Date(),
    @SerializedName("contentUri") val contentUri: String = "",
    // Nowe pole do trwałego zapisu treści dokumentu (symulacja OCR/treści pliku)
    @SerializedName("content") val content: String = "Treść dokumentu..." 
)

enum class FileType {
    PDF, IMAGE, WORD, OTHER
}

@Entity(tableName = "cases")
data class LegalCase(
    @PrimaryKey val id: String = UUID.randomUUID().toString(),
    val title: String,
    val description: String,
    val status: CaseStatus,
    val deadline: Date? = null,
    val folders: List<CaseFolder> = emptyList(),
    val files: List<CaseFile> = emptyList()
)

@Entity(tableName = "chat_messages")
data class ChatMessage(
    @PrimaryKey val id: String = UUID.randomUUID().toString(),
    val text: String,
    val isUser: Boolean,
    val timestamp: Date = Date()
)

data class User(
    val id: String,
    val username: String,
    val role: String
)

// --- Converters for Room Database ---
class Converters {
    private val gson = Gson()

    @TypeConverter
    fun fromTimestamp(value: Long?): Date? {
        return value?.let { Date(it) }
    }

    @TypeConverter
    fun dateToTimestamp(date: Date?): Long? {
        return date?.time
    }

    @TypeConverter
    fun fromFolderList(value: String): List<CaseFolder> {
        val type = object : TypeToken<List<CaseFolder>>() {}.type
        return gson.fromJson(value, type) ?: emptyList()
    }

    @TypeConverter
    fun toFolderList(list: List<CaseFolder>): String {
        return gson.toJson(list)
    }

    @TypeConverter
    fun fromFileList(value: String): List<CaseFile> {
        val type = object : TypeToken<List<CaseFile>>() {}.type
        return gson.fromJson(value, type) ?: emptyList()
    }

    @TypeConverter
    fun toFileList(list: List<CaseFile>): String {
        return gson.toJson(list)
    }
}
