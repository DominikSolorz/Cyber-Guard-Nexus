
package com.example.ekancelaria.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.ekancelaria.ui.theme.BluePrimary
import com.example.ekancelaria.ui.theme.Slate900

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PrivacyScreen(onBack: () -> Unit) {
    var selectedTab by remember { mutableIntStateOf(0) } // 0 = Polityka, 1 = Regulamin

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Bezpieczeństwo i Zasady") },
                navigationIcon = {
                    IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, "Wróć") }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = Slate900,
                    titleContentColor = Color.White,
                    navigationIconContentColor = Color.White
                )
            )
        },
        containerColor = Slate900
    ) { padding ->
        Column(modifier = Modifier.padding(padding)) {
            TabRow(
                selectedTabIndex = selectedTab,
                containerColor = Slate900,
                contentColor = BluePrimary,
                indicator = { tabPositions ->
                    TabRowDefaults.SecondaryIndicator(
                        Modifier.tabIndicatorOffset(tabPositions[selectedTab]),
                        color = BluePrimary
                    )
                }
            ) {
                Tab(selected = selectedTab == 0, onClick = { selectedTab = 0 }, text = { Text("Polityka Prywatności") })
                Tab(selected = selectedTab == 1, onClick = { selectedTab = 1 }, text = { Text("Regulamin") })
            }

            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .verticalScroll(rememberScrollState())
                    .padding(24.dp)
            ) {
                if (selectedTab == 0) {
                    PrivacyContent()
                } else {
                    TermsContent()
                }
            }
        }
    }
}

@Composable
fun PrivacyContent() {
    Column(verticalArrangement = Arrangement.spacedBy(16.dp)) {
        Icon(Icons.Default.Shield, null, tint = BluePrimary, modifier = Modifier.size(48.dp))
        Text("Twoje dane należą do Ciebie", style = MaterialTheme.typography.headlineSmall, color = Color.White)
        
        TextSection("1. Lokalny Zapis", "Wszystkie dane wprowadzane do aplikacji (sprawy, notatki, pliki) są zapisywane wyłącznie w pamięci Twojego urządzenia. Nie wysyłamy ich na zewnętrzne serwery, chyba że sam tego zażądasz (np. korzystając z AI).")
        
        TextSection("2. Rola Administratora", "Twórca aplikacji nie ma technicznej możliwości podglądania Twoich akt. Jesteś jedynym administratorem swoich danych.")
        
        TextSection("3. Korzystanie z AI", "Jeśli używasz Asystenta AI, treść Twojego pytania jest wysyłana do modelu językowego (Google Gemini) w celu analizy, a następnie natychmiast usuwana po wygenerowaniu odpowiedzi. Model nie uczy się na Twoich danych.")
    }
}

@Composable
fun TermsContent() {
    Column(verticalArrangement = Arrangement.spacedBy(16.dp)) {
        TextSection("1. Przeznaczenie", "Aplikacja służy do prywatnego zarządzania dokumentacją prawną i organizacją spraw.")
        
        TextSection("2. Odpowiedzialność", "Asystent AI służy jako pomoc, a nie ostateczna porada prawna. Zawsze konsultuj ważne decyzje z profesjonalnym prawnikiem.")
        
        TextSection("3. Konto Użytkownika", "Rejestracja odbywa się lokalnie. Jeśli zapomnisz hasła, odzyskanie danych może być niemożliwe ze względów bezpieczeństwa (szyfrowanie).")
    }
}

@Composable
fun TextSection(title: String, body: String) {
    Column {
        Text(title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = BluePrimary)
        Spacer(modifier = Modifier.height(4.dp))
        Text(body, style = MaterialTheme.typography.bodyMedium, color = Color.Gray)
    }
}
