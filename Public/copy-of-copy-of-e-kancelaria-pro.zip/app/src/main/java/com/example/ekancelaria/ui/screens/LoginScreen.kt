
package com.example.ekancelaria.ui.screens

import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Business
import androidx.compose.material.icons.filled.Email
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.MarkEmailRead
import androidx.compose.material.icons.filled.Person
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.blur
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.unit.dp
import com.example.ekancelaria.data.DataRepository
import com.example.ekancelaria.ui.components.GlassCard
import com.example.ekancelaria.ui.theme.BluePrimary

@Composable
fun LoginScreen(onLoginSuccess: () -> Unit, onNavigateToPrivacy: () -> Unit) {
    val context = LocalContext.current
    var isRegistering by remember { mutableStateOf(false) }
    var isVerifying by remember { mutableStateOf(false) } // Stan weryfikacji email
    
    var username by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var confirmPassword by remember { mutableStateOf("") }
    var email by remember { mutableStateOf("") } // Dodane pole email
    
    var verificationCodeInput by remember { mutableStateOf("") }
    var generatedCode by remember { mutableStateOf("") } // Kod "wysłany" na maila

    var selectedRole by remember { mutableStateOf("user") }
    var error by remember { mutableStateOf("") }
    var acceptedTerms by remember { mutableStateOf(false) }

    Box(modifier = Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background)) {
        // Tło
        Box(modifier = Modifier.align(Alignment.TopEnd).offset(x = 50.dp, y = (-50).dp)
            .size(300.dp).background(BluePrimary.copy(alpha=0.2f), CircleShape).blur(80.dp))
        
        Column(
            modifier = Modifier.align(Alignment.Center).padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Icon(
                imageVector = if (isVerifying) Icons.Default.MarkEmailRead else Icons.Default.Lock,
                contentDescription = null,
                modifier = Modifier.size(64.dp).padding(bottom = 16.dp),
                tint = BluePrimary
            )
            
            Text("E-Kancelaria Pro", style = MaterialTheme.typography.headlineMedium, color = Color.White)
            Text(
                when {
                    isVerifying -> "Weryfikacja Email"
                    isRegistering -> "Utwórz nowe konto"
                    else -> "Zaloguj się"
                }, 
                style = MaterialTheme.typography.bodyMedium, color = Color.Gray
            )
            
            Spacer(modifier = Modifier.height(32.dp))
            
            GlassCard(modifier = Modifier.fillMaxWidth()) {
                Column(modifier = Modifier.padding(24.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
                    
                    if (isVerifying) {
                        // --- EKRAN WERYFIKACJI ---
                        Text(
                            "Wysłaliśmy kod weryfikacyjny na adres: $email\n(Dla demo wpisz: 1234)", 
                            style = MaterialTheme.typography.bodySmall, 
                            color = Color.LightGray
                        )

                        OutlinedTextField(
                            value = verificationCodeInput,
                            onValueChange = { verificationCodeInput = it },
                            label = { Text("Kod weryfikacyjny") },
                            modifier = Modifier.fillMaxWidth(),
                            singleLine = true
                        )

                        Button(
                            onClick = {
                                // Weryfikacja kodu (w demo przyjmujemy 1234 lub to co wygenerowaliśmy)
                                if (verificationCodeInput == "1234" || verificationCodeInput == generatedCode) {
                                    DataRepository.login(username, selectedRole) 
                                    Toast.makeText(context, "Weryfikacja pomyślna!", Toast.LENGTH_SHORT).show()
                                    onLoginSuccess()
                                } else {
                                    error = "Nieprawidłowy kod"
                                }
                            },
                            modifier = Modifier.fillMaxWidth().height(50.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = BluePrimary)
                        ) {
                            Text("Potwierdź i wejdź")
                        }

                        TextButton(onClick = { isVerifying = false }) {
                            Text("Wróć", color = Color.Gray)
                        }

                    } else {
                        // --- EKRAN LOGOWANIA / REJESTRACJI ---
                        
                        if (isRegistering) {
                            Row(modifier = Modifier.fillMaxWidth().background(Color.Black.copy(alpha=0.3f), RoundedCornerShape(8.dp)).padding(4.dp)) {
                                RoleButton(
                                    text = "Klient",
                                    icon = Icons.Default.Person,
                                    isSelected = selectedRole == "user",
                                    onClick = { selectedRole = "user" },
                                    modifier = Modifier.weight(1f)
                                )
                                RoleButton(
                                    text = "Kancelaria",
                                    icon = Icons.Default.Business,
                                    isSelected = selectedRole == "admin",
                                    onClick = { selectedRole = "admin" },
                                    modifier = Modifier.weight(1f)
                                )
                            }
                        }

                        OutlinedTextField(
                            value = username,
                            onValueChange = { username = it },
                            label = { Text("Login") },
                            leadingIcon = { Icon(Icons.Default.Person, null) },
                            modifier = Modifier.fillMaxWidth(),
                            singleLine = true
                        )
                        
                        // Pole Email tylko przy rejestracji
                        if (isRegistering) {
                            OutlinedTextField(
                                value = email,
                                onValueChange = { email = it },
                                label = { Text("Adres Email") },
                                leadingIcon = { Icon(Icons.Default.Email, null) },
                                modifier = Modifier.fillMaxWidth(),
                                singleLine = true
                            )
                        }
                        
                        OutlinedTextField(
                            value = password,
                            onValueChange = { password = it },
                            label = { Text("Hasło") },
                            leadingIcon = { Icon(Icons.Default.Lock, null) },
                            visualTransformation = PasswordVisualTransformation(),
                            modifier = Modifier.fillMaxWidth(),
                            singleLine = true
                        )
                        
                        if (isRegistering) {
                            OutlinedTextField(
                                value = confirmPassword,
                                onValueChange = { confirmPassword = it },
                                label = { Text("Powtórz hasło") },
                                leadingIcon = { Icon(Icons.Default.Lock, null) },
                                visualTransformation = PasswordVisualTransformation(),
                                modifier = Modifier.fillMaxWidth(),
                                singleLine = true
                            )

                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Checkbox(
                                    checked = acceptedTerms,
                                    onCheckedChange = { acceptedTerms = it },
                                    colors = CheckboxDefaults.colors(checkedColor = BluePrimary)
                                )
                                Column {
                                    Text("Akceptuję regulamin", style = MaterialTheme.typography.bodySmall, color = Color.Gray)
                                    Text("Politykę Prywatności", style = MaterialTheme.typography.bodySmall, color = BluePrimary, textDecoration = TextDecoration.Underline, modifier = Modifier.clickable { onNavigateToPrivacy() })
                                }
                            }
                        }
                        
                        if (error.isNotEmpty()) {
                            Text(error, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
                        }
                        
                        Button(
                            onClick = {
                                if (username.isEmpty() || password.isEmpty()) {
                                    error = "Wypełnij wszystkie pola"
                                } else if (isRegistering) {
                                    if (email.isEmpty()) error = "Podaj email do weryfikacji"
                                    else if (password != confirmPassword) error = "Hasła nie są identyczne"
                                    else if (!acceptedTerms) error = "Musisz zaakceptować regulamin"
                                    else {
                                        // Symulacja wysłania kodu na email
                                        generatedCode = "1234" // W prawdziwej appce: Random.nextInt(1000, 9999).toString()
                                        Toast.makeText(context, "Kod wysłany na email: $generatedCode", Toast.LENGTH_LONG).show()
                                        isVerifying = true
                                        error = ""
                                    }
                                } else {
                                    val role = if (username.contains("admin") || username.contains("kancelaria")) "admin" else "user"
                                    DataRepository.login(username, role)
                                    onLoginSuccess()
                                }
                            },
                            modifier = Modifier.fillMaxWidth().height(50.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = BluePrimary)
                        ) {
                            Text(if (isRegistering) "Dalej" else "Zaloguj się")
                        }
                    }
                }
            }

            if (!isVerifying) {
                Spacer(modifier = Modifier.height(16.dp))
                TextButton(onClick = { 
                    isRegistering = !isRegistering 
                    error = ""
                }) {
                    Text(
                        if (isRegistering) "Masz już konto? Zaloguj się" else "Nie masz konta? Załóż je",
                        color = Color.Gray
                    )
                }
            }
        }
    }
}

@Composable
fun RoleButton(text: String, icon: androidx.compose.ui.graphics.vector.ImageVector, isSelected: Boolean, onClick: () -> Unit, modifier: Modifier = Modifier) {
    Button(
        onClick = onClick,
        modifier = modifier.padding(2.dp),
        colors = ButtonDefaults.buttonColors(
            containerColor = if (isSelected) BluePrimary else Color.Transparent,
            contentColor = if (isSelected) Color.White else Color.Gray
        ),
        shape = RoundedCornerShape(6.dp),
        contentPadding = PaddingValues(vertical = 8.dp)
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Icon(icon, null, modifier = Modifier.size(20.dp))
            Text(text, style = MaterialTheme.typography.labelSmall)
        }
    }
}
