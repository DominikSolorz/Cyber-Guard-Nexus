
package com.example.ekancelaria.ui.theme

import androidx.compose.ui.graphics.Color

val Purple80 = Color(0xFFD0BCFF)
val PurpleGrey80 = Color(0xFFCCC2DC)
val Pink80 = Color(0xFFEFB8C8)

val BluePrimary = Color(0xFF2563EB)
val Slate900 = Color(0xFF0F172A)
val Slate800 = Color(0xFF1E293B)
val Slate700 = Color(0xFF334155)
val TextWhite = Color(0xFFF1F5F9)
val TextGray = Color(0xFF94A3B8)

val StatusGreen = Color(0xFF4ADE80)
val StatusYellow = Color(0xFFFACC15)
val StatusGray = Color(0xFF9CA3AF)
