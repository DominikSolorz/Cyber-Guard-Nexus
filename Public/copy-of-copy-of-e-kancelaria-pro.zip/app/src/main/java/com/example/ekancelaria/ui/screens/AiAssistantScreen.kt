
package com.example.ekancelaria.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Send
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import com.example.ekancelaria.ui.theme.BluePrimary
import com.example.ekancelaria.ui.theme.Slate700
import com.example.ekancelaria.viewmodel.MainViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AiAssistantScreen(viewModel: MainViewModel, onBack: () -> Unit) {
    var prompt by remember { mutableStateOf("") }
    val messages by viewModel.chatMessages.collectAsState()
    val isThinking by viewModel.isAiThinking.collectAsState()
    
    // W tej wersji demo, zakładamy że AI ma dostęp do ostatnio otwartej sprawy lub jest ogólnym asystentem.
    // Aby funkcje działały (np. tworzenie folderu), musielibyśmy wiedzieć z której sprawy user kliknął w AI.
    // Tutaj dla uproszczenia (globalny chat) - przekażemy ID pierwszej sprawy z listy, jeśli istnieje,
    // jako "kontekst domyślny" lub null. W pełnej wersji kontekst powinien być przekazywany w nawigacji.
    val cases by viewModel.cases.collectAsState()
    val activeCaseId = cases.firstOrNull()?.id 

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Asystent AI") },
                navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, null) } },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = Color.Transparent)
            )
        },
        bottomBar = {
            Row(
                modifier = Modifier.padding(16.dp).fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                OutlinedTextField(
                    value = prompt,
                    onValueChange = { prompt = it },
                    modifier = Modifier.weight(1f),
                    placeholder = { Text("Np. Stwórz folder Dowody...") },
                    shape = RoundedCornerShape(24.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                IconButton(
                    onClick = { 
                        if (prompt.isNotEmpty()) {
                            viewModel.sendMessage(prompt, activeCaseId)
                            prompt = ""
                        }
                    },
                    enabled = !isThinking && prompt.isNotEmpty(),
                    modifier = Modifier.background(BluePrimary, androidx.compose.foundation.shape.CircleShape)
                ) {
                    Icon(Icons.Default.Send, null, tint = Color.White)
                }
            }
        }
    ) { padding ->
        LazyColumn(
            modifier = Modifier.padding(padding).padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp),
            reverseLayout = false
        ) {
            items(messages) { msg ->
                ChatBubble(text = msg.text, isUser = msg.isUser)
            }
            if (isThinking) {
                item {
                    Text("AI przetwarza...", style = MaterialTheme.typography.labelSmall, color = Color.Gray, modifier = Modifier.padding(8.dp))
                }
            }
        }
    }
}

@Composable
fun ChatBubble(text: String, isUser: Boolean) {
    Column(
        modifier = Modifier.fillMaxWidth(),
        horizontalAlignment = if (isUser) Alignment.End else Alignment.Start
    ) {
        Surface(
            color = if (isUser) BluePrimary else Slate700,
            shape = RoundedCornerShape(16.dp).copy(
                bottomEnd = if (isUser) 0.dp else 16.dp,
                bottomStart = if (isUser) 16.dp else 0.dp
            ),
            modifier = Modifier.widthIn(max = 300.dp)
        ) {
            Text(
                text = text,
                modifier = Modifier.padding(12.dp),
                color = Color.White
            )
        }
        Text(
            text = if (isUser) "Ty" else "Asystent",
            style = MaterialTheme.typography.labelSmall,
            color = Color.Gray,
            modifier = Modifier.padding(top = 4.dp, start = 4.dp, end = 4.dp)
        )
    }
}
