
package com.example.ekancelaria.ui.screens

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.CreateNewFolder
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.UploadFile
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.example.ekancelaria.model.FileType
import com.example.ekancelaria.ui.components.GlassCard
import com.example.ekancelaria.ui.theme.BluePrimary
import com.example.ekancelaria.ui.theme.StatusGreen
import com.example.ekancelaria.viewmodel.MainViewModel

@OptIn(ExperimentalMaterial3Api::class, ExperimentalFoundationApi::class)
@Composable
fun CaseDetailScreen(
    caseId: String?, 
    viewModel: MainViewModel, 
    onBack: () -> Unit,
    onFileClick: (String) -> Unit
) {
    val cases by viewModel.cases.collectAsState()
    val currentUser by viewModel.currentUser.collectAsState()
    val activeCase = cases.find { it.id == caseId }
    val isClient = currentUser?.role == "user"
    val context = LocalContext.current

    // Launcher do wyboru plików z systemu Android
    val filePickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        if (uri != null && activeCase != null) {
            viewModel.handleFileUri(activeCase.id, null, uri, context)
        }
    }

    if (activeCase == null) {
        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            Text("Nie znaleziono sprawy")
        }
        return
    }

    var showAddFolder by remember { mutableStateOf(false) }
    var itemToRename by remember { mutableStateOf<Pair<String, String>?>(null) }
    var isRenamingFolder by remember { mutableStateOf(false) }
    var itemToDelete by remember { mutableStateOf<String?>(null) }
    var isDeletingFolder by remember { mutableStateOf(false) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { 
                    Column {
                         Text(activeCase.title, maxLines = 1) 
                         if (isClient) {
                             Text("Śledzenie sprawy", style = MaterialTheme.typography.labelSmall, color = StatusGreen)
                         }
                    }
                },
                navigationIcon = {
                    IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, "Back") }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = Color.Transparent)
            )
        },
        bottomBar = {
            if (!isClient) {
                BottomAppBar(containerColor = Color.Transparent) {
                    IconButton(onClick = { showAddFolder = true }) {
                        Icon(Icons.Default.CreateNewFolder, "Dodaj folder", tint = BluePrimary)
                    }
                    Spacer(modifier = Modifier.weight(1f))
                    
                    // Przycisk "Dodaj Plik" uruchamia teraz prawdziwy wybór plików
                    ExtendedFloatingActionButton(
                        onClick = { 
                            filePickerLauncher.launch("*/*") // Pozwól wybrać dowolny plik
                        },
                        containerColor = BluePrimary,
                        icon = { Icon(Icons.Default.UploadFile, null) },
                        text = { Text("Dodaj Dokument") }
                    )
                }
            } else {
                 BottomAppBar(containerColor = Color.Transparent) {
                    Text(
                        "Kliknij w plik, aby otworzyć podgląd dokumentu.", 
                        style = MaterialTheme.typography.bodySmall, 
                        color = Color.Gray,
                        modifier = Modifier.padding(16.dp)
                    )
                 }
            }
        }
    ) { padding ->
        LazyColumn(
            modifier = Modifier.padding(padding).padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            item {
                 GlassCard(modifier = Modifier.fillMaxWidth().padding(bottom = 16.dp)) {
                     Column(modifier = Modifier.padding(16.dp)) {
                         Text("Opis Sprawy", style = MaterialTheme.typography.labelSmall, color = Color.Gray)
                         Text(activeCase.description, color = Color.White, style = MaterialTheme.typography.bodyMedium)
                     }
                 }
                 Text(if (isClient) "Twoje Akta" else "Zarządzanie Aktami", style = MaterialTheme.typography.titleMedium, color = BluePrimary)
            }

            items(activeCase.folders) { folder ->
                var expanded by remember { mutableStateOf(true) } // Domyślnie rozwinięte
                
                GlassCard(
                    modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp).combinedClickable(
                        onClick = { expanded = !expanded },
                        onLongClick = { 
                            if (!isClient) {
                                itemToRename = folder.id to folder.name
                                isRenamingFolder = true
                            }
                        }
                    )
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Folder, null, tint = Color(0xFFEAB308))
                            Spacer(modifier = Modifier.width(12.dp))
                            Text(folder.name, color = Color.White, modifier = Modifier.weight(1f))
                            
                            if (!isClient) {
                                Box {
                                    var menuExpanded by remember { mutableStateOf(false) }
                                    IconButton(onClick = { menuExpanded = true }, modifier = Modifier.size(24.dp)) {
                                        Icon(Icons.Default.MoreVert, null, tint = Color.Gray)
                                    }
                                    DropdownMenu(expanded = menuExpanded, onDismissRequest = { menuExpanded = false }) {
                                        DropdownMenuItem(
                                            text = { Text("Zmień nazwę") },
                                            onClick = { itemToRename = folder.id to folder.name; isRenamingFolder = true; menuExpanded = false }
                                        )
                                        DropdownMenuItem(
                                            text = { Text("Usuń") },
                                            onClick = { itemToDelete = folder.id; isDeletingFolder = true; menuExpanded = false }
                                        )
                                    }
                                }
                            }
                        }
                        
                        if (expanded) {
                            val folderFiles = activeCase.files.filter { it.folderId == folder.id }
                            if (folderFiles.isNotEmpty()) {
                                 Spacer(modifier = Modifier.height(8.dp))
                                 folderFiles.forEach { file ->
                                     FileRow(
                                         name = file.name, 
                                         isClient = isClient,
                                         modifier = Modifier.padding(start = 24.dp, top = 8.dp).clickable { onFileClick(file.id) },
                                         onRename = { itemToRename = file.id to file.name; isRenamingFolder = false },
                                         onDelete = { itemToDelete = file.id; isDeletingFolder = false }
                                     )
                                 }
                            } else {
                                Text("Pusty folder", style = MaterialTheme.typography.labelSmall, color = Color.Gray, modifier = Modifier.padding(start=36.dp, top=4.dp))
                            }
                        }
                    }
                }
            }

            val rootFiles = activeCase.files.filter { it.folderId == null }
            if (rootFiles.isNotEmpty()) {
                item { Text("Dokumenty", style = MaterialTheme.typography.labelSmall, color = Color.Gray, modifier = Modifier.padding(top=8.dp)) }
                items(rootFiles) { file ->
                    GlassCard(modifier = Modifier.fillMaxWidth().clickable { onFileClick(file.id) }) {
                        FileRow(
                            name = file.name, 
                            isClient = isClient,
                            modifier = Modifier.padding(12.dp),
                            onRename = { itemToRename = file.id to file.name; isRenamingFolder = false },
                            onDelete = { itemToDelete = file.id; isDeletingFolder = false }
                        )
                    }
                }
            }
        }
    }
    
    // --- DIALOGI ---

    if (showAddFolder && !isClient) {
        var folderName by remember { mutableStateOf("") }
        AlertDialog(
            onDismissRequest = { showAddFolder = false },
            title = { Text("Nowy Folder") },
            text = { OutlinedTextField(value = folderName, onValueChange = { folderName = it }, label = { Text("Nazwa") }) },
            confirmButton = {
                Button(onClick = { 
                    if(folderName.isNotEmpty()) {
                        viewModel.addFolder(activeCase.id, folderName)
                        showAddFolder = false
                    }
                }) { Text("Utwórz") }
            },
            dismissButton = { TextButton(onClick = { showAddFolder = false }) { Text("Anuluj") } }
        )
    }

    if (itemToRename != null && !isClient) {
        var newName by remember { mutableStateOf(itemToRename!!.second) }
        AlertDialog(
            onDismissRequest = { itemToRename = null },
            title = { Text("Zmień nazwę") },
            text = { OutlinedTextField(value = newName, onValueChange = { newName = it }) },
            confirmButton = {
                TextButton(onClick = { 
                    if (newName.isNotEmpty()) {
                        if (isRenamingFolder) viewModel.renameFolder(activeCase.id, itemToRename!!.first, newName)
                        else viewModel.renameFile(activeCase.id, itemToRename!!.first, newName)
                        itemToRename = null
                    }
                }) { Text("Zapisz") }
            },
            dismissButton = { TextButton(onClick = { itemToRename = null }) { Text("Anuluj") } }
        )
    }
    if (itemToDelete != null && !isClient) {
        AlertDialog(
            onDismissRequest = { itemToDelete = null },
            title = { Text("Usuń element") },
            text = { Text("Czy na pewno chcesz usunąć ten element i jego zawartość?") },
            confirmButton = {
                Button(onClick = { 
                     if (isDeletingFolder) viewModel.deleteFolder(activeCase.id, itemToDelete!!)
                     else viewModel.deleteFile(activeCase.id, itemToDelete!!)
                     itemToDelete = null
                }, colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error)) { Text("Usuń") }
            },
            dismissButton = { TextButton(onClick = { itemToDelete = null }) { Text("Anuluj") } }
        )
    }
}

@Composable
fun FileRow(name: String, isClient: Boolean, modifier: Modifier = Modifier, onRename: () -> Unit, onDelete: () -> Unit) {
    Row(modifier = modifier, verticalAlignment = Alignment.CenterVertically) {
        Icon(Icons.Default.Description, null, tint = BluePrimary)
        Spacer(modifier = Modifier.width(12.dp))
        Text(name, color = Color.White, modifier = Modifier.weight(1f))
        
        if (!isClient) {
             Box {
                var menuExpanded by remember { mutableStateOf(false) }
                IconButton(onClick = { menuExpanded = true }, modifier = Modifier.size(24.dp)) {
                    Icon(Icons.Default.MoreVert, null, tint = Color.Gray)
                }
                DropdownMenu(expanded = menuExpanded, onDismissRequest = { menuExpanded = false }) {
                    DropdownMenuItem(text = { Text("Zmień nazwę") }, onClick = { onRename(); menuExpanded = false })
                    DropdownMenuItem(text = { Text("Usuń") }, onClick = { onDelete(); menuExpanded = false })
                }
            }
        } else {
            Icon(Icons.Default.Visibility, null, tint = Color.Gray.copy(alpha=0.5f), modifier = Modifier.size(24.dp))
        }
    }
}
