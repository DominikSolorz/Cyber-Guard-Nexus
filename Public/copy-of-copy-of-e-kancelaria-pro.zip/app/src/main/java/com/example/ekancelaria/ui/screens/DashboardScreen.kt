
package com.example.ekancelaria.ui.screens

import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.Psychology
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import com.example.ekancelaria.model.CaseStatus
import com.example.ekancelaria.model.LegalCase
import com.example.ekancelaria.ui.components.GlassCard
import com.example.ekancelaria.ui.components.StatusBadge
import com.example.ekancelaria.ui.theme.BluePrimary
import com.example.ekancelaria.ui.theme.StatusGreen
import com.example.ekancelaria.ui.theme.StatusYellow
import com.example.ekancelaria.viewmodel.MainViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DashboardScreen(
    viewModel: MainViewModel, 
    onCaseClick: (String) -> Unit,
    onAiClick: () -> Unit,
    onMenuClick: () -> Unit
) {
    val cases by viewModel.filteredCases.collectAsState()
    val query by viewModel.searchQuery.collectAsState()
    val currentUser by viewModel.currentUser.collectAsState()
    
    // Klient nie może dodawać spraw - tylko admin/kancelaria
    val isClient = currentUser?.role == "user"
    
    var showAddDialog by remember { mutableStateOf(false) }
    var caseToDelete by remember { mutableStateOf<String?>(null) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { 
                    Column {
                        Text("Lista Spraw")
                        if (isClient) {
                            Text("Panel Klienta - Podgląd", style = MaterialTheme.typography.labelSmall, color = StatusGreen)
                        }
                    }
                },
                navigationIcon = {
                    IconButton(onClick = onMenuClick) {
                        Icon(Icons.Default.Menu, "Menu")
                    }
                },
                actions = {
                    IconButton(onClick = onAiClick) {
                        Icon(Icons.Default.Psychology, "AI Assistant", tint = Color.Magenta)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = Color.Transparent)
            )
        },
        floatingActionButton = {
            if (!isClient) {
                FloatingActionButton(
                    onClick = { showAddDialog = true },
                    containerColor = BluePrimary
                ) {
                    Icon(Icons.Default.Add, "Nowa Sprawa")
                }
            }
        }
    ) { padding ->
        Column(modifier = Modifier.padding(padding).padding(16.dp)) {
            OutlinedTextField(
                value = query,
                onValueChange = viewModel::onSearchQueryChanged,
                modifier = Modifier.fillMaxWidth().padding(bottom = 16.dp),
                placeholder = { Text("Szukaj sprawy...") },
                leadingIcon = { Icon(Icons.Default.Search, null) },
                shape = MaterialTheme.shapes.medium
            )
            
            LazyColumn(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                items(cases) { legalCase ->
                    CaseItem(
                        legalCase, 
                        onClick = { onCaseClick(legalCase.id) },
                        onLongClick = { 
                            // Tylko kancelaria może usuwać sprawy
                            if (!isClient) caseToDelete = legalCase.id 
                        }
                    )
                }
                if (cases.isEmpty()) {
                    item {
                        Box(modifier = Modifier.fillParentMaxSize(), contentAlignment = Alignment.Center) {
                            Text("Brak spraw", color = Color.Gray)
                        }
                    }
                }
            }
        }
    }
    
    if (showAddDialog) {
        NewCaseDialog(
            onDismiss = { showAddDialog = false },
            onConfirm = { t, d -> 
                viewModel.addCase(t, d)
                showAddDialog = false
            }
        )
    }

    if (caseToDelete != null) {
        AlertDialog(
            onDismissRequest = { caseToDelete = null },
            title = { Text("Usunąć sprawę?") },
            text = { Text("Tej operacji nie można cofnąć.") },
            confirmButton = {
                Button(
                    onClick = { 
                        viewModel.deleteCase(caseToDelete!!)
                        caseToDelete = null
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error)
                ) { Text("Usuń") }
            },
            dismissButton = {
                TextButton(onClick = { caseToDelete = null }) { Text("Anuluj") }
            }
        )
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun CaseItem(legalCase: LegalCase, onClick: () -> Unit, onLongClick: () -> Unit) {
    GlassCard(
        modifier = Modifier.fillMaxWidth().combinedClickable(
            onClick = onClick,
            onLongClick = onLongClick
        )
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                StatusBadge(
                    status = legalCase.status.label,
                    color = when(legalCase.status) {
                        CaseStatus.IN_PROGRESS -> StatusYellow
                        CaseStatus.NEW -> StatusGreen
                        else -> Color.Gray
                    }
                )
                if (legalCase.deadline != null) {
                    Text("Termin: 14 dni", style = MaterialTheme.typography.bodySmall, color = Color.Gray)
                }
            }
            Spacer(modifier = Modifier.height(8.dp))
            Text(legalCase.title, style = MaterialTheme.typography.titleMedium, color = Color.White)
            Text(legalCase.description, style = MaterialTheme.typography.bodySmall, color = Color.Gray, maxLines = 2)
        }
    }
}

@Composable
fun NewCaseDialog(onDismiss: () -> Unit, onConfirm: (String, String) -> Unit) {
    var title by remember { mutableStateOf("") }
    var desc by remember { mutableStateOf("") }
    
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Nowa Sprawa") },
        text = {
            Column {
                OutlinedTextField(value = title, onValueChange = { title = it }, label = { Text("Tytuł") })
                Spacer(modifier = Modifier.height(8.dp))
                OutlinedTextField(value = desc, onValueChange = { desc = it }, label = { Text("Opis") })
            }
        },
        confirmButton = {
            TextButton(onClick = { if (title.isNotEmpty()) onConfirm(title, desc) }) { Text("Dodaj") }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Anuluj") }
        }
    )
}
