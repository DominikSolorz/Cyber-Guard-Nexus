
package com.example.ekancelaria

import android.app.Application
import com.example.ekancelaria.data.DataRepository

class EKancelariaApp : Application() {
    override fun onCreate() {
        super.onCreate()
        // Inicjalizacja bazy danych przy starcie aplikacji
        DataRepository.initialize(this)
    }
}
